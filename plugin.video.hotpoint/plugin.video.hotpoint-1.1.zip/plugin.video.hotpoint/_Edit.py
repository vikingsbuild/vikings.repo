import xbmcaddon

MainBase ='https://pastebin.com/raw/UEVvFuTw'
addon = xbmcaddon.Addon('plugin.video.hotpoint')
