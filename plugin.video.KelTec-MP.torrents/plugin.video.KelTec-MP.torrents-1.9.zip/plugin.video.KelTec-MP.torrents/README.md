# KeltecMP IPTV download:
# https://keltec-mediaplay.ga/

Addon Editado pelo Team KeltecMP.

Nao somos responsaveis por colocar o conteudo online, apenas indexamos.

Link encurtado para download: http://bit.ly/Repositorio-KeltecMP-Oficial

Para sugestoes e report de bugs nossa pagina no FB: https://www.facebook.com/groups/KelTec.Media.Play/

Créditos base REPO LOJINK!(TORRENT PLAY)

Add-on Modificado, Funcional somente para Android.
Plugin: Configurado com Player Principal Elementum.
