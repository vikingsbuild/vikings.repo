# -*- coding: utf-8 -*-
import urllib
import urllib2
import datetime
import re
import os
import base64
import codecs
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import traceback
import cookielib
import time
import xbmcgui
import xbmc
import xbmcplugin
import webbrowser
import os
import xbmcaddon
from BeautifulSoup import BeautifulStoneSoup , BeautifulSoup , BeautifulSOAP
if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
o0OO00 = None
try :
 from xml . sax . saxutils import escape
except : traceback . print_exc ( )
if 78 - 78: i11i . oOooOoO0Oo0O
try :
 import json
except :
 import simplejson as json
import SimpleDownloader as downloader
import time
import requests
iI1 = False
if 43 - 43: I11i11Ii
if 65 - 65: i1iIi11iIIi1I
Oo = "10.06.20"
if 2 - 2: o0 * i1 * ii1IiI1i % OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
if 97 - 97: Ii1I - ii1IiI1i . I1Ii111 - OoooooooOO
oO0o = 'aHR0cHM6Ly9iaXQubHkvMlg0ZmsyMy0lQzMlQjAlQzIlOUQlQzIlOTElQzIlOTglQzMlQjAlQzIlOUQlQzIlOTElQzIlOTglQzMlQjAlQzIlOUQlQzIlOTElQzIlOTglQzMlQjAlQzIlOUQlQzIlOTElQzIlOTglQzMlQjAlQzIlOUQlQzIlOTElQzIlOTglQzMlQjAlQzIlOUQlQzIlOTElQzIlOTglQzMlQjAlQzIlOUQlQzIlOTElQzIlOTglQzMlQjAlQzIlOUQlQzIlOTElQzIlOTglQzMlQjAlQzIlOUQlQzIlOTElQzIlOTg='
IIII = base64 . b64decode ( oO0o )
if 59 - 59: i1IIi * i1IIi % I11i + i11i
if 32 - 32: o0 . o00O0oo * i1IIi . ooOoO0o / I1Ii111
o00 = '[COLOR orange][B]->[/COLOR][/B][COLOR deepskyblue][B] BEM-VINDOS[/COLOR][/B]'
if 62 - 62: i11iIiiIii - i11i % ooOoO0o - iIii1I11I1II1 . ii1IiI1i . i11i
if 61 - 61: OOooOOo / o0 / IiII * i1iIi11iIIi1I . i11i
if 1 - 1: i11i - ii1IiI1i % i11iIiiIii + I1Ii111 . ooOoO0o
Oooo0000 = '-> INSTALE PLUGIN PARA VER FILMES 4K'
if 22 - 22: iII111i . I1Ii111
if 41 - 41: ooOoO0o . o00O0oo * I1Ii111 % i11iIiiIii
if 74 - 74: IiII * I1Ii111
if 82 - 82: iIii1I11I1II1 % I1Ii111
oOo0oooo00o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3LzJQTk4xUGpL'
oO0o0o0ooO0oO = base64 . b64decode ( oOo0oooo00o )
if 52 - 52: i11i - i11iIiiIii % ooOoO0o
if 54 - 54: I11i % O0 + oOooOoO0Oo0O - IiII / Ii1I
if 31 - 31: i1iIi11iIIi1I + i11i
if 13 - 13: I11i * OOooOOo * oOooOoO0Oo0O
if 55 - 55: i11i
IIIiI11ii = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3BYR2gyckVu'
O000oo = base64 . b64decode ( IIIiI11ii )
if 3 - 3: IiII + O0
if 42 - 42: I11i / i1IIi + i11iIiiIii - iII111i
if 78 - 78: i1iIi11iIIi1I
Iii1I111 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1hDdDl6clRm'
OO0O0O00OooO = base64 . b64decode ( Iii1I111 )
if 77 - 77: i11i - i11i . oOooOoO0Oo0O / i1
if 14 - 14: Ii1I % O0
IiI1I1 = 3000
if 86 - 86: i11iIiiIii + iII111i + o00O0oo * Ii1I + i1
if 61 - 61: i1iIi11iIIi1I / i11iIiiIii
if 34 - 34: OoooooooOO + iIii1I11I1II1 + i11iIiiIii - ii1IiI1i + i11iIiiIii
if 65 - 65: o0
if 6 - 6: oOooOoO0Oo0O / I11i11Ii % iII111i
oo = 'aHR0cHM6Ly91cmxwbGF5LmNvbS9OMHJkTEI='
OO0O00 = base64 . b64decode ( oo )
if 20 - 20: OoooooooOO
if 13 - 13: i1IIi - iII111i % OOooOOo / iIii1I11I1II1 % IiII
if 97 - 97: i11iIiiIii
if 32 - 32: I11i11Ii * O0 % OOooOOo % iII111i . I1Ii111
o0OOOOO00o0O0 = 'ǭq�{���}���w���'
if 71 - 71: o00O0oo % IiII / i1
if 49 - 49: i11i % IiII * O0
if 89 - 89: OOooOOo + I11i11Ii
Ii1IOo0o0 = 'filme4k'
III1ii1iII = 'https://i.imgur.com/67UUio3.png'
oo0oooooO0 = 'https://i.imgur.com/Y4QXRab.jpg'
if 19 - 19: Ii1I + o00O0oo
ooo = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0JVYk5CWlFB'
ii1I1i1I = base64 . b64decode ( ooo )
if 88 - 88: i1iIi11iIIi1I + O0 / o0 * IiII
iiiIi1i1I = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0JVYk5CWlFB'
oOO00oOO = base64 . b64decode ( iiiIi1i1I )
if 75 - 75: i1IIi / OoooooooOO - O0 / o0 . i11i - i1IIi
if 71 - 71: I11i + iII111i * I11i - i1iIi11iIIi1I * i1
if 65 - 65: O0 % oOooOoO0Oo0O . ii1IiI1i % iIii1I11I1II1 / I11i % ooOoO0o
if 51 - 51: i11iIiiIii . oOooOoO0Oo0O + i11i
II111ii1II1i = '[COLOR white]Selecione um item:[/COLOR]'
if 59 - 59: O0 + oOooOoO0Oo0O + I1Ii111 % oOooOoO0Oo0O
o0OOoo0OO0OOO = '[COLOR white]!!Download em execução!![/COLOR]'
iI1iI1I1i1I = '!!Download [COLOR seablue]Audio!![/COLOR]'
if 24 - 24: ii1IiI1i
o0Oo0O0Oo00oO = '[COLOR deepskyblue][B] CHECAR POR ATUALIZAÇÃO[/COLOR][/B]'
I11i1I1I = 'https://i.imgur.com/22LSvnr.png'
oO0Oo = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L2E5dE1DMEh1'
oOOoo0Oo = base64 . b64decode ( oO0Oo )
if 78 - 78: Ii1I
if 71 - 71: I11i + o00O0oo % i11iIiiIii + ii1IiI1i - I1Ii111
if 88 - 88: o0 - i1iIi11iIIi1I % I11i
iI1I111Ii111i = 'BEM-VINDOS'
I11IiI1I11i1i = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3F0NmhqV0VY'
iI1ii1Ii = 'https://i.imgur.com/fHRcl7O.png'
oooo000 = 'https://i.imgur.com/Y4QXRab.jpg'
iIIIi1 = base64 . b64decode ( I11IiI1I11i1i )
if 20 - 20: i1IIi + ii1IiI1i - o00O0oo
if 30 - 30: i11i - I11i - i11iIiiIii % o0 - i11i * iII111i
if 61 - 61: OOooOOo - Ii1I % I11i
OOoOO0oo0ooO = '$texto='
if 98 - 98: IiII * IiII / IiII + Ii1I
if 34 - 34: o00O0oo
__addon__ = xbmcaddon . Addon ( )
__addonname__ = __addon__ . getAddonInfo ( 'name' )
__icon__ = __addon__ . getAddonInfo ( 'icon' )
if 15 - 15: Ii1I * o00O0oo * I11i11Ii % i11iIiiIii % o0 - I11i
if 68 - 68: ooOoO0o % i1IIi . I1Ii111 . ii1IiI1i
o0oo0oOo = [ '180upload.com' , 'allmyvideos.net' , 'bestreams.net' , 'clicknupload.com' , 'cloudzilla.to' , 'movshare.net' , 'novamov.com' , 'nowvideo.sx' , 'videoweed.es' , 'daclips.in' , 'datemule.com' , 'fastvideo.in' , 'faststream.in' , 'filehoot.com' , 'filenuke.com' , 'sharesix.com' , 'docs.google.com' , 'plus.google.com' , 'picasaweb.google.com' , 'gorillavid.com' , 'gorillavid.in' , 'grifthost.com' , 'hugefiles.net' , 'ipithos.to' , 'ishared.eu' , 'kingfiles.net' , 'mail.ru' , 'my.mail.ru' , 'videoapi.my.mail.ru' , 'mightyupload.com' , 'mooshare.biz' , 'movdivx.com' , 'movpod.net' , 'movpod.in' , 'movreel.com' , 'mrfile.me' , 'nosvideo.com' , 'openload.io' , 'played.to' , 'bitshare.com' , 'filefactory.com' , 'k2s.cc' , 'oboom.com' , 'rapidgator.net' , 'uploaded.net' , 'primeshare.tv' , 'bitshare.com' , 'filefactory.com' , 'k2s.cc' , 'oboom.com' , 'rapidgator.net' , 'uploaded.net' , 'sharerepo.com' , 'stagevu.com' , 'streamcloud.eu' , 'streamin.to' , 'thefile.me' , 'thevideo.me' , 'tusfiles.net' , 'uploadc.com' , 'zalaa.com' , 'uploadrocket.net' , 'uptobox.com' , 'v-vids.com' , 'veehd.com' , 'vidbull.com' , 'videomega.tv' , 'vidplay.net' , 'vidspot.net' , 'vidto.me' , 'vidzi.tv' , 'vimeo.com' , 'vk.com' , 'vodlocker.com' , 'xfileload.com' , 'xvidstage.com' , 'zettahost.tv' ]
o000O0o = [ 'plugin.video.dramasonline' , 'plugin.video.f4mTester' , 'plugin.video.shahidmbcnet' , 'plugin.video.SportsDevil' , 'plugin.stream.vaughnlive.tv' , 'plugin.video.ZemTV-shani' ]
if 42 - 42: o0
class II ( urllib2 . HTTPErrorProcessor ) :
 def http_response ( self , request , response ) :
  return response
 https_response = http_response
 if 45 - 45: O0 * i1 % I11i11Ii * OoooooooOO + IiII . o0
Oo0ooOo0o = False ;
if Oo0ooOo0o :
 if 22 - 22: iIii1I11I1II1 / i11iIiiIii * iIii1I11I1II1 * i11i . I11i / i11iIiiIii
 if 2 - 2: oOooOoO0Oo0O / O0 / i1 % o0 % iII111i
 try :
  import pysrc . pydevd as pydevd
  if 52 - 52: i1
  pydevd . settrace ( 'localhost' , stdoutToServer = True , stderrToServer = True )
 except ImportError :
  sys . stderr . write ( "Error: " +
 "You must add org.python.pydev.debug.pysrc to your PYTHONPATH." )
  sys . exit ( 1 )
  if 95 - 95: iII111i
  if 87 - 87: o00O0oo + o0 . I11i + o0
oO = xbmcaddon . Addon ( )
iIi1IIIi1 = oO . getAddonInfo ( 'version' )
O0oOoOOOoOO = xbmc . translatePath ( oO . getAddonInfo ( 'profile' ) . decode ( 'utf-8' ) )
ii1ii11IIIiiI = xbmc . translatePath ( oO . getAddonInfo ( 'path' ) . decode ( 'utf-8' ) )
O00OOOoOoo0O = os . path . join ( O0oOoOOOoOO , 'favorites' )
O000OOo00oo = os . path . join ( O0oOoOOOoOO , 'history' )
if 71 - 71: i11iIiiIii + I1Ii111
oOo = os . path . join ( O0oOoOOOoOO , 'list_revision' )
oOO00Oo = os . path . join ( ii1ii11IIIiiI , 'icon.png' )
i1iIIIi1i = os . path . join ( ii1ii11IIIiiI , 'icon_config.png' )
iI1iIIiiii = os . path . join ( ii1ii11IIIiiI , 'favorites.png' )
i1iI11i1ii11 = os . path . join ( ii1ii11IIIiiI , 'fanart.jpg' )
OOooo0O00o = os . path . join ( O0oOoOOOoOO , 'source_file' )
oOOoOooOo = O0oOoOOOoOO
if 51 - 51: Ii1I + IiII % iIii1I11I1II1 / OOooOOo / I11i % OoooooooOO
downloader = downloader . SimpleDownloader ( )
o0O0OOO0Ooo = oO . getSetting ( 'debug' )
if os . path . exists ( O00OOOoOoo0O ) == True :
 iiIiI = open ( O00OOOoOoo0O ) . read ( )
else : iiIiI = [ ]
if os . path . exists ( OOooo0O00o ) == True :
 I1 = open ( OOooo0O00o ) . read ( )
else : I1 = [ ]
if 86 - 86: o0 - iII111i - i1iIi11iIIi1I * IiII
if 66 - 66: OoooooooOO + O0
def I1IiiI ( url ) :
 try :
  import urllib . request as urllib2
 except ImportError :
  import urllib2
 IIi = urllib2 . build_opener ( )
 IIi . addheaders = [ ( 'User-Agent' , 'Mozilla/5.0' ) ]
 if 41 - 41: iII111i - O0 - O0
 oO00OOoO00 = IIi . open ( url )
 IiI111111IIII = oO00OOoO00 . read ( ) . decode ( 'utf-8' )
 i1Ii = IiI111111IIII
 return i1Ii
 if 14 - 14: IiII
def I1iI1iIi111i ( string ) :
 if o0O0OOO0Ooo == 'true' :
  if 44 - 44: i1IIi % i11i + Ii1I
  xbmc . log ( "[APOLLO-%s]: %s" % ( iIi1IIIi1 , string ) )
  if 45 - 45: IiII / IiII + ooOoO0o + o00O0oo
  if 47 - 47: i1 + o00O0oo
  if 82 - 82: i11i . I1Ii111 - iIii1I11I1II1 - I1Ii111 * i11i
  if 77 - 77: iIii1I11I1II1 * i1iIi11iIIi1I
def oOooOo0 ( msg ) :
 i1I1ii11i1Iii = oO . getSetting ( 'suporte' )
 if i1I1ii11i1Iii == 'true' :
  I1IiiiiI ( Oooo0000 , OO0O00 , 44 , III1ii1iII , i1iI11i1ii11 , o0O ( O000oo ) , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
  if 2 - 2: iIii1I11I1II1 / OOooOOo + i1iIi11iIIi1I / I11i
def IIOOOO0oo0 ( msg ) :
 xbmcgui . Dialog ( ) . ok ( '[COLOR deepskyblue][B]"INSTALE PARA ASSISTIR EM 4K!" [/COLOR][/B]' , "[COLOR orange][B]PARA VOCÊ ASSISTIR OS FILMES EM 4K MUITO SIMPLES VCS DEVEM FAZER O DOWNLOAD DO PLUGIN ELEMENTUM NOS LINKS ASEGUIR!. LOGO APOIS TER FEITO O DOWNLOAD VC VÃO EM SITESMA INSTALA POR ZIP E PROCURAR NA PASTA DA SUA BOX OU PC O ZIP PARA INSTALAR NA BOX![/COLOR][/B]" )
 I11iiI1i1 = xbmcgui . Dialog ( )
 I1i1Iiiii = I11iiI1i1 . select ( '[COLOR orange][B]PARA ASSISTIR FILMES EM 4K LINKS ABAIXO![/COLOR][/B]' , [ '[COLOR deepskyblue][B]BAIXAR[/COLOR][/B][COLOR orange][B] ELEMENTUM[/COLOR][/B]' , '[COLOR deepskyblue][B]BAIXAR[/COLOR][/B][COLOR orange][B] ELEMENTUM BURST[/COLOR][/B]' , '' ] )
 if I1i1Iiiii == 0 :
  if xbmc . getCondVisibility ( 'system.platform.android' ) :
   xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://github.com/elgatito/plugin.video.elementum/releases/download/v0.1.52/plugin.video.elementum-0.1.52.zip' ) )
  else :
   webbrowser . open ( 'https://github.com/elgatito/plugin.video.elementum/releases/download/v0.1.52/plugin.video.elementum-0.1.52.zip' )
 if I1i1Iiiii == 1 :
  if xbmc . getCondVisibility ( 'system.platform.android' ) :
   xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://github.com/elgatito/script.elementum.burst/releases/download/v0.0.48/script.elementum.burst-0.0.48.zip' ) )
  else :
   webbrowser . open ( 'https://github.com/elgatito/script.elementum.burst/releases/download/v0.0.48/script.elementum.burst-0.0.48.zip' )
   if 94 - 94: i1 * iII111i / I11i11Ii / iII111i
 if I1i1Iiiii == 5 :
  xbmcaddon . Addon ( ) . openSettings ( )
  if 87 - 87: I11i11Ii . I1Ii111
  xbmc . executebuiltin ( "XBMC.Container.Refresh(%s?mode=None, replace)" % sys . argv [ 0 ] )
  xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
  if 75 - 75: o00O0oo + o0 + i1 * Ii1I % OOooOOo . IiII
def oOI1Ii1I1 ( ) :
 IiII111iI1ii1 = oO . getSetting ( 'username' )
 iI11I1II = oO . getSetting ( 'password' )
 Ii1IIiI1i = oO . getSetting ( 'servidor' )
 o0Oo00 = oO . getSetting ( 'exibirfilme4k' )
 iI = oO . getSetting ( 'saida' )
 if o0Oo00 == 'true' :
  if Ii1IIiI1i == 'filme4k' :
   O0O0Oooo0o = 'http://sv1.iptvcasa.online:25461/get.php?username=%s&password=%s&type=m3u_plus&output=%s' % ( IiII111iI1ii1 , iI11I1II , iI )
   I1IiiiiI ( Ii1IOo0o0 , O0O0Oooo0o , 1 , III1ii1iII , oo0oooooO0 , o0O ( ii1I1i1I ) , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
  if Ii1IIiI1i == 'Nenhum' :
   I1IiiiiI ( Ii1IOo0o0 , '' , 42 , III1ii1iII , oo0oooooO0 , o0O ( ii1I1i1I ) , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
 IiII111iI1ii1 = oO . getSetting ( 'username2' )
 iI11I1II = oO . getSetting ( 'password2' )
 Ii1IIiI1i = oO . getSetting ( 'servidor2' )
 o0Oo00 = oO . getSetting ( 'exibirfilme4k2' )
 iI = oO . getSetting ( 'saida2' )
 if o0Oo00 == 'true' :
  if Ii1IIiI1i == 'filme4k' :
   O0O0Oooo0o = 'http://cloudsteam.club:8080/get.php?username=%s&password=%s&type=m3u_plus&output=%s' % ( IiII111iI1ii1 , iI11I1II , iI )
   I1IiiiiI ( titulo_filme4k2 , O0O0Oooo0o , 1 , thumbnail_filme4k2 , oo0oooooO0 , o0O ( ii1I1i1I ) , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
  if Ii1IIiI1i == 'Nenhum' :
   I1IiiiiI ( titulo_filme4k2 , '' , 42 , thumbnail_filme4k2 , fanart_filme4k2 , o0O ( ii1I1i1I ) , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
   if 56 - 56: ii1IiI1i % O0 - oOooOoO0Oo0O
def O00o0OO0 ( msg ) :
 IIi1I1iiiii = oO . getSetting ( 'mensagem1' )
 if IIi1I1iiiii == 'true' :
  I11iiI1i1 = xbmcgui . Dialog ( )
  I1i1Iiiii = I11iiI1i1 . select ( '[COLOR orange][B]AJUDE O ADD-ON FAÇA SUA[/COLOR][/B][COLOR deepskyblue][B] DOAÇÃO[/COLOR][/B]' , [ '[COLOR deepskyblue][B]APOLLO ->[/COLOR][/B][COLOR orange][B] SITE OFICIAL![/COLOR][/B]' , '[COLOR deepskyblue][B]AJUDE ->[/COLOR][/B][COLOR orange][B] DOAÇÃO PELO[/COLOR][/B][COLOR lightcyan][B] MERCADO[/COLOR][/B][COLOR dodgerblue][B]PAGO [/COLOR][/B]' , '[COLOR deepskyblue][B]AJUDE ->[/COLOR][/B][COLOR orange][B] DOAÇÃO PELO[/COLOR][/B][COLOR blueviolet][B] NUBANK[/COLOR][/B]' , '[COLOR deepskyblue][B]AJUDE ->[/COLOR][/B][COLOR orange][B] DOAÇÃO PELO[/COLOR][/B][COLOR lightcyan][B] PIC[/COLOR][/B][COLOR lime][B]PAY [/COLOR][/B]' , '[COLOR deepskyblue][B]AJUDE ->[/COLOR][/B][COLOR orange][B] DOAÇÃO PELO[/COLOR][/B][COLOR royalblue][B] PAY[/COLOR][/B][COLOR lightcyan][B]PAL [/COLOR][/B]' , '[COLOR deepskyblue][B]APOLLO ->[/COLOR][/B][COLOR orange][B] GRUPO TELEGRAM[/COLOR][/B]' , '[COLOR deepskyblue][B]APOLLO ->[/COLOR][/B][COLOR orange][B] GRUPO FACEBOOK[/COLOR][/B]' , '[COLOR deepskyblue][B]ENTRAR NO[/COLOR][/B][COLOR orange][B] ADD-ON[/COLOR][/B]' , '[COLOR deepskyblue][B]SAIR DO[/COLOR][/B][COLOR orange][B] ADD-ON[/COLOR][/B]' ] )
  if 71 - 71: I1Ii111 * i11i * OOooOOo
  if I1i1Iiiii == 0 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://deus-apollo.ml' ) )
   else :
    webbrowser . open ( 'http://deus-apollo.ml' )
    if 56 - 56: oOooOoO0Oo0O
    if 54 - 54: ooOoO0o / I11i . OOooOOo % IiII
  if I1i1Iiiii == 1 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.mercadopago.com.br/checkout/v1/redirect?pref_id=203668628-f9a8d299-8b36-4cbd-84f4-0eb34ed0be11' ) )
   else :
    webbrowser . open ( 'https://www.mercadopago.com.br/checkout/v1/redirect?pref_id=203668628-f9a8d299-8b36-4cbd-84f4-0eb34ed0be11' )
    if 57 - 57: i11iIiiIii . ii1IiI1i - iII111i - OOooOOo + o0
  if I1i1Iiiii == 2 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://nubank.com.br/pagar/1djpv6/FJzleug9nF' ) )
   else :
    webbrowser . open ( 'https://nubank.com.br/pagar/1djpv6/FJzleug9nF' )
    if 63 - 63: o0 * IiII
    if 69 - 69: O0 . i1iIi11iIIi1I
  if I1i1Iiiii == 3 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://picpay.me/deus.apollo' ) )
   else :
    webbrowser . open ( 'https://picpay.me/deus.apollo' )
    if 49 - 49: oOooOoO0Oo0O - Ii1I
    if 74 - 74: iIii1I11I1II1 * ii1IiI1i + o0 / i1IIi / i11i . I11i11Ii
  if I1i1Iiiii == 4 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=44A92DUKBAKAN&source=url' ) )
   else :
    webbrowser . open ( 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=44A92DUKBAKAN&source=url' )
    if 62 - 62: OoooooooOO * oOooOoO0Oo0O
    if 58 - 58: o0 % i1
    if 50 - 50: ooOoO0o . i1
  if I1i1Iiiii == 5 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://telegram.me/DeusApollo' ) )
   else :
    webbrowser . open ( 'http://telegram.me/DeusApollo' )
    if 97 - 97: O0 + o0
  if I1i1Iiiii == 6 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.facebook.com/groups/Deus.Apollo' ) )
   else :
    webbrowser . open ( 'https://www.facebook.com/groups/Deus.Apollo' )
    if 89 - 89: i1 + i1iIi11iIIi1I * Ii1I * iII111i
  if I1i1Iiiii == 8 :
   xbmc . executebuiltin ( "XBMC.Container.Refresh('close()')" )
   xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
   if 37 - 37: OoooooooOO - O0 - i1
def o0o0O0O00oOOo ( msg ) :
 I1IiiiiI ( o00 , OO0O00 , 1 , oOO00Oo , i1iI11i1ii11 , o0O ( oO0o0o0ooO0oO ) , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
 oOooOo0 ( True )
 oOI1Ii1I1 ( )
 if 14 - 14: o0 + OOooOOo
 oo00oO0O0 ( IIII , '' )
 I1IiiiiI ( o0Oo0O0Oo00oO , '' , 54 , I11i1I1I , i1iI11i1ii11 , o0O ( oOOoo0Oo ) , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
 if 30 - 30: I11i + ii1IiI1i * Ii1I % i11iIiiIii % o0
 OO0OoOO0o0o ( )
 O00o0OO0 ( True )
 if 95 - 95: i11iIiiIii
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 32 - 32: I11i
 if 42 - 42: I1Ii111 * O0 % i1IIi . I11i / i1
def iII11I1IiiIi ( msg ) :
 try :
  oo0oO = urllib2 . urlopen ( "https://github.com/Tiagotj/repo.apollo/raw/master/plugin.video.apollo/version.txt" ) . read ( ) . replace ( '' , '' ) . replace ( '\r' , '' )
  oo0oO = re . compile ( '[a-zA-Z\.\d]+' ) . findall ( oo0oO ) [ 0 ]
  if 94 - 94: iIii1I11I1II1 / I11i11Ii % IiII * IiII * i11i
  if oo0oO != Oo :
   IIiIiI ( )
   if 94 - 94: OOooOOo . i1IIi - i1 % O0 - i1iIi11iIIi1I
  elif msg == True :
   if 72 - 72: iII111i
   O00o0OO0 ( True )
   if 1 - 1: i1iIi11iIIi1I * I1Ii111 * OoooooooOO + o00O0oo
 except urllib2 . URLError , IiII111i1i11 :
  if msg == True :
   xbmcgui . Dialog ( ) . ok ( 'Apollo' , "Não foi possível checar" )
   if 40 - 40: o00O0oo * I1Ii111 * i11iIiiIii
def oo0OO00OoooOo ( msg ) :
 try :
  oo0oO = urllib2 . urlopen ( "https://github.com/Tiagotj/repo.apollo/raw/master/plugin.video.apollo/version.txt" ) . read ( ) . replace ( '' , '' ) . replace ( '\r' , '' )
  oo0oO = re . compile ( '[a-zA-Z\.\d]+' ) . findall ( oo0oO ) [ 0 ]
  if 19 - 19: ii1IiI1i % OoooooooOO % I1Ii111 * i1 % O0
  if oo0oO != Oo :
   IIiIiI ( )
   if 67 - 67: oOooOoO0Oo0O . i1IIi
  elif msg == True :
   xbmcgui . Dialog ( ) . ok ( '[COLOR orange][B]APOLLO[/COLOR][/B]' , "[COLOR deepskyblue][B] O ADD-ON JÁ ESTÁ NA ÚLTIMA VERSÃO![/COLOR][/B][COLOR orange][B] 1.4.5[/COLOR][/B] " + Oo + "[COLOR deepskyblue][B] ATUALIZAÇÕES SÃO AUTOMÁTICAS SE NÃO ATUALIZA ENTRE NO SITE[/COLOR][/B][COLOR orange][B] http://deus-apollo.ml[/COLOR][/B]" )
   if 27 - 27: o00O0oo % oOooOoO0Oo0O
 except urllib2 . URLError , IiII111i1i11 :
  if msg == True :
   xbmcgui . Dialog ( ) . ok ( 'Apollo' , "Não foi possível checar" )
   if 73 - 73: I11i
   if 70 - 70: iIii1I11I1II1
def IIiIiI ( ) :
 i11ii1iI = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 try :
  i1I = urllib2 . urlopen ( "https://github.com/Tiagotj/repo.apollo/raw/master/plugin.video.apollo/apollo.py" ) . read ( ) . replace ( '' , '' )
  IIIii11 = re . compile ( 'checkintegrity' ) . findall ( i1I )
  if IIIii11 :
   iiIiIIIiiI = os . path . join ( i11ii1iI , "apollo.py" )
   file = open ( iiIiIIIiiI , "w" )
   file . write ( i1I )
   file . close ( )
  i1I = urllib2 . urlopen ( "https://github.com/Tiagotj/repo.apollo/raw/master/plugin.video.apollo/resources/settings.xml" ) . read ( ) . replace ( '' , '' )
  IIIii11 = re . compile ( '</settings>' ) . findall ( i1I )
  if IIIii11 :
   iiIiIIIiiI = os . path . join ( i11ii1iI , "resources/settings.xml" )
   file = open ( iiIiIIIiiI , "w" )
   file . write ( i1I )
   file . close ( )
  i1I = urllib2 . urlopen ( "https://github.com/Tiagotj/repo.apollo/raw/master/plugin.video.apollo/addon.xml" ) . read ( ) . replace ( '' , '' )
  IIIii11 = re . compile ( '</addon>' ) . findall ( i1I )
  if IIIii11 :
   iiIiIIIiiI = os . path . join ( i11ii1iI , "addon.xml" )
   file = open ( iiIiIIIiiI , "w" )
   file . write ( i1I )
   file . close ( )
  xbmcgui . Dialog ( ) . ok ( '[COLOR deepskyblue][B]APOLLO[/COLOR][/B]' , "OBS: ADD-ON ESTÁ DESATUALIZADO! CLIQUE EM OK PARA ELE SE ALTO ATUALIZAR! CASO O ADD-ON NÃO SE ATUALIZE FAÇA O DOWNLOAD NO SITE OFICIAL! [COLOR deepskyblue][B]->[/COLOR][/B][COLOR orange][COLOR orange][B] https://deus-apollo.ml[/COLOR][/B]" ) . xbmc . executebuiltin
 except :
  xbmc . executebuiltin ( "Notification({0}, {1}, 9000, {2})" . format ( __addonname__ , "[COLOR orange][B]Atualizando o addon. Por favor aguarde 5 segundos e Pode Continuar![/COLOR][/B]" , __icon__ ) )
 xbmc . executebuiltin ( "XBMC.Container.Refresh()" )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 12 - 12: O0 - i1
oo0OO00OoooOo ( False )
if 81 - 81: o0 - o0 . IiII
def o0OoOo00o0o ( ) :
 I1II1I11I1I = {
 "Accept-Language" : "en-US,en;q=0.5" ,
 "Accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" ,
 "Referer" : "APOLLO 1.4.5" ,
 "Connection" : "keep-alive"
 }
 OoOO0o = urllib2 . Request ( "https://whos.amung.us/pingjs/?k=c4302b" , headers = I1II1I11I1I )
 oO00OOoO00 = urllib2 . urlopen ( OoOO0o ) . read ( )
 if 1 - 1: i11i
 if 68 - 68: IiII - oOooOoO0Oo0O / ooOoO0o / Ii1I
o0OoOo00o0o ( )
if 12 - 12: iII111i + i11iIiiIii * iIii1I11I1II1 / ii1IiI1i . Ii1I
def Iii1iI ( url , headers = None ) :
 try :
  if headers is None :
   if 29 - 29: oOooOoO0Oo0O % I11i - oOooOoO0Oo0O / I11i . i1IIi
   headers = { 'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0' }
   headers = { 'User-agent' : '�}q�|{�\�~1�|{�\�}�ߜ{�\Ǯqߌ{�\�~q߼{�\�~�߬{�\ǭq߼{�\ǭ�ߌ{�\�~�߼{�\�}�ߌ{�\�1ߜ{�\�qߜ{�' }
  i11III1111iIi = urllib2 . Request ( url , None , headers )
  oO00OOoO00 = urllib2 . urlopen ( i11III1111iIi )
  IiI111111IIII = oO00OOoO00 . read ( )
  oO00OOoO00 . close ( )
  return IiI111111IIII
 except urllib2 . URLError , IiII111i1i11 :
  I1iI1iIi111i ( 'URL: ' + url )
  if hasattr ( IiII111i1i11 , 'code' ) :
   I1iI1iIi111i ( 'Falha com o código de erro - %s.' % IiII111i1i11 . code )
   if 38 - 38: IiII + Ii1I / ooOoO0o % o00O0oo - ii1IiI1i
   if 14 - 14: OOooOOo / ooOoO0o
   xbmc . executebuiltin ( "XBMC.Notification(Falha, código de erro - " + str ( IiII111i1i11 . code ) + ",10000," + oOO00Oo + ")" )
  elif hasattr ( IiII111i1i11 , 'reason' ) :
   I1iI1iIi111i ( 'Falha ao acessar um servidor.' )
   I1iI1iIi111i ( 'Razão: %s' % IiII111i1i11 . reason )
   if 85 - 85: Ii1I
   xbmc . executebuiltin ( "XBMC.Notification(Falha, motivo - " + str ( IiII111i1i11 . reason ) + ",10000," + oOO00Oo + ")" )
   if 20 - 20: OOooOOo % I1Ii111
def o0O ( url ) :
 IIi = urllib2 . build_opener ( )
 if 19 - 19: ii1IiI1i % I1Ii111 + o00O0oo / ooOoO0o . o00O0oo
 IIi . addheaders = [ ( 'User-Agent' , o0OOOOO00o0O0 ) ]
 oO00OOoO00 = IIi . open ( url )
 IiIi1I1 = oO00OOoO00 . read ( )
 return IiIi1I1
 if 39 - 39: i11i + o0 - o00O0oo . o0
 if 84 - 84: i1iIi11iIIi1I + i1IIi - i11i . ii1IiI1i * OoooooooOO + oOooOoO0Oo0O
def OO0OoOO0o0o ( ) :
 II1i11I = oO . getSetting ( 'mensagem2' )
 if II1i11I == 'true' :
  IIi = urllib2 . build_opener ( )
  if 50 - 50: OoooooooOO % Ii1I
  IIi . addheaders = [ ( 'User-Agent' , o0OOOOO00o0O0 ) ]
  if 49 - 49: OOooOOo - i11iIiiIii . ooOoO0o * iII111i % IiII + i1IIi
  oO00OOoO00 = IIi . open ( OO0O0O00OooO )
  oOO0OOOo = oO00OOoO00 . read ( )
  if 56 - 56: i1
  time = IiI1I1
  xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , oOO0OOOo , time , __icon__ ) )
  if 28 - 28: IiII . IiII % iIii1I11I1II1 * iIii1I11I1II1 . i1 / IiII
  if 27 - 27: i1iIi11iIIi1I + o00O0oo - i1IIi
def O00oOOooo ( ) :
 xbmc . executebuiltin ( "XBMC.Container.Refresh()" )
 if 50 - 50: ii1IiI1i % O0 * i1
def i1Iii11Ii1i1 ( ) :
 if os . path . exists ( O00OOOoOoo0O ) == True :
  I1IiiiiI ( 'Favorites' , 'url' , 4 , os . path . join ( ii1ii11IIIiiI , 'resources' , 'favorite.png' ) , i1iI11i1ii11 , '' , '' , '' , '' )
 if oO . getSetting ( "browse_xml_database" ) == "true" :
  I1IiiiiI ( 'XML Database' , 'http://xbmcplus.xb.funpic.de/www-data/filesystem/' , 15 , oOO00Oo , i1iI11i1ii11 , '' , '' , '' , '' )
 if oO . getSetting ( "browse_community" ) == "true" :
  I1IiiiiI ( 'Community Files' , 'community_files' , 16 , oOO00Oo , i1iI11i1ii11 , '' , '' , '' , '' )
 if os . path . exists ( O000OOo00oo ) == True :
  I1IiiiiI ( 'Search History' , 'history' , 25 , os . path . join ( ii1ii11IIIiiI , 'resources' , 'favorite.png' ) , i1iI11i1ii11 , '' , '' , '' , '' )
 if oO . getSetting ( "searchyt" ) == "true" :
  I1IiiiiI ( 'Search:Youtube' , 'youtube' , 25 , oOO00Oo , i1iI11i1ii11 , '' , '' , '' , '' )
 if oO . getSetting ( "searchDM" ) == "true" :
  I1IiiiiI ( 'Search:dailymotion' , 'dmotion' , 25 , oOO00Oo , i1iI11i1ii11 , '' , '' , '' , '' )
 if oO . getSetting ( "PulsarM" ) == "true" :
  I1IiiiiI ( 'Pulsar:IMDB' , 'IMDBidplay' , 27 , oOO00Oo , i1iI11i1ii11 , '' , '' , '' , '' )
  if os . path . exists ( OOooo0O00o ) == True :
   OOooo0O0o0 = json . loads ( open ( OOooo0O00o , "r" ) . read ( ) )
   if 14 - 14: i1 % O0 * IiII + iII111i + I11i11Ii * iII111i
  if len ( OOooo0O0o0 ) > 1 :
   for iII1I1IiI11ii in OOooo0O0o0 :
    if 72 - 72: oOooOoO0Oo0O % i11iIiiIii . I11i11Ii / i11i
    if isinstance ( iII1I1IiI11ii , list ) :
     I1IiiiiI ( iII1I1IiI11ii [ 0 ] . encode ( 'utf-8' ) , iII1I1IiI11ii [ 1 ] . encode ( 'utf-8' ) , 1 , oOO00Oo , i1iI11i1ii11 , '' , '' , '' , '' , 'source' )
    else :
     iIIiIiI = oOO00Oo
     iIi11 = i1iI11i1ii11
     OOoo = ''
     iIIiiiI = ''
     credits = ''
     oo0 = ''
     IiI111ii1ii = ''
     O0OOo = ''
     IiIII1 = ''
     O0Oo000 = ''
     iiI11i1II = ''
     OO0O0OOo0O = ''
     I1o0OooOOOOOO = ''
     OOooO0o0 = ''
     iiIII1i = ''
     I1I = ''
     ooooO0oOoOOoO = ''
     if iII1I1IiI11ii . has_key ( 'thumbnail' ) :
      iIIiIiI = iII1I1IiI11ii [ 'thumbnail' ]
     if iII1I1IiI11ii . has_key ( 'fanart' ) :
      iIi11 = iII1I1IiI11ii [ 'fanart' ]
     if iII1I1IiI11ii . has_key ( 'description' ) :
      OOoo = iII1I1IiI11ii [ 'description' ]
     if iII1I1IiI11ii . has_key ( 'date' ) :
      iIIiiiI = iII1I1IiI11ii [ 'date' ]
     if iII1I1IiI11ii . has_key ( 'genre' ) :
      I1i11i = iII1I1IiI11ii [ 'genre' ]
     if iII1I1IiI11ii . has_key ( 'credits' ) :
      credits = iII1I1IiI11ii [ 'credits' ]
     if iII1I1IiI11ii . has_key ( 'year' ) :
      oo0 = iII1I1IiI11ii [ 'year' ]
     if iII1I1IiI11ii . has_key ( 'director' ) :
      IiI111ii1ii = iII1I1IiI11ii [ 'director' ]
     if iII1I1IiI11ii . has_key ( 'duration' ) :
      O0OOo = iII1I1IiI11ii [ 'duration' ]
     if iII1I1IiI11ii . has_key ( 'premiered' ) :
      IiIII1 = iII1I1IiI11ii [ 'premiered' ]
     if iII1I1IiI11ii . has_key ( 'studio' ) :
      O0Oo000 = iII1I1IiI11ii [ 'studio' ]
     if iII1I1IiI11ii . has_key ( 'rate' ) :
      iiI11i1II = iII1I1IiI11ii [ 'rate' ]
     if iII1I1IiI11ii . has_key ( 'originaltitle' ) :
      OO0O0OOo0O = iII1I1IiI11ii [ 'originaltitle' ]
     if iII1I1IiI11ii . has_key ( 'country' ) :
      I1o0OooOOOOOO = iII1I1IiI11ii [ 'country' ]
     if iII1I1IiI11ii . has_key ( 'rating' ) :
      OOooO0o0 = iII1I1IiI11ii [ 'rating' ]
     if iII1I1IiI11ii . has_key ( 'userrating' ) :
      iiIII1i = iII1I1IiI11ii [ 'userrating' ]
     if iII1I1IiI11ii . has_key ( 'votes' ) :
      I1I = iII1I1IiI11ii [ 'votes' ]
     if iII1I1IiI11ii . has_key ( 'aired' ) :
      ooooO0oOoOOoO = iII1I1IiI11ii [ 'aired' ]
     I1IiiiiI ( iII1I1IiI11ii [ 'title' ] . encode ( 'utf-8' ) , iII1I1IiI11ii [ 'url' ] . encode ( 'utf-8' ) , 1 , iIIiIiI , iIi11 , OOoo , I1i11i , iIIiiiI , credits , oo0 , IiI111ii1ii , O0OOo , IiIII1 , O0Oo000 , iiI11i1II , OO0O0OOo0O , I1o0OooOOOOOO , OOooO0o0 , iiIII1i , I1I , ooooO0oOoOOoO , 'source' )
     if 11 - 11: oOooOoO0Oo0O / i11i + i1 * ii1IiI1i - ii1IiI1i - oOooOoO0Oo0O
  else :
   if len ( OOooo0O0o0 ) == 1 :
    if isinstance ( OOooo0O0o0 [ 0 ] , list ) :
     oo00oO0O0 ( OOooo0O0o0 [ 0 ] [ 1 ] . encode ( 'utf-8' ) , i1iI11i1ii11 )
    else :
     oo00oO0O0 ( OOooo0O0o0 [ 0 ] [ 'url' ] , OOooo0O0o0 [ 0 ] [ 'fanart' ] )
     if 85 - 85: Ii1I % OOooOOo / iIii1I11I1II1 . iIii1I11I1II1
     if 31 - 31: i1 % i1iIi11iIIi1I
def iI1I ( url = None ) :
 if url is None :
  if not oO . getSetting ( "new_file_source" ) == "" :
   OooOoOo = oO . getSetting ( 'new_file_source' ) . decode ( 'utf-8' )
  elif not oO . getSetting ( "new_url_source" ) == "" :
   OooOoOo = oO . getSetting ( 'new_url_source' ) . decode ( 'utf-8' )
 else :
  OooOoOo = url
 if OooOoOo == '' or OooOoOo is None :
  return
 I1iI1iIi111i ( 'Adding New Source: ' + OooOoOo . encode ( 'utf-8' ) )
 if 14 - 14: i1 * I11i + IiII + O0 + i11iIiiIii
 oOoO0 = None
 if 77 - 77: iIii1I11I1II1 . IiII % IiII + i11iIiiIii
 IiI111111IIII = Oo00o0OO0O00o ( OooOoOo )
 print 'source_url' , OooOoOo
 if isinstance ( IiI111111IIII , BeautifulSOAP ) :
  if IiI111111IIII . find ( 'channels_info' ) :
   oOoO0 = IiI111111IIII . channels_info
  elif IiI111111IIII . find ( 'items_info' ) :
   oOoO0 = IiI111111IIII . items_info
 if oOoO0 :
  O0Oooo = { }
  O0Oooo [ 'url' ] = OooOoOo
  try : O0Oooo [ 'title' ] = oOoO0 . title . string
  except : pass
  try : O0Oooo [ 'thumbnail' ] = oOoO0 . thumbnail . string
  except : pass
  try : O0Oooo [ 'fanart' ] = oOoO0 . fanart . string
  except : pass
  try : O0Oooo [ 'genre' ] = oOoO0 . genre . string
  except : pass
  try : O0Oooo [ 'description' ] = oOoO0 . description . string
  except : pass
  try : O0Oooo [ 'date' ] = oOoO0 . date . string
  except : pass
  try : O0Oooo [ 'credits' ] = oOoO0 . credits . string
  except : pass
  try : O0Oooo [ 'year' ] = oOoO0 . year . string
  except : pass
  try : O0Oooo [ 'director' ] = oOoO0 . director . string
  except : pass
  try : O0Oooo [ 'premiered' ] = oOoO0 . premiered . string
  except : pass
  try : O0Oooo [ 'studio' ] = oOoO0 . studio . string
  except : pass
  try : O0Oooo [ 'rate' ] = oOoO0 . rate . string
  except : pass
  try : O0Oooo [ 'originaltitle' ] = oOoO0 . originaltitle . string
  except : pass
  try : O0Oooo [ 'country' ] = oOoO0 . country . string
  except : pass
  try : O0Oooo [ 'rating' ] = oOoO0 . rating . string
  except : pass
  try : O0Oooo [ 'userrating' ] = oOoO0 . userrating . string
  except : pass
  try : O0Oooo [ 'votes' ] = oOoO0 . votes . string
  except : pass
  try : O0Oooo [ 'aired' ] = oOoO0 . aired . string
  except : pass
 else :
  if '/' in OooOoOo :
   iiIi1i = OooOoOo . split ( '/' ) [ - 1 ] . split ( '.' ) [ 0 ]
  if '\\' in OooOoOo :
   iiIi1i = OooOoOo . split ( '\\' ) [ - 1 ] . split ( '.' ) [ 0 ]
  if '%' in iiIi1i :
   iiIi1i = urllib . unquote_plus ( iiIi1i )
  I1i11111i1i11 = xbmc . Keyboard ( iiIi1i , 'Displayed Name, Rename?' )
  I1i11111i1i11 . doModal ( )
  if ( I1i11111i1i11 . isConfirmed ( ) == False ) :
   return
  OOoOOO0 = I1i11111i1i11 . getText ( )
  if len ( OOoOOO0 ) == 0 :
   return
  O0Oooo = { }
  O0Oooo [ 'title' ] = OOoOOO0
  O0Oooo [ 'url' ] = OooOoOo
  O0Oooo [ 'fanart' ] = iIi11
  if 10 - 10: ooOoO0o / o00O0oo + i11iIiiIii / iII111i
 if os . path . exists ( OOooo0O00o ) == False :
  OOOoOoO = [ ]
  OOOoOoO . append ( O0Oooo )
  iIIIII1ii1I = open ( OOooo0O00o , "w" )
  iIIIII1ii1I . write ( json . dumps ( OOOoOoO ) )
  iIIIII1ii1I . close ( )
 else :
  OOooo0O0o0 = json . loads ( open ( OOooo0O00o , "r" ) . read ( ) )
  OOooo0O0o0 . append ( O0Oooo )
  iIIIII1ii1I = open ( OOooo0O00o , "w" )
  iIIIII1ii1I . write ( json . dumps ( OOooo0O0o0 ) )
  iIIIII1ii1I . close ( )
 oO . setSetting ( 'new_url_source' , "" )
 oO . setSetting ( 'new_file_source' , "" )
 if 13 - 13: i11iIiiIii + i1IIi * iIii1I11I1II1 % OoooooooOO - i11i * I11i
 xbmc . executebuiltin ( "XBMC.Notification(New source added.,5000," + oOO00Oo + ")" )
 if not url is None :
  if 'xbmcplus.xb.funpic.de' in url :
   xbmc . executebuiltin ( "XBMC.Container.Update(%s?mode=14,replace)" % sys . argv [ 0 ] )
  elif 'community-links' in url :
   xbmc . executebuiltin ( "XBMC.Container.Update(%s?mode=10,replace)" % sys . argv [ 0 ] )
 else : oO . openSettings ( )
 if 26 - 26: OoooooooOO * oOooOoO0Oo0O + I11i
 if 24 - 24: i11iIiiIii % iIii1I11I1II1 + I11i / i11iIiiIii
def OOooO0oo0o00o ( name ) :
 OOooo0O0o0 = json . loads ( open ( OOooo0O00o , "r" ) . read ( ) )
 for ooOO0OoO in range ( len ( OOooo0O0o0 ) ) :
  if isinstance ( OOooo0O0o0 [ ooOO0OoO ] , list ) :
   if OOooo0O0o0 [ ooOO0OoO ] [ 0 ] == name :
    del OOooo0O0o0 [ ooOO0OoO ]
    iIIIII1ii1I = open ( OOooo0O00o , "w" )
    iIIIII1ii1I . write ( json . dumps ( OOooo0O0o0 ) )
    iIIIII1ii1I . close ( )
    break
  else :
   if OOooo0O0o0 [ ooOO0OoO ] [ 'title' ] == name :
    del OOooo0O0o0 [ ooOO0OoO ]
    iIIIII1ii1I = open ( OOooo0O00o , "w" )
    iIIIII1ii1I . write ( json . dumps ( OOooo0O0o0 ) )
    iIIIII1ii1I . close ( )
    break
 xbmc . executebuiltin ( "XBMC.Container.Refresh" )
 if 69 - 69: iIii1I11I1II1 . ii1IiI1i % o00O0oo + iIii1I11I1II1 / O0 / ii1IiI1i
 if 61 - 61: I11i % I11i * i1 / i1
 if 75 - 75: I1Ii111 . o00O0oo
def iII111iO0000o ( url , browse = False ) :
 if url is None :
  url = 'http://xbmcplus.xb.funpic.de/www-data/filesystem/'
 ii = BeautifulSoup ( Iii1iI ( url ) , convertEntities = BeautifulSoup . HTML_ENTITIES )
 for iII1I1IiI11ii in ii ( 'a' ) :
  OOO0oOOoo = iII1I1IiI11ii [ 'href' ]
  if not OOO0oOOoo . startswith ( '?' ) :
   oOOO00o000o = iII1I1IiI11ii . string
   if oOOO00o000o not in [ 'Parent Directory' , 'recycle_bin/' ] :
    if OOO0oOOoo . endswith ( '/' ) :
     if browse :
      I1IiiiiI ( oOOO00o000o , url + OOO0oOOoo , 15 , oOO00Oo , iIi11 , '' , '' , '' )
     else :
      I1IiiiiI ( oOOO00o000o , url + OOO0oOOoo , 14 , oOO00Oo , iIi11 , '' , '' , '' )
    elif OOO0oOOoo . endswith ( '.xml' ) :
     if browse :
      I1IiiiiI ( oOOO00o000o , url + OOO0oOOoo , 1 , oOO00Oo , iIi11 , '' , '' , '' , '' , 'download' )
     else :
      if os . path . exists ( OOooo0O00o ) == True :
       if oOOO00o000o in I1 :
        I1IiiiiI ( oOOO00o000o + ' (in use)' , url + OOO0oOOoo , 11 , oOO00Oo , iIi11 , '' , '' , '' , '' , 'download' )
       else :
        I1IiiiiI ( oOOO00o000o , url + OOO0oOOoo , 11 , oOO00Oo , iIi11 , '' , '' , '' , '' , 'download' )
      else :
       I1IiiiiI ( oOOO00o000o , url + OOO0oOOoo , 11 , oOO00Oo , iIi11 , '' , '' , '' , '' , 'download' )
       if 9 - 9: OOooOOo + Ii1I / Ii1I
       if 12 - 12: OoooooooOO % i1 * Ii1I % iIii1I11I1II1 / iII111i
def Ii1ii1IiIII ( browse = False ) :
 O0O0Oooo0o = 'http://community-links.googlecode.com/svn/trunk/'
 ii = BeautifulSoup ( Iii1iI ( O0O0Oooo0o ) , convertEntities = BeautifulSoup . HTML_ENTITIES )
 ooO0o = ii ( 'ul' ) [ 0 ] ( 'li' ) [ 1 : ]
 for iII1I1IiI11ii in ooO0o :
  oOOO00o000o = iII1I1IiI11ii ( 'a' ) [ 0 ] [ 'href' ]
  if browse :
   I1IiiiiI ( oOOO00o000o , O0O0Oooo0o + oOOO00o000o , 1 , oOO00Oo , iIi11 , '' , '' , '' , '' , 'download' )
  else :
   I1IiiiiI ( oOOO00o000o , O0O0Oooo0o + oOOO00o000o , 11 , oOO00Oo , iIi11 , '' , '' , '' , '' , 'download' )
   if 51 - 51: I1Ii111
   if 25 - 25: OoooooooOO + I1Ii111 * ii1IiI1i
def Oo00o0OO0O00o ( url , data = None ) :
 global o0OO00 , iI1
 iI1 = False
 if url . startswith ( 'http://' ) or url . startswith ( 'https://' ) :
  OoO0ooO = False
  if '$$TSDOWNLOADER$$' in url :
   iI1 = True
   url = url . replace ( "$$TSDOWNLOADER$$" , "" )
  if '$$LSProEncKey=' in url :
   OoO0ooO = url . split ( '$$LSProEncKey=' ) [ 1 ] . split ( '$$' ) [ 0 ]
   O000 = '$$LSProEncKey=%s$$' % OoO0ooO
   url = url . replace ( O000 , "" )
  try :
   data = base64 . b32decode ( Iii1iI ( url ) [ : : - 1 ] ) . decode ( 'utf-8' )
  except :
   data = Iii1iI ( url )
  if OoO0ooO :
   import pyaes
   OoO0ooO = OoO0ooO . encode ( "ascii" )
   print OoO0ooO
   i1iIi = 16 - len ( OoO0ooO )
   OoO0ooO = OoO0ooO + ( chr ( 0 ) * ( i1iIi ) )
   print repr ( OoO0ooO )
   data = base64 . b64decode ( data )
   IIIII = pyaes . new ( OoO0ooO , pyaes . MODE_ECB , IV = None )
   data = IIIII . decrypt ( data ) . split ( '\0' ) [ 0 ]
   if 78 - 78: iII111i * i1IIi
  if re . search ( "#EXTM3U" , data ) or 'm3u' in url :
   if 1 - 1: oOooOoO0Oo0O / I1Ii111 * o00O0oo
   return data
 elif data == None :
  if not '/' in url or not '\\' in url :
   if 1 - 1: Ii1I * i1 . o0 / O0
   url = os . path . join ( communityfiles , url )
  if xbmcvfs . exists ( url ) :
   if url . startswith ( "smb://" ) or url . startswith ( "nfs://" ) :
    O00 = xbmcvfs . copy ( url , os . path . join ( O0oOoOOOoOO , 'temp' , 'sorce_temp.txt' ) )
    if O00 :
     data = open ( os . path . join ( O0oOoOOOoOO , 'temp' , 'sorce_temp.txt' ) , "r" ) . read ( )
     xbmcvfs . delete ( os . path . join ( O0oOoOOOoOO , 'temp' , 'sorce_temp.txt' ) )
    else :
     I1iI1iIi111i ( "failed to copy from smb:" )
   else :
    data = open ( url , 'r' ) . read ( )
    if re . match ( "#EXTM3U" , data ) or 'm3u' in url :
     if 52 - 52: o00O0oo + O0 . IiII . ii1IiI1i . i1iIi11iIIi1I
     return data
  else :
   I1iI1iIi111i ( "Soup Data not found!" )
   return
 if '<SetViewMode>' in data :
  try :
   o0OO00 = re . findall ( '<SetViewMode>(.*?)<' , data ) [ 0 ]
   xbmc . executebuiltin ( "Container.SetViewMode(%s)" % o0OO00 )
   print 'done setview' , o0OO00
  except : pass
 return BeautifulSOAP ( data , convertEntities = BeautifulStoneSoup . XML_ENTITIES )
 if 97 - 97: oOooOoO0Oo0O / IiII
 if 71 - 71: i11i / i1IIi . ii1IiI1i % OoooooooOO . o0
def oo00oO0O0 ( url , fanart , data = None ) :
 if 41 - 41: i1IIi * i11i / OoooooooOO . I11i
 O0iII1 = "List"
 if 27 - 27: i1iIi11iIIi1I . Ii1I + o0 / iIii1I11I1II1 % IiII . o00O0oo
 ii = Oo00o0OO0O00o ( url , data )
 if 14 - 14: OOooOOo + ii1IiI1i - IiII / O0 . ooOoO0o
 if isinstance ( ii , BeautifulSOAP ) :
  if len ( ii ( 'layoutype' ) ) > 0 :
   O0iII1 = "thumbnail"
   if 45 - 45: ooOoO0o
  if len ( ii ( 'channels' ) ) > 0 :
   oOIIi1iiii1iI = ii ( 'channel' )
   for iIiiii in oOIIi1iiii1iI :
    if 89 - 89: IiII - o00O0oo % I11i11Ii % i1
    if 49 - 49: I11i11Ii - oOooOoO0Oo0O / I1Ii111 / O0 % i1 * iII111i
    OOo = ''
    O0II11iI111i1 = 0
    try :
     OOo = iIiiii ( 'externallink' ) [ 0 ] . string
     O0II11iI111i1 = len ( iIiiii ( 'externallink' ) )
    except : pass
    if 95 - 95: OoooooooOO - I1Ii111 * oOooOoO0Oo0O + o0
    if O0II11iI111i1 > 1 : OOo = ''
    if 10 - 10: i1 / i11iIiiIii
    oOOO00o000o = iIiiii ( 'name' ) [ 0 ] . string
    o00oO = iIiiii ( 'thumbnail' ) [ 0 ] . string
    if o00oO == None :
     o00oO = ''
     if 92 - 92: I1Ii111 * I11i11Ii * I11i11Ii * oOooOoO0Oo0O . iIii1I11I1II1
    try :
     if not iIiiii ( 'fanart' ) :
      if oO . getSetting ( 'use_thumb' ) == "true" :
       I1Ii1111iIi = o00oO
      else :
       I1Ii1111iIi = fanart
     else :
      I1Ii1111iIi = iIiiii ( 'fanart' ) [ 0 ] . string
     if I1Ii1111iIi == None :
      raise
    except :
     I1Ii1111iIi = fanart
     if 31 - 31: Ii1I . ooOoO0o * o00O0oo + i11iIiiIii * OOooOOo
    try :
     OOoo = iIiiii ( 'info' ) [ 0 ] . string
     if OOoo == None :
      raise
    except :
     OOoo = ''
     if 93 - 93: ii1IiI1i / iIii1I11I1II1 * i1IIi % OoooooooOO * O0 * Ii1I
    try :
     I1i11i = iIiiii ( 'genre' ) [ 0 ] . string
     if I1i11i == None :
      raise
    except :
     I1i11i = ''
     if 64 - 64: i11i + O0 / iIii1I11I1II1 / I11i11Ii . o00O0oo % I1Ii111
    try :
     iIIiiiI = iIiiii ( 'date' ) [ 0 ] . string
     if iIIiiiI == None :
      raise
    except :
     iIIiiiI = ''
     if 50 - 50: iIii1I11I1II1 - I1Ii111 + I11i
    try :
     credits = iIiiii ( 'credits' ) [ 0 ] . string
     if credits == None :
      raise
    except :
     credits = ''
     if 69 - 69: O0
    try :
     oo0 = iIiiii ( 'year' ) [ 0 ] . string
     if oo0 == None :
      raise
    except :
     oo0 = ''
     if 85 - 85: o00O0oo / O0
    try :
     IiI111ii1ii = iIiiii ( 'director' ) [ 0 ] . string
     if IiI111ii1ii == None :
      raise
    except :
     IiI111ii1ii = ''
     if 18 - 18: i1 % O0 * ii1IiI1i
    try :
     O0OOo = iIiiii ( 'duration' ) [ 0 ] . string
     if O0OOo == None :
      raise
    except :
     O0OOo = ''
     if 62 - 62: ooOoO0o . I1Ii111 . OoooooooOO
    try :
     IiIII1 = iIiiii ( 'premiered' ) [ 0 ] . string
     if IiIII1 == None :
      raise
    except :
     IiIII1 = ''
     if 11 - 11: I11i / Ii1I
    try :
     O0Oo000 = iIiiii ( 'studio' ) [ 0 ] . string
     if O0Oo000 == None :
      raise
    except :
     O0Oo000 = ''
     if 73 - 73: i1IIi / i11iIiiIii
    try :
     iiI11i1II = iIiiii ( 'rate' ) [ 0 ] . string
     if iiI11i1II == None :
      raise
    except :
     iiI11i1II = ''
     if 58 - 58: I11i11Ii . i11i + OOooOOo - i11iIiiIii / i11i / O0
    try :
     OO0O0OOo0O = iIiiii ( 'originaltitle' ) [ 0 ] . string
     if OO0O0OOo0O == None :
      raise
    except :
     OO0O0OOo0O = ''
     if 85 - 85: o0 + I11i
    try :
     I1o0OooOOOOOO = iIiiii ( 'country' ) [ 0 ] . string
     if I1o0OooOOOOOO == None :
      raise
    except :
     I1o0OooOOOOOO = ''
     if 10 - 10: I1Ii111 / i1iIi11iIIi1I + o0 / i1IIi
    try :
     i1iII1II11I = iIiiii ( 'mediatype' ) [ 0 ] . string
     if i1iII1II11I == None :
      raise
    except :
     i1iII1II11I = ''
     if 54 - 54: I1Ii111 + O0 + Ii1I * ooOoO0o - I11i % OOooOOo
    try :
     OOooO0o0 = iIiiii ( 'rating' ) [ 0 ] . string
     if OOooO0o0 == None :
      raise
    except :
     OOooO0o0 = ''
     if 13 - 13: o00O0oo / IiII * i1iIi11iIIi1I . i1iIi11iIIi1I * o00O0oo
    try :
     iiIII1i = iIiiii ( 'userrating' ) [ 0 ] . string
     if iiIII1i == None :
      raise
    except :
     iiIII1i = ''
     if 63 - 63: ooOoO0o / O0 * I11i11Ii + i11i / I1Ii111 + iII111i
    try :
     I1I = iIiiii ( 'votes' ) [ 0 ] . string
     if I1I == None :
      raise
    except :
     I1I = ''
     if 63 - 63: i1iIi11iIIi1I + ii1IiI1i . ooOoO0o % ooOoO0o
    try :
     ooooO0oOoOOoO = iIiiii ( 'aired' ) [ 0 ] . string
     if ooooO0oOoOOoO == None :
      raise
    except :
     ooooO0oOoOOoO = ''
     if 57 - 57: i11i
    try :
     if OOo == '' :
      I1IiiiiI ( oOOO00o000o . encode ( 'utf-8' , 'ignore' ) , url . encode ( 'utf-8' ) , 2 , o00oO , I1Ii1111iIi , OOoo , I1i11i , iIIiiiI , credits , oo0 , IiI111ii1ii , O0OOo , IiIII1 , O0Oo000 , iiI11i1II , OO0O0OOo0O , I1o0OooOOOOOO , OOooO0o0 , iiIII1i , I1I , ooooO0oOoOOoO , True )
     else :
      if 54 - 54: I11i11Ii + OOooOOo + i11iIiiIii
      I1IiiiiI ( oOOO00o000o . encode ( 'utf-8' ) , OOo . encode ( 'utf-8' ) , 1 , o00oO , I1Ii1111iIi , OOoo , I1i11i , iIIiiiI , None , oo0 , IiI111ii1ii , O0OOo , IiIII1 , O0Oo000 , iiI11i1II , OO0O0OOo0O , I1o0OooOOOOOO , OOooO0o0 , iiIII1i , I1I , ooooO0oOoOOoO , 'source' )
    except :
     I1iI1iIi111i ( 'There was a problem adding directory from getData(): ' + oOOO00o000o . encode ( 'utf-8' , 'ignore' ) )
  else :
   I1iI1iIi111i ( 'No Channels: getItems' )
   i1i1ii111 ( ii ( 'item' ) , fanart )
 else :
  IiI1i ( ii )
  if 87 - 87: o00O0oo
 if O0iII1 == "thumbnail" :
  IIIii ( )
  if 83 - 83: I1Ii111 % i1 % oOooOoO0Oo0O . iIii1I11I1II1 - I1Ii111
  if 88 - 88: OoooooooOO
  if 84 - 84: o0 / Ii1I * IiII / OOooOOo - i11iIiiIii . I11i11Ii
def IiI1i ( data ) :
 oOOo000oOoO0 = data . rstrip ( )
 OoOo00o0OO = re . compile ( r'#EXTINF:(.+?),(.*?)[\n\r]+([^\r\n]+)' ) . findall ( oOOo000oOoO0 )
 ii1IIIIiI11 = len ( OoOo00o0OO )
 print 'tsdownloader' , iI1
 if 40 - 40: i1
 for OOOooo , Oo00oo0000OO , O0oOOo0Oo in OoOo00o0OO :
  if 73 - 73: iII111i - ooOoO0o
  if 'tvg-logo' in OOOooo :
   o00oO = O00oooo00o0O ( OOOooo , 'tvg-logo=[\'"](.*?)[\'"]' )
   if o00oO :
    if o00oO . startswith ( 'http' ) :
     o00oO = o00oO
     if 9 - 9: oOooOoO0Oo0O % oOooOoO0Oo0O % i11i
    elif not oO . getSetting ( 'logo-folderPath' ) == "" :
     I1I1i1I = oO . getSetting ( 'logo-folderPath' )
     o00oO = I1I1i1I + o00oO
     if 87 - 87: O0 / iIii1I11I1II1 * i1IIi
    else :
     o00oO = o00oO
     if 41 - 41: o0 * Ii1I / o0 % OOooOOo
     if 18 - 18: i11i . OoooooooOO % o0 % iII111i
  else :
   o00oO = ''
   if 9 - 9: i1iIi11iIIi1I - I11i11Ii * OoooooooOO . I11i11Ii
  if 'type' in OOOooo :
   ii1Ii1IiIIi = O00oooo00o0O ( OOOooo , 'type=[\'"](.*?)[\'"]' )
   if ii1Ii1IiIIi == 'yt-dl' :
    O0oOOo0Oo = O0oOOo0Oo + "&mode=18"
   elif ii1Ii1IiIIi == 'regex' :
    O0O0Oooo0o = O0oOOo0Oo . split ( '&regexs=' )
    if 83 - 83: Ii1I / ii1IiI1i
    II1Ii11Ii1i1I = ii1iIi1II ( Oo00o0OO0O00o ( '' , data = O0O0Oooo0o [ 1 ] ) )
    if 2 - 2: I11i11Ii + o0 - I11i . oOooOoO0Oo0O - I11i
    oo0o0oooo ( O0O0Oooo0o [ 0 ] , Oo00oo0000OO , o00oO , '' , '' , '' , '' , '' , None , II1Ii11Ii1i1I , ii1IIIIiI11 )
    continue
   elif ii1Ii1IiIIi == 'ftv' :
    O0oOOo0Oo = 'plugin://plugin.video.F.T.V/?name=' + urllib . quote ( Oo00oo0000OO ) + '&url=' + O0oOOo0Oo + '&mode=125&ch_fanart=na'
  elif iI1 and '.ts' in O0oOOo0Oo :
   O0oOOo0Oo = 'plugin://plugin.video.f4mTester/?url=' + urllib . quote_plus ( O0oOOo0Oo ) + '&amp;streamtype=TSDOWNLOADER&name=' + urllib . quote ( Oo00oo0000OO )
  ii1iiIi1 ( O0oOOo0Oo , Oo00oo0000OO , o00oO , '' , '' , '' , '' , '' , None , '' , ii1IIIIiI11 )
  if 34 - 34: I11i
def OooO0ooo0o ( name , url , fanart ) :
 ii = Oo00o0OO0O00o ( url )
 iii1 = ii . find ( 'channel' , attrs = { 'name' : name . decode ( 'utf-8' ) } )
 I1i = iii1 ( 'item' )
 try :
  I1Ii1111iIi = iii1 ( 'fanart' ) [ 0 ] . string
  if I1Ii1111iIi == None :
   raise
 except :
  I1Ii1111iIi = fanart
 for iIiiii in iii1 ( 'subchannel' ) :
  name = iIiiii ( 'name' ) [ 0 ] . string
  try :
   o00oO = iIiiii ( 'thumbnail' ) [ 0 ] . string
   if o00oO == None :
    raise
  except :
   o00oO = ''
  try :
   if not iIiiii ( 'fanart' ) :
    if oO . getSetting ( 'use_thumb' ) == "true" :
     I1Ii1111iIi = o00oO
   else :
    I1Ii1111iIi = iIiiii ( 'fanart' ) [ 0 ] . string
   if I1Ii1111iIi == None :
    raise
  except :
   pass
  try :
   OOoo = iIiiii ( 'info' ) [ 0 ] . string
   if OOoo == None :
    raise
  except :
   OOoo = ''
   if 86 - 86: I11i11Ii / OOooOOo + O0 * IiII
  try :
   I1i11i = iIiiii ( 'genre' ) [ 0 ] . string
   if I1i11i == None :
    raise
  except :
   I1i11i = ''
   if 19 - 19: i11i * I1Ii111 + iII111i
  try :
   iIIiiiI = iIiiii ( 'date' ) [ 0 ] . string
   if iIIiiiI == None :
    raise
  except :
   iIIiiiI = ''
   if 65 - 65: I11i . ooOoO0o . i1iIi11iIIi1I . IiII - I11i
  try :
   credits = iIiiii ( 'credits' ) [ 0 ] . string
   if credits == None :
    raise
  except :
   credits = ''
   if 19 - 19: i11iIiiIii + IiII % o00O0oo
  try :
   oo0 = iIiiii ( 'year' ) [ 0 ] . string
   if oo0 == None :
    raise
  except :
   oo0 = ''
   if 14 - 14: i1iIi11iIIi1I . i11i . Ii1I / iII111i % ii1IiI1i - o00O0oo
  try :
   IiI111ii1ii = iIiiii ( 'director' ) [ 0 ] . string
   if IiI111ii1ii == None :
    raise
  except :
   IiI111ii1ii = ''
   if 67 - 67: Ii1I - I11i . i1IIi
  try :
   O0OOo = iIiiii ( 'duration' ) [ 0 ] . string
   if O0OOo == None :
    raise
  except :
   O0OOo = ''
   if 35 - 35: IiII + o00O0oo - OOooOOo . IiII . I1Ii111
  try :
   IiIII1 = iIiiii ( 'premiered' ) [ 0 ] . string
   if IiIII1 == None :
    raise
  except :
   IiIII1 = ''
   if 87 - 87: o0
  try :
   O0Oo000 = iIiiii ( 'studio' ) [ 0 ] . string
   if O0Oo000 == None :
    raise
  except :
   O0Oo000 = ''
   if 25 - 25: i1IIi . i1iIi11iIIi1I - o0 / i1iIi11iIIi1I % i1iIi11iIIi1I * iIii1I11I1II1
  try :
   iiI11i1II = iIiiii ( 'rate' ) [ 0 ] . string
   if iiI11i1II == None :
    raise
  except :
   iiI11i1II = ''
   if 50 - 50: i1iIi11iIIi1I . i11iIiiIii - OOooOOo . OOooOOo
  try :
   OO0O0OOo0O = iIiiii ( 'originaltitle' ) [ 0 ] . string
   if OO0O0OOo0O == None :
    raise
  except :
   OO0O0OOo0O = ''
   if 31 - 31: I11i / I11i11Ii * i1IIi . o0
  try :
   I1o0OooOOOOOO = iIiiii ( 'country' ) [ 0 ] . string
   if I1o0OooOOOOOO == None :
    raise
  except :
   I1o0OooOOOOOO = ''
   if 57 - 57: I11i + iIii1I11I1II1 % i1IIi % oOooOoO0Oo0O
  try :
   OOooO0o0 = iIiiii ( 'rating' ) [ 0 ] . string
   if OOooO0o0 == None :
    raise
  except :
   OOooO0o0 = ''
   if 83 - 83: i1 / i11iIiiIii % iIii1I11I1II1 . Ii1I % OOooOOo . OoooooooOO
  try :
   iiIII1i = iIiiii ( 'userrating' ) [ 0 ] . string
   if iiIII1i == None :
    raise
  except :
   iiIII1i = ''
   if 94 - 94: iII111i + iIii1I11I1II1 % i1iIi11iIIi1I
  try :
   I1I = iIiiii ( 'votes' ) [ 0 ] . string
   if I1I == None :
    raise
  except :
   I1I = ''
   if 93 - 93: iII111i - I11i + iIii1I11I1II1 * i1 + ooOoO0o . IiII
  try :
   ooooO0oOoOOoO = iIiiii ( 'aired' ) [ 0 ] . string
   if ooooO0oOoOOoO == None :
    raise
  except :
   ooooO0oOoOOoO = ''
   if 49 - 49: OoooooooOO * Ii1I - I11i11Ii . OOooOOo
  try :
   I1IiiiiI ( name . encode ( 'utf-8' , 'ignore' ) , url . encode ( 'utf-8' ) , 3 , o00oO , I1Ii1111iIi , OOoo , I1i11i , credits , iIIiiiI , oo0 , IiI111ii1ii , O0OOo , IiIII1 , O0Oo000 , iiI11i1II , OO0O0OOo0O , I1o0OooOOOOOO , OOooO0o0 , iiIII1i , I1I , ooooO0oOoOOoO )
  except :
   I1iI1iIi111i ( 'There was a problem adding directory - ' + name . encode ( 'utf-8' , 'ignore' ) )
 i1i1ii111 ( I1i , I1Ii1111iIi )
 if 89 - 89: o00O0oo + iII111i * o00O0oo / o00O0oo
 if 46 - 46: i1iIi11iIIi1I
def O0000 ( name , url , fanart ) :
 ii = Oo00o0OO0O00o ( url )
 iii1 = ii . find ( 'subchannel' , attrs = { 'name' : name . decode ( 'utf-8' ) } )
 I1i = iii1 ( 'subitem' )
 i1i1ii111 ( I1i , fanart )
 if 64 - 64: i11i - oOooOoO0Oo0O
 if 68 - 68: o00O0oo - I11i - iIii1I11I1II1 / o0 + I11i - i1iIi11iIIi1I
def O00Oo ( name , url , iconimage , fanart ) :
 I1ii = [ ] ; Ii1i1i1111 = [ ] ; o0oO0O00oOo = 0
 I1111I1II11 = iiiIIIIiIi ( url , 'sublink:' , '#' )
 for Iii in I1111I1II11 :
  IIIII1iii = Iii . replace ( 'sublink:' , '' ) . replace ( '#' , '' )
  if 7 - 7: i1 + i1IIi . oOooOoO0Oo0O / I11i11Ii
  if len ( IIIII1iii ) > 10 :
   o0oO0O00oOo = o0oO0O00oOo + 1 ; I1ii . append ( name + ' Source [' + str ( o0oO0O00oOo ) + ']' ) ; Ii1i1i1111 . append ( IIIII1iii )
   if 22 - 22: o00O0oo - o00O0oo % I11i . ooOoO0o + OOooOOo
 if o0oO0O00oOo == 1 :
  try :
   if 63 - 63: oOooOoO0Oo0O % ooOoO0o * i1 + ooOoO0o / I11i11Ii % IiII
   iiI1i1Iii111 = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage ) ; iiI1i1Iii111 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
   i111I11i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Ii1i1i1111 [ 0 ] , listitem = iiI1i1Iii111 )
   xbmc . Player ( ) . play ( ii1 ( Ii1i1i1111 [ 0 ] ) , iiI1i1Iii111 )
  except :
   pass
 else :
  I11iiI1i1 = xbmcgui . Dialog ( )
  if 56 - 56: i11i / OOooOOo + i11iIiiIii + I11i
  O0O0o0o0o = I11iiI1i1 . select ( 'Select A Source' , I1ii )
  if O0O0o0o0o >= 0 :
   IIIIIiI = name
   Oo0000O0OOooO = str ( Ii1i1i1111 [ O0O0o0o0o ] )
   if 54 - 54: Ii1I / oOooOoO0Oo0O * OOooOOo + OoooooooOO - IiII / OoooooooOO
   try :
    iiI1i1Iii111 = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage ) ; iiI1i1Iii111 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
    i111I11i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Oo0000O0OOooO , listitem = iiI1i1Iii111 )
    xbmc . Player ( ) . play ( ii1 ( Oo0000O0OOooO ) , iiI1i1Iii111 )
   except :
    pass
    if 19 - 19: I1Ii111 * o00O0oo * i1 + O0 / O0
    if 73 - 73: iIii1I11I1II1 / iIii1I11I1II1 - OOooOOo
def Iii1iI ( url , headers = None ) :
 try :
  if headers is None :
   if 91 - 91: OOooOOo + oOooOoO0Oo0O
   headers = { 'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0' }
   headers = { 'User-agent' : '\xbd\xbf\xef\xbd\xbf\xef\x38\x62\x55\xbd\xbf\xef\xbd\xbf\xef\xbd\xbf\xef\x19' }
  i11III1111iIi = urllib2 . Request ( url , None , headers )
  oO00OOoO00 = urllib2 . urlopen ( i11III1111iIi )
  IiI111111IIII = oO00OOoO00 . read ( )
  oO00OOoO00 . close ( )
  return IiI111111IIII
 except urllib2 . URLError , IiII111i1i11 :
  I1iI1iIi111i ( 'URL: ' + url )
  if hasattr ( IiII111i1i11 , 'code' ) :
   I1iI1iIi111i ( 'Falha com o código de erro - %s.' % IiII111i1i11 . code )
   if 59 - 59: oOooOoO0Oo0O + i11iIiiIii + i1IIi / Ii1I
   if 44 - 44: Ii1I . o0 * oOooOoO0Oo0O + OoooooooOO - IiII - I1Ii111
   xbmc . executebuiltin ( "XBMC.Notification(Falha, código de erro - " + str ( IiII111i1i11 . code ) + ",10000," + oOO00Oo + ")" )
  elif hasattr ( IiII111i1i11 , 'reason' ) :
   I1iI1iIi111i ( 'Falha ao acessar um servidor.' )
   I1iI1iIi111i ( 'Razão: %s' % IiII111i1i11 . reason )
   if 15 - 15: I1Ii111 / O0 . i1 . i11iIiiIii
   xbmc . executebuiltin ( "XBMC.Notification(Falha, motivo - " + str ( IiII111i1i11 . reason ) + ",10000," + oOO00Oo + ")" )
   if 59 - 59: ooOoO0o - i1 - o00O0oo
   if 48 - 48: i1IIi + Ii1I % o0 / I11i11Ii - i1
def OOoOOo0O00O ( ) :
 if 36 - 36: O0 + I11i11Ii
 iIIIi1i1I11i = 'Name of channel show or movie'
 oOO0OO0OO = ''
 I1i11111i1i11 = xbmc . Keyboard ( oOO0OO0OO , iIIIi1i1I11i )
 I1i11111i1i11 . doModal ( )
 if I1i11111i1i11 . isConfirmed ( ) :
  oOO0OO0OO = I1i11111i1i11 . getText ( ) . replace ( '\n' , '' ) . strip ( )
  if len ( oOO0OO0OO ) == 0 :
   xbmcgui . Dialog ( ) . ok ( 'RobinHood' , 'Nothing Entered' )
   return
   if 87 - 87: OOooOOo + iIii1I11I1II1 - OoooooooOO
 oOO0OO0OO = oOO0OO0OO . lower ( )
 I1ii = [ ]
 I1ii . append ( plugin_name )
 IiI1 = 0
 i1IIii1iiIi = 1
 oooo0OOo = 0
 OoO00 = 0
 I11iIi1II = xbmcgui . DialogProgress ( )
 if 60 - 60: iIii1I11I1II1 + i1IIi
 I11iIi1II . create ( 'Searching Please wait' , ' ' )
 if 86 - 86: iIii1I11I1II1 + o0 . i11iIiiIii - iII111i
 while i1IIii1iiIi <> oooo0OOo :
  ooO000O = I1ii [ oooo0OOo ] . strip ( )
  print 'read this one from file list (' + str ( oooo0OOo ) + ')'
  oooo0OOo = oooo0OOo + 1
  if 53 - 53: i1 . IiII / iII111i
  I11iiIi1i1 = ''
  try :
   I11iiIi1i1 = net . http_GET ( ooO000O ) . content
   I11iiIi1i1 = I11iiIi1i1 . encode ( 'ascii' , 'ignore' ) . decode ( 'ascii' )
   if 41 - 41: iII111i % ii1IiI1i
  except :
   pass
   if 12 - 12: I11i
  if len ( I11iiIi1i1 ) < 10 :
   I11iiIi1i1 = ''
   IiI1 = IiI1 + 1
   print '*** PASSED ****' + ooO000O + '  ************* Total Passed Urls: ' + str ( IiI1 )
   time . sleep ( .5 )
   if 69 - 69: OoooooooOO + I11i
  IIi11I1 = int ( ( oooo0OOo / 300 ) * 100 )
  iiiI111I = '     Pages Read: ' + str ( oooo0OOo ) + '        Matches Found: ' + str ( OoO00 )
  I11iIi1II . update ( IIi11I1 , "" , iiiI111I , "" )
  if 75 - 75: OoooooooOO % i1iIi11iIIi1I / oOooOoO0Oo0O
  if I11iIi1II . iscanceled ( ) :
   return
   if 56 - 56: OoooooooOO % i11iIiiIii * iIii1I11I1II1 . i1iIi11iIIi1I * O0
  if len ( I11iiIi1i1 ) > 10 :
   iIO0O00OOo = iiiIIIIiIi ( I11iiIi1i1 , '<channel>' , '</channel>' )
   for Iii in iIO0O00OOo :
    IIIII1iii = OoOOo ( Iii , '<externallink>' , '</externallink>' )
    if 17 - 17: i1IIi
    if 1 - 1: o00O0oo
    if len ( IIIII1iii ) > 5 :
     i1IIii1iiIi = i1IIii1iiIi + 1
     I1ii . append ( IIIII1iii )
     if 78 - 78: ii1IiI1i + Ii1I - O0
     if 10 - 10: ooOoO0o % oOooOoO0Oo0O
   oo0OoOooo = iiiIIIIiIi ( I11iiIi1i1 , '<item>' , '</item>' )
   for Iii in oo0OoOooo :
    IIIII1iii = OoOOo ( Iii , '<link>' , '</link>' )
    oOOO00o000o = OoOOo ( Iii , '<title>' , '</title>' )
    O00O00O000OOO = '  ' + oOOO00o000o . lower ( ) + '  '
    if 3 - 3: O0
    if len ( IIIII1iii ) > 5 and O00O00O000OOO . find ( oOO0OO0OO ) > 0 :
     OoO00 = OoO00 + 1
     iIi11 = ''
     o00oO = OoOOo ( Iii , '<thumbnail>' , '</thumbnail>' )
     iIi11 = OoOOo ( Iii , '<fanart>' , '</fanart>' )
     if len ( iIi11 ) < 5 :
      iIi11 = oOO00Oo
     if IIIII1iii . find ( 'sublink' ) > 0 :
      I1IiiiiI ( oOOO00o000o , IIIII1iii , 30 , o00oO , iIi11 , '' , '' , '' , '' )
     else :
      oo0o0oooo ( str ( IIIII1iii ) , oOOO00o000o , o00oO , iIi11 , '' , '' , '' , True , None , '' , 1 )
      if 64 - 64: i1IIi % o00O0oo / i11iIiiIii - i1IIi % I11i . IiII
      if 8 - 8: I11i11Ii + i11i * I11i * o0 * Ii1I / I1Ii111
 I11iIi1II . close ( )
 xbmc . executebuiltin ( "Container.SetViewMode(50)" )
 if 21 - 21: OOooOOo / OoooooooOO
def III1IiIII1 ( data , Searchkey ) :
 oOOo000oOoO0 = data . rstrip ( )
 OoOo00o0OO = re . compile ( r'#EXTINF:(.+?),(.*?)[\n\r]+([^\n]+)' ) . findall ( oOOo000oOoO0 )
 ii1IIIIiI11 = len ( OoOo00o0OO )
 print 'total m3u links' , ii1IIIIiI11
 for OOOooo , Oo00oo0000OO , O0oOOo0Oo in OoOo00o0OO :
  if 'tvg-logo' in OOOooo :
   o00oO = O00oooo00o0O ( OOOooo , 'tvg-logo=[\'"](.*?)[\'"]' )
   if o00oO :
    if o00oO . startswith ( 'http' ) :
     o00oO = o00oO
     if 90 - 90: o00O0oo + i11i * ii1IiI1i / iII111i . i1 + i1
    elif not oO . getSetting ( 'logo-folderPath' ) == "" :
     I1I1i1I = oO . getSetting ( 'logo-folderPath' )
     o00oO = I1I1i1I + o00oO
     if 40 - 40: o00O0oo / o0 % i11iIiiIii % ii1IiI1i / oOooOoO0Oo0O
    else :
     o00oO = o00oO
     if 62 - 62: i1IIi - o0
     if 62 - 62: i1IIi + I11i11Ii % I1Ii111
  else :
   o00oO = ''
  if 'type' in OOOooo :
   ii1Ii1IiIIi = O00oooo00o0O ( OOOooo , 'type=[\'"](.*?)[\'"]' )
   if ii1Ii1IiIIi == 'yt-dl' :
    O0oOOo0Oo = O0oOOo0Oo + "&mode=18"
   elif ii1Ii1IiIIi == 'regex' :
    O0O0Oooo0o = O0oOOo0Oo . split ( '&regexs=' )
    if 28 - 28: ii1IiI1i . i1IIi
    II1Ii11Ii1i1I = ii1iIi1II ( Oo00o0OO0O00o ( '' , data = O0O0Oooo0o [ 1 ] ) )
    if 10 - 10: i1iIi11iIIi1I / I11i11Ii
    oo0o0oooo ( O0O0Oooo0o [ 0 ] , Oo00oo0000OO , o00oO , '' , '' , '' , '' , '' , None , II1Ii11Ii1i1I , ii1IIIIiI11 )
    continue
  oo0o0oooo ( O0oOOo0Oo , Oo00oo0000OO , o00oO , '' , '' , '' , '' , '' , None , '' , ii1IIIIiI11 )
  if 15 - 15: IiII . o0 / IiII * Ii1I - oOooOoO0Oo0O % ii1IiI1i
def oo0OOOOOO0 ( text , pattern ) :
 i11 = ""
 try :
  Ii1I1I11I = re . findall ( pattern , text , flags = re . DOTALL )
  i11 = Ii1I1I11I [ 0 ]
 except :
  i11 = ""
  if 29 - 29: OoooooooOO . oOooOoO0Oo0O % ii1IiI1i - IiII
 return i11
 if 8 - 8: i1IIi
def iiiIIIIiIi ( text , start_with , end_with ) :
 iIiI1 = re . findall ( "(?i)(" + start_with + "[\S\s]+?" + end_with + ")" , text )
 return iIiI1
 if 37 - 37: i1iIi11iIIi1I * i11iIiiIii / I11i % ooOoO0o
def OoOOo ( text , from_string , to_string , excluding = True ) :
 if excluding :
  try : iIiI1 = re . search ( "(?i)" + from_string + "([\S\s]+?)" + to_string , text ) . group ( 1 )
  except : iIiI1 = ''
 else :
  try : iIiI1 = re . search ( "(?i)(" + from_string + "[\S\s]+?" + to_string + ")" , text ) . group ( 1 )
  except : iIiI1 = ''
 return iIiI1
 if 71 - 71: OoooooooOO
def i1i1ii111 ( items , fanart , dontLink = False ) :
 ii1IIIIiI11 = len ( items )
 I1iI1iIi111i ( 'Total Items: %s' % ii1IIIIiI11 )
 iIiI1iiiI1ii = oO . getSetting ( 'add_playlist' )
 I1iOO0Oo = oO . getSetting ( 'ask_playlist_items' )
 IiIIIIIIiI = oO . getSetting ( 'use_thumb' )
 OOooo00 = oO . getSetting ( 'parentalblocked' )
 OOooo00 = ''
 OOooo00 = OOooo00 == "true"
 for i1oO in items :
  iIIi1IIi = False
  i111i11I1ii = False
  if 64 - 64: OOooOOo / i11iIiiIii / i1 . OoooooooOO
  i1iiIIi11I = 'false'
  try :
   i1iiIIi11I = i1oO ( 'parentalblock' ) [ 0 ] . string
  except :
   I1iI1iIi111i ( 'parentalblock Error' )
   i1iiIIi11I = ''
  if i1iiIIi11I == 'true' and OOooo00 : continue
  if 80 - 80: o00O0oo * O0
  try :
   oOOO00o000o = i1oO ( 'title' ) [ 0 ] . string
   if oOOO00o000o is None :
    oOOO00o000o = 'unknown?'
  except :
   I1iI1iIi111i ( 'Name Error' )
   oOOO00o000o = ''
   if 78 - 78: o0
   if 20 - 20: IiII % iII111i . iII111i / Ii1I + o0 . iII111i
  try :
   if i1oO ( 'epg' ) :
    if i1oO . epg_url :
     I1iI1iIi111i ( 'Get EPG Regex' )
     O0ooOo0 = i1oO . epg_url . string
     oo00ooOoo = i1oO . epg_regex . string
     iii1IIIiiiI = OoO00oo00 ( O0ooOo0 , oo00ooOoo )
     if iii1IIIiiiI :
      oOOO00o000o += ' - ' + iii1IIIiiiI
    elif i1oO ( 'epg' ) [ 0 ] . string > 1 :
     oOOO00o000o += Oo0Oo0O ( i1oO ( 'epg' ) [ 0 ] . string )
   else :
    pass
  except :
   I1iI1iIi111i ( 'EPG Error' )
  try :
   O0O0Oooo0o = [ ]
   if len ( i1oO ( 'link' ) ) > 0 :
    if 44 - 44: OoooooooOO % OoooooooOO
    if 35 - 35: IiII / ii1IiI1i * OoooooooOO . i11i / I11i11Ii
    for iII1I1IiI11ii in i1oO ( 'link' ) :
     if not iII1I1IiI11ii . string == None :
      O0O0Oooo0o . append ( iII1I1IiI11ii . string )
      if 1 - 1: OoooooooOO + I1Ii111 . i1IIi % Ii1I
   elif len ( i1oO ( 'sportsdevil' ) ) > 0 :
    for iII1I1IiI11ii in i1oO ( 'sportsdevil' ) :
     if not iII1I1IiI11ii . string == None :
      OOOOOo = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + iII1I1IiI11ii . string
      oo0o0oOo = i1oO ( 'referer' ) [ 0 ] . string
      if oo0o0oOo :
       if 58 - 58: i1 - i11i % OOooOOo + ooOoO0o . o0 / I1Ii111
       OOOOOo = OOOOOo + '%26referer=' + oo0o0oOo
      O0O0Oooo0o . append ( OOOOOo )
   elif len ( i1oO ( 'p2p' ) ) > 0 :
    for iII1I1IiI11ii in i1oO ( 'p2p' ) :
     if not iII1I1IiI11ii . string == None :
      if 'sop://' in iII1I1IiI11ii . string :
       IIo00ooo = 'plugin://plugin.video.p2p-streams/?mode=2url=' + iII1I1IiI11ii . string + '&' + 'name=' + oOOO00o000o
       O0O0Oooo0o . append ( IIo00ooo )
      else :
       Ii1IiIiIi1IiI = 'plugin://plugin.video.p2p-streams/?mode=1&url=' + iII1I1IiI11ii . string + '&' + 'name=' + oOOO00o000o
       O0O0Oooo0o . append ( Ii1IiIiIi1IiI )
   elif len ( i1oO ( 'vaughn' ) ) > 0 :
    for iII1I1IiI11ii in i1oO ( 'vaughn' ) :
     if not iII1I1IiI11ii . string == None :
      i1iiIIi1I = 'plugin://plugin.stream.vaughnlive.tv/?mode=PlayLiveStream&amp;channel=' + iII1I1IiI11ii . string
      O0O0Oooo0o . append ( i1iiIIi1I )
   elif len ( i1oO ( 'ilive' ) ) > 0 :
    for iII1I1IiI11ii in i1oO ( 'ilive' ) :
     if not iII1I1IiI11ii . string == None :
      if not 'http' in iII1I1IiI11ii . string :
       iiI1I1IIi11i1 = 'plugin://plugin.video.tbh.ilive/?url=http://www.streamlive.to/view/' + iII1I1IiI11ii . string + '&amp;link=99&amp;mode=iLivePlay'
      else :
       iiI1I1IIi11i1 = 'plugin://plugin.video.tbh.ilive/?url=' + iII1I1IiI11ii . string + '&amp;link=99&amp;mode=iLivePlay'
   elif len ( i1oO ( 'yt-dl' ) ) > 0 :
    for iII1I1IiI11ii in i1oO ( 'yt-dl' ) :
     if not iII1I1IiI11ii . string == None :
      i1II1iii1i = iII1I1IiI11ii . string + '&mode=18'
      O0O0Oooo0o . append ( i1II1iii1i )
   elif len ( i1oO ( 'dm' ) ) > 0 :
    for iII1I1IiI11ii in i1oO ( 'dm' ) :
     if not iII1I1IiI11ii . string == None :
      OOO0o = "plugin://plugin.video.dailymotion_com/?mode=playVideo&url=" + iII1I1IiI11ii . string
      O0O0Oooo0o . append ( OOO0o )
   elif len ( i1oO ( 'dmlive' ) ) > 0 :
    for iII1I1IiI11ii in i1oO ( 'dmlive' ) :
     if not iII1I1IiI11ii . string == None :
      OOO0o = "plugin://plugin.video.dailymotion_com/?mode=playLiveVideo&url=" + iII1I1IiI11ii . string
      O0O0Oooo0o . append ( OOO0o )
   elif len ( i1oO ( 'utube' ) ) > 0 :
    for iII1I1IiI11ii in i1oO ( 'utube' ) :
     if not iII1I1IiI11ii . string == None :
      if ' ' in iII1I1IiI11ii . string :
       iII = 'plugin://plugin.video.youtube/search/?q=' + urllib . quote_plus ( iII1I1IiI11ii . string )
       i111i11I1ii = iII
      elif len ( iII1I1IiI11ii . string ) == 11 :
       iII = 'plugin://plugin.video.youtube/play/?video_id=' + iII1I1IiI11ii . string
      elif ( iII1I1IiI11ii . string . startswith ( 'PL' ) and not '&order=' in iII1I1IiI11ii . string ) or iII1I1IiI11ii . string . startswith ( 'UU' ) :
       iII = 'plugin://plugin.video.youtube/play/?&order=default&playlist_id=' + iII1I1IiI11ii . string
      elif iII1I1IiI11ii . string . startswith ( 'PL' ) or iII1I1IiI11ii . string . startswith ( 'UU' ) :
       iII = 'plugin://plugin.video.youtube/play/?playlist_id=' + iII1I1IiI11ii . string
      elif iII1I1IiI11ii . string . startswith ( 'UC' ) and len ( iII1I1IiI11ii . string ) > 12 :
       iII = 'plugin://plugin.video.youtube/channel/' + iII1I1IiI11ii . string + '/'
       i111i11I1ii = iII
      elif not iII1I1IiI11ii . string . startswith ( 'UC' ) and not ( iII1I1IiI11ii . string . startswith ( 'PL' ) ) :
       iII = 'plugin://plugin.video.youtube/user/' + iII1I1IiI11ii . string + '/'
       i111i11I1ii = iII
     O0O0Oooo0o . append ( iII )
     if 24 - 24: I11i11Ii . Ii1I * iII111i % IiII / I11i
   elif len ( i1oO ( 'gdrive' ) ) > 0 :
    for iII1I1IiI11ii in i1oO ( 'gdrive' ) :
     if not iII1I1IiI11ii . string == None :
      if len ( iII1I1IiI11ii . string ) == 33 :
       Oo0Ooo0O0 = 'plugin://plugin.video.gdrive?mode=streamURL&amp;url=https://drive.google.com/open?id=' + iII1I1IiI11ii . string
       if 42 - 42: i1IIi * OOooOOo - iII111i . oOooOoO0Oo0O + i1 . iIii1I11I1II1
     O0O0Oooo0o . append ( Oo0Ooo0O0 )
     if 51 - 51: Ii1I . I11i11Ii
   elif len ( i1oO ( 'imdb' ) ) > 0 :
    for iII1I1IiI11ii in i1oO ( 'imdb' ) :
     if not iII1I1IiI11ii . string == None :
      if oO . getSetting ( 'genesisorpulsar' ) == '0' :
       IiiIiiIi = 'plugin://plugin.video.genesis/?action=play&imdb=' + iII1I1IiI11ii . string
      else :
       IiiIiiIi = 'plugin://plugin.video.pulsar/movie/tt' + iII1I1IiI11ii . string + '/play'
      O0O0Oooo0o . append ( IiiIiiIi )
   elif len ( i1oO ( 'f4m' ) ) > 0 :
    for iII1I1IiI11ii in i1oO ( 'f4m' ) :
     if not iII1I1IiI11ii . string == None :
      if '.f4m' in iII1I1IiI11ii . string :
       i1iiIIIi = 'plugin://plugin.video.f4mTester/?url=' + urllib . quote_plus ( iII1I1IiI11ii . string )
      elif '.m3u8' in iII1I1IiI11ii . string :
       i1iiIIIi = 'plugin://plugin.video.f4mTester/?url=' + urllib . quote_plus ( iII1I1IiI11ii . string ) + '&amp;streamtype=HLS'
       if 62 - 62: O0 / oOooOoO0Oo0O % O0 * i1iIi11iIIi1I % oOooOoO0Oo0O
      else :
       i1iiIIIi = 'plugin://plugin.video.f4mTester/?url=' + urllib . quote_plus ( iII1I1IiI11ii . string ) + '&amp;streamtype=SIMPLE'
     O0O0Oooo0o . append ( i1iiIIIi )
   elif len ( i1oO ( 'ftv' ) ) > 0 :
    for iII1I1IiI11ii in i1oO ( 'ftv' ) :
     if not iII1I1IiI11ii . string == None :
      Ii = 'plugin://plugin.video.F.T.V/?name=' + urllib . quote ( oOOO00o000o ) + '&url=' + iII1I1IiI11ii . string + '&mode=125&ch_fanart=na'
     O0O0Oooo0o . append ( Ii )
   elif len ( i1oO ( 'urlsolve' ) ) > 0 :
    if 99 - 99: i1iIi11iIIi1I * i11iIiiIii . OoooooooOO % I11i11Ii
    for iII1I1IiI11ii in i1oO ( 'urlsolve' ) :
     if not iII1I1IiI11ii . string == None :
      Oo0 = iII1I1IiI11ii . string + '&mode=19'
      O0O0Oooo0o . append ( Oo0 )
   if len ( O0O0Oooo0o ) < 1 :
    raise
  except :
   I1iI1iIi111i ( 'Error <link> element, Passing:' + oOOO00o000o . encode ( 'utf-8' , 'ignore' ) )
   continue
  try :
   iIIi1IIi = i1oO ( 'externallink' ) [ 0 ] . string
  except : pass
  if 93 - 93: i11iIiiIii % iIii1I11I1II1 % i11iIiiIii + i1 / i1 / i11i
  if iIIi1IIi :
   I1iOo = [ iIIi1IIi ]
   iIIi1IIi = True
  else :
   iIIi1IIi = False
  try :
   i111i11I1ii = i1oO ( 'jsonrpc' ) [ 0 ] . string
  except : pass
  if i111i11I1ii :
   if 29 - 29: O0 - i11iIiiIii - i11i + I11i * I1Ii111
   I1iOo = [ i111i11I1ii ]
   if 2 - 2: i1IIi - o00O0oo + oOooOoO0Oo0O . i1 * i1 / o0
   i111i11I1ii = True
  else :
   i111i11I1ii = False
  try :
   o00oO = i1oO ( 'thumbnail' ) [ 0 ] . string
   if o00oO == None :
    raise
  except :
   o00oO = ''
  try :
   if not i1oO ( 'fanart' ) :
    if oO . getSetting ( 'use_thumb' ) == "true" :
     I1Ii1111iIi = o00oO
    else :
     I1Ii1111iIi = fanart
   else :
    I1Ii1111iIi = i1oO ( 'fanart' ) [ 0 ] . string
   if I1Ii1111iIi == None :
    raise
  except :
   I1Ii1111iIi = fanart
  try :
   OOoo = i1oO ( 'info' ) [ 0 ] . string
   if OOoo == None :
    raise
  except :
   OOoo = ''
   if 93 - 93: i1IIi
  try :
   I1i11i = i1oO ( 'genre' ) [ 0 ] . string
   if I1i11i == None :
    raise
  except :
   I1i11i = ''
   if 53 - 53: OoooooooOO + I11i11Ii + OOooOOo
  try :
   iIIiiiI = i1oO ( 'date' ) [ 0 ] . string
   if iIIiiiI == None :
    raise
  except :
   iIIiiiI = ''
   if 24 - 24: IiII - I1Ii111 - IiII * ii1IiI1i . OoooooooOO / I1Ii111
  try :
   oo0 = i1oO ( 'year' ) [ 0 ] . string
   if iIIiiiI == None :
    raise
  except :
   oo0 = ''
   if 66 - 66: I11i11Ii
  try :
   IiI111ii1ii = i1oO ( 'director' ) [ 0 ] . string
   if IiI111ii1ii == None :
    raise
  except :
   IiI111ii1ii = ''
   if 97 - 97: i1IIi - OoooooooOO / ooOoO0o * oOooOoO0Oo0O
  try :
   O0OOo = i1oO ( 'duration' ) [ 0 ] . string
   if O0OOo == None :
    raise
  except :
   O0OOo = ''
   if 55 - 55: i1 . IiII
  try :
   IiIII1 = i1oO ( 'premiered' ) [ 0 ] . string
   if IiIII1 == None :
    raise
  except :
   IiIII1 = ''
   if 87 - 87: i1 % iIii1I11I1II1
  try :
   O0Oo000 = i1oO ( 'studio' ) [ 0 ] . string
   if O0Oo000 == None :
    raise
  except :
   O0Oo000 = ''
   if 100 - 100: ooOoO0o . oOooOoO0Oo0O * ooOoO0o - oOooOoO0Oo0O . Ii1I * iII111i
  try :
   iiI11i1II = i1oO ( 'rate' ) [ 0 ] . string
   if iiI11i1II == None :
    raise
  except :
   iiI11i1II = ''
   if 89 - 89: i1iIi11iIIi1I + I1Ii111 * ooOoO0o
  try :
   OO0O0OOo0O = channel ( 'originaltitle' ) [ 0 ] . string
   if OO0O0OOo0O == None :
    raise
  except :
   OO0O0OOo0O = ''
   if 28 - 28: OoooooooOO . OOooOOo % ii1IiI1i / i1IIi / I11i
  try :
   I1o0OooOOOOOO = channel ( 'country' ) [ 0 ] . string
   if I1o0OooOOOOOO == None :
    raise
  except :
   I1o0OooOOOOOO = ''
   if 36 - 36: i1 + Ii1I - I1Ii111 + iIii1I11I1II1 + OoooooooOO
  try :
   OOooO0o0 = channel ( 'rating' ) [ 0 ] . string
   if OOooO0o0 == None :
    raise
  except :
   OOooO0o0 = ''
   if 4 - 4: i11i . Ii1I + iII111i * ooOoO0o . o00O0oo
  try :
   iiIII1i = channel ( 'userrating' ) [ 0 ] . string
   if iiIII1i == None :
    raise
  except :
   iiIII1i = ''
   if 87 - 87: o0 / i1iIi11iIIi1I / i11iIiiIii
  try :
   I1I = channel ( 'votes' ) [ 0 ] . string
   if I1I == None :
    raise
  except :
   I1I = ''
   if 74 - 74: OOooOOo / ii1IiI1i % i1
  try :
   ooooO0oOoOOoO = channel ( 'aired' ) [ 0 ] . string
   if ooooO0oOoOOoO == None :
    raise
  except :
   ooooO0oOoOOoO = ''
   if 88 - 88: o0 - i11iIiiIii % i1 * Ii1I + ii1IiI1i
  II1Ii11Ii1i1I = None
  if i1oO ( 'regex' ) :
   try :
    OoiIIIiIi1I1i = i1oO ( 'regex' )
    II1Ii11Ii1i1I = ii1iIi1II ( OoiIIIiIi1I1i )
   except :
    pass
  try :
   if 78 - 78: iIii1I11I1II1 % o0 + ii1IiI1i / i1IIi % i11i + I11i
   if len ( O0O0Oooo0o ) > 1 :
    OooOOOO0O0 = 0
    i1IIi1i1Ii1 = [ ]
    for iII1I1IiI11ii in O0O0Oooo0o :
     if iIiI1iiiI1ii == "false" :
      OooOOOO0O0 += 1
      oo0o0oooo ( iII1I1IiI11ii , '%s) %s' % ( OooOOOO0O0 , oOOO00o000o . encode ( 'utf-8' , 'ignore' ) ) , o00oO , I1Ii1111iIi , OOoo , I1i11i , iIIiiiI , oo0 , IiI111ii1ii , O0OOo , IiIII1 , O0Oo000 , iiI11i1II , OO0O0OOo0O , I1o0OooOOOOOO , OOooO0o0 , iiIII1i , I1I , ooooO0oOoOOoO , True , i1IIi1i1Ii1 , II1Ii11Ii1i1I , ii1IIIIiI11 )
     elif iIiI1iiiI1ii == "true" and I1iOO0Oo == 'true' :
      if II1Ii11Ii1i1I :
       i1IIi1i1Ii1 . append ( iII1I1IiI11ii + '&regexs=' + II1Ii11Ii1i1I )
      elif any ( x in iII1I1IiI11ii for x in o0oo0oOo ) and iII1I1IiI11ii . startswith ( 'http' ) :
       i1IIi1i1Ii1 . append ( iII1I1IiI11ii + '&mode=19' )
      else :
       i1IIi1i1Ii1 . append ( iII1I1IiI11ii )
     else :
      i1IIi1i1Ii1 . append ( iII1I1IiI11ii )
    if len ( i1IIi1i1Ii1 ) > 1 :
     oo0o0oooo ( '' , oOOO00o000o , o00oO , I1Ii1111iIi , OOoo , I1i11i , iIIiiiI , oo0 , IiI111ii1ii , O0OOo , IiIII1 , O0Oo000 , iiI11i1II , OO0O0OOo0O , I1o0OooOOOOOO , OOooO0o0 , iiIII1i , I1I , ooooO0oOoOOoO , True , i1IIi1i1Ii1 , II1Ii11Ii1i1I , ii1IIIIiI11 )
   else :
    if 45 - 45: iIii1I11I1II1 . OOooOOo / o0 / I1Ii111
    if dontLink :
     return oOOO00o000o , O0O0Oooo0o [ 0 ] , II1Ii11Ii1i1I
    if iIIi1IIi :
     if not II1Ii11Ii1i1I == None :
      I1IiiiiI ( oOOO00o000o . encode ( 'utf-8' ) , I1iOo [ 0 ] . encode ( 'utf-8' ) , 1 , o00oO , fanart , OOoo , I1i11i , iIIiiiI , oo0 , IiI111ii1ii , O0OOo , IiIII1 , O0Oo000 , iiI11i1II , OO0O0OOo0O , I1o0OooOOOOOO , OOooO0o0 , iiIII1i , I1I , ooooO0oOoOOoO , None , '!!update' , II1Ii11Ii1i1I , O0O0Oooo0o [ 0 ] . encode ( 'utf-8' ) )
      if 55 - 55: I1Ii111
     else :
      I1IiiiiI ( oOOO00o000o . encode ( 'utf-8' ) , I1iOo [ 0 ] . encode ( 'utf-8' ) , 1 , o00oO , fanart , OOoo , I1i11i , iIIiiiI , oo0 , IiI111ii1ii , O0OOo , IiIII1 , O0Oo000 , iiI11i1II , OO0O0OOo0O , I1o0OooOOOOOO , OOooO0o0 , iiIII1i , I1I , ooooO0oOoOOoO , None , 'source' , None , None )
      if 24 - 24: i1iIi11iIIi1I + OOooOOo . i1 / OOooOOo
    elif i111i11I1ii :
     I1IiiiiI ( oOOO00o000o . encode ( 'utf-8' ) , I1iOo [ 0 ] , 53 , o00oO , fanart , OOoo , I1i11i , iIIiiiI , oo0 , IiI111ii1ii , O0OOo , IiIII1 , O0Oo000 , iiI11i1II , OO0O0OOo0O , I1o0OooOOOOOO , OOooO0o0 , iiIII1i , I1I , ooooO0oOoOOoO , None , 'source' )
     if 56 - 56: iIii1I11I1II1 . i11iIiiIii - I11i * i11i * ooOoO0o
    else :
     if 5 - 5: I11i / I11i - ii1IiI1i
     oo0o0oooo ( O0O0Oooo0o [ 0 ] , oOOO00o000o . encode ( 'utf-8' , 'ignore' ) , o00oO , I1Ii1111iIi , OOoo , I1i11i , iIIiiiI , oo0 , IiI111ii1ii , O0OOo , IiIII1 , O0Oo000 , iiI11i1II , OO0O0OOo0O , I1o0OooOOOOOO , OOooO0o0 , iiIII1i , I1I , ooooO0oOoOOoO , True , None , II1Ii11Ii1i1I , ii1IIIIiI11 )
     if 79 - 79: ii1IiI1i + ooOoO0o
  except :
   I1iI1iIi111i ( 'There was a problem adding item - ' + oOOO00o000o . encode ( 'utf-8' , 'ignore' ) )
   if 10 - 10: I11i11Ii + O0
def ii1iIi1II ( reg_item ) :
 try :
  II1Ii11Ii1i1I = { }
  for iII1I1IiI11ii in reg_item :
   II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] = { }
   II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'name' ] = iII1I1IiI11ii ( 'name' ) [ 0 ] . string
   if 43 - 43: iIii1I11I1II1 / i11i % i1 - I11i
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'expres' ] = iII1I1IiI11ii ( 'expres' ) [ 0 ] . string
    if not II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'expres' ] :
     II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'expres' ] = ''
   except :
    I1iI1iIi111i ( "Regex: -- No Referer --" )
   II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'page' ] = iII1I1IiI11ii ( 'page' ) [ 0 ] . string
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'referer' ] = iII1I1IiI11ii ( 'referer' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No Referer --" )
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'connection' ] = iII1I1IiI11ii ( 'connection' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No connection --" )
    if 62 - 62: Ii1I
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'notplayable' ] = iII1I1IiI11ii ( 'notplayable' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No notplayable --" )
    if 63 - 63: I11i + o00O0oo * OOooOOo / i1 / I11i11Ii * iIii1I11I1II1
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'noredirect' ] = iII1I1IiI11ii ( 'noredirect' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No noredirect --" )
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'origin' ] = iII1I1IiI11ii ( 'origin' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No origin --" )
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'accept' ] = iII1I1IiI11ii ( 'accept' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No accept --" )
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'includeheaders' ] = iII1I1IiI11ii ( 'includeheaders' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No includeheaders --" )
    if 57 - 57: o0 - OOooOOo / o00O0oo % i11iIiiIii
    if 3 - 3: IiII . o00O0oo % oOooOoO0Oo0O + ii1IiI1i
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'listrepeat' ] = iII1I1IiI11ii ( 'listrepeat' ) [ 0 ] . string
    if 64 - 64: i1IIi
   except :
    I1iI1iIi111i ( "Regex: -- No listrepeat --" )
    if 29 - 29: i1 / i11iIiiIii / oOooOoO0Oo0O % OOooOOo % i11iIiiIii
    if 18 - 18: I11i + ooOoO0o
    if 80 - 80: OOooOOo + i1 * iII111i + i1iIi11iIIi1I
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'proxy' ] = iII1I1IiI11ii ( 'proxy' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No proxy --" )
    if 75 - 75: Ii1I / i1 / I11i / I1Ii111 % o00O0oo + i11i
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'x-req' ] = iII1I1IiI11ii ( 'x-req' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No x-req --" )
    if 4 - 4: IiII - I11i11Ii - I1Ii111 - Ii1I % i11iIiiIii / i1iIi11iIIi1I
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'x-addr' ] = iII1I1IiI11ii ( 'x-addr' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No x-addr --" )
    if 50 - 50: o00O0oo + i1IIi
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'x-forward' ] = iII1I1IiI11ii ( 'x-forward' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No x-forward --" )
    if 31 - 31: iII111i
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'agent' ] = iII1I1IiI11ii ( 'agent' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No User Agent --" )
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'post' ] = iII1I1IiI11ii ( 'post' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- Not a post" )
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'rawpost' ] = iII1I1IiI11ii ( 'rawpost' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- Not a rawpost" )
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'htmlunescape' ] = iII1I1IiI11ii ( 'htmlunescape' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- Not a htmlunescape" )
    if 78 - 78: i11iIiiIii + i1 + ooOoO0o / i1 % iIii1I11I1II1 % I1Ii111
    if 83 - 83: iIii1I11I1II1 % o0 % i1 % ooOoO0o . ii1IiI1i % O0
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'readcookieonly' ] = iII1I1IiI11ii ( 'readcookieonly' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- Not a readCookieOnly" )
    if 47 - 47: i1
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'cookiejar' ] = iII1I1IiI11ii ( 'cookiejar' ) [ 0 ] . string
    if not II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'cookiejar' ] :
     II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'cookiejar' ] = ''
   except :
    I1iI1iIi111i ( "Regex: -- Not a cookieJar" )
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'setcookie' ] = iII1I1IiI11ii ( 'setcookie' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- Not a setcookie" )
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'appendcookie' ] = iII1I1IiI11ii ( 'appendcookie' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- Not a appendcookie" )
    if 66 - 66: oOooOoO0Oo0O - I1Ii111
   try :
    II1Ii11Ii1i1I [ iII1I1IiI11ii ( 'name' ) [ 0 ] . string ] [ 'ignorecache' ] = iII1I1IiI11ii ( 'ignorecache' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- no ignorecache" )
    if 33 - 33: oOooOoO0Oo0O / i1iIi11iIIi1I
    if 12 - 12: i11i
    if 2 - 2: i1IIi - oOooOoO0Oo0O + Ii1I . i11i
    if 25 - 25: OOooOOo
    if 34 - 34: o0 . iIii1I11I1II1 % O0
  II1Ii11Ii1i1I = urllib . quote ( repr ( II1Ii11Ii1i1I ) )
  return II1Ii11Ii1i1I
  if 43 - 43: ii1IiI1i - IiII
 except :
  II1Ii11Ii1i1I = None
  I1iI1iIi111i ( 'regex Error: ' + oOOO00o000o . encode ( 'utf-8' , 'ignore' ) )
  if 70 - 70: IiII / I11i % o00O0oo - iII111i
  if 47 - 47: IiII
def o00Ooo0 ( url ) :
 try :
  for iII1I1IiI11ii in range ( 1 , 51 ) :
   i11 = O0O00O ( url )
   if "EXT-X-STREAM-INF" in i11 : return url
   if not "EXTM3U" in i11 : return
   xbmc . sleep ( 2000 )
  return
 except :
  return
  if 4 - 4: o0 + iII111i / OOooOOo
def i1iI1IIIII1 ( regexs , url , cookieJar = None , forCookieJarOnly = False , recursiveCall = False , cachedPages = { } , rawPost = False , cookie_jar_file = None ) :
 if not recursiveCall :
  regexs = eval ( urllib . unquote ( regexs ) )
  if 39 - 39: ii1IiI1i % i1iIi11iIIi1I % iII111i
  if 55 - 55: O0 - ooOoO0o
 oOO0o0oo0 = re . compile ( '\$doregex\[([^\]]*)\]' ) . findall ( url )
 if 78 - 78: I11i + IiII . I1Ii111
 OoIIi1iI = True
 for oO0Ooo0OooOOo in oOO0o0oo0 :
  if oO0Ooo0OooOOo in regexs :
   if 71 - 71: I1Ii111 + i1IIi * I11i11Ii % I11i11Ii / I11i11Ii
   OoO00o0 = regexs [ oO0Ooo0OooOOo ]
   if 68 - 68: O0
   II1iIII = False
   if 'cookiejar' in OoO00o0 :
    if 79 - 79: OoooooooOO + ii1IiI1i - I11i11Ii + OoooooooOO
    II1iIII = OoO00o0 [ 'cookiejar' ]
    if '$doregex' in II1iIII :
     cookieJar = i1iI1IIIII1 ( regexs , OoO00o0 [ 'cookiejar' ] , cookieJar , True , True , cachedPages )
     II1iIII = True
    else :
     II1iIII = True
     if 61 - 61: i1IIi * i1iIi11iIIi1I - I11i11Ii - o00O0oo
   if II1iIII :
    if cookieJar == None :
     if 57 - 57: o0 . iIii1I11I1II1 % o00O0oo % iII111i * o0
     cookie_jar_file = None
     if 'open[' in OoO00o0 [ 'cookiejar' ] :
      cookie_jar_file = OoO00o0 [ 'cookiejar' ] . split ( 'open[' ) [ 1 ] . split ( ']' ) [ 0 ]
      if 8 - 8: o0 . o00O0oo % OOooOOo . oOooOoO0Oo0O % oOooOoO0Oo0O . iII111i
      if 47 - 47: Ii1I + o00O0oo + i11i % i11iIiiIii
     cookieJar = OOoOoo00Oo ( cookie_jar_file )
     if 9 - 9: i11i * i11i . i11iIiiIii * iIii1I11I1II1
     if cookie_jar_file :
      II1 ( cookieJar , cookie_jar_file )
      if 27 - 27: iII111i + oOooOoO0Oo0O * iIii1I11I1II1 . OoooooooOO * o0
      if 100 - 100: i1iIi11iIIi1I / i1IIi - oOooOoO0Oo0O % iII111i - iIii1I11I1II1
      if 17 - 17: Ii1I / i1 % I11i11Ii
    elif 'save[' in OoO00o0 [ 'cookiejar' ] :
     cookie_jar_file = OoO00o0 [ 'cookiejar' ] . split ( 'save[' ) [ 1 ] . split ( ']' ) [ 0 ]
     o0o = os . path . join ( O0oOoOOOoOO , cookie_jar_file )
     if 93 - 93: o00O0oo % i11iIiiIii % ooOoO0o
     II1 ( cookieJar , cookie_jar_file )
   if OoO00o0 [ 'page' ] and '$doregex' in OoO00o0 [ 'page' ] :
    O00OooO = i1iI1IIIII1 ( regexs , OoO00o0 [ 'page' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages )
    if len ( O00OooO ) == 0 :
     O00OooO = 'http://regexfailed'
    OoO00o0 [ 'page' ] = O00OooO
    if 40 - 40: Ii1I % OoooooooOO - I11i + i1 / I11i
   if 'setcookie' in OoO00o0 and OoO00o0 [ 'setcookie' ] and '$doregex' in OoO00o0 [ 'setcookie' ] :
    OoO00o0 [ 'setcookie' ] = i1iI1IIIII1 ( regexs , OoO00o0 [ 'setcookie' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages )
   if 'appendcookie' in OoO00o0 and OoO00o0 [ 'appendcookie' ] and '$doregex' in OoO00o0 [ 'appendcookie' ] :
    OoO00o0 [ 'appendcookie' ] = i1iI1IIIII1 ( regexs , OoO00o0 [ 'appendcookie' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages )
    if 84 - 84: O0
    if 11 - 11: i11i / i11iIiiIii / O0
   if 'post' in OoO00o0 and '$doregex' in OoO00o0 [ 'post' ] :
    OoO00o0 [ 'post' ] = i1iI1IIIII1 ( regexs , OoO00o0 [ 'post' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages )
    if 94 - 94: o00O0oo * Ii1I - I1Ii111 . iIii1I11I1II1
    if 66 - 66: o00O0oo - I11i * o0 / OOooOOo * i11i * i1iIi11iIIi1I
   if 'rawpost' in OoO00o0 and '$doregex' in OoO00o0 [ 'rawpost' ] :
    OoO00o0 [ 'rawpost' ] = i1iI1IIIII1 ( regexs , OoO00o0 [ 'rawpost' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages , rawPost = True )
    if 91 - 91: OoooooooOO / iII111i . oOooOoO0Oo0O + o00O0oo . i11i
    if 45 - 45: OOooOOo * o0 / iIii1I11I1II1
   if 'rawpost' in OoO00o0 and '$epoctime$' in OoO00o0 [ 'rawpost' ] :
    OoO00o0 [ 'rawpost' ] = OoO00o0 [ 'rawpost' ] . replace ( '$epoctime$' , o00ooOoO0 ( ) )
    if 15 - 15: I11i * Ii1I / ii1IiI1i * i1
   if 'rawpost' in OoO00o0 and '$epoctime2$' in OoO00o0 [ 'rawpost' ] :
    OoO00o0 [ 'rawpost' ] = OoO00o0 [ 'rawpost' ] . replace ( '$epoctime2$' , o000Oo0 ( ) )
    if 82 - 82: ooOoO0o - I11i + i1iIi11iIIi1I
    if 64 - 64: i1 . O0 * iII111i + OoooooooOO - I11i11Ii . OoooooooOO
   I1i1Iiiii = ''
   if OoO00o0 [ 'page' ] and OoO00o0 [ 'page' ] in cachedPages and not 'ignorecache' in OoO00o0 and forCookieJarOnly == False :
    if 70 - 70: I11i11Ii - OOooOOo . iIii1I11I1II1 % Ii1I / o0 - O0
    I1i1Iiiii = cachedPages [ OoO00o0 [ 'page' ] ]
   else :
    if OoO00o0 [ 'page' ] and not OoO00o0 [ 'page' ] == '' and OoO00o0 [ 'page' ] . startswith ( 'http' ) :
     if '$epoctime$' in OoO00o0 [ 'page' ] :
      OoO00o0 [ 'page' ] = OoO00o0 [ 'page' ] . replace ( '$epoctime$' , o00ooOoO0 ( ) )
     if '$epoctime2$' in OoO00o0 [ 'page' ] :
      OoO00o0 [ 'page' ] = OoO00o0 [ 'page' ] . replace ( '$epoctime2$' , o000Oo0 ( ) )
      if 55 - 55: IiII - i1iIi11iIIi1I
      if 100 - 100: O0
     o00IiI1iiII1i1i = OoO00o0 [ 'page' ] . split ( '|' )
     i1IiI = o00IiI1iiII1i1i [ 0 ]
     o0o0O00 = None
     if len ( o00IiI1iiII1i1i ) > 1 :
      o0o0O00 = o00IiI1iiII1i1i [ 1 ]
      if 68 - 68: ii1IiI1i * iIii1I11I1II1
      if 84 - 84: ii1IiI1i % iIii1I11I1II1 + i1iIi11iIIi1I . ii1IiI1i % i1iIi11iIIi1I
      if 93 - 93: O0
      if 85 - 85: i11iIiiIii % i11iIiiIii + O0 / I11i
      if 89 - 89: iII111i % i1IIi % OOooOOo
      if 53 - 53: OOooOOo * OoooooooOO . o0
      if 96 - 96: oOooOoO0Oo0O % i1IIi . i1 . O0
      if 37 - 37: i1IIi - I11i % OoooooooOO / I11i % o00O0oo
      if 48 - 48: i11iIiiIii % OOooOOo
      if 29 - 29: IiII + i11iIiiIii % Ii1I
     oOo00Ooo0o0 = urllib2 . ProxyHandler ( urllib2 . getproxies ( ) )
     if 33 - 33: Ii1I
     if 87 - 87: o0 / I1Ii111 + iIii1I11I1II1
     if 93 - 93: iIii1I11I1II1 + OOooOOo % o00O0oo
     i11III1111iIi = urllib2 . Request ( i1IiI )
     if 'proxy' in OoO00o0 :
      iii1IiI1I1 = OoO00o0 [ 'proxy' ]
      if 64 - 64: o00O0oo / O0 * o0 * o00O0oo
      if 60 - 60: Ii1I / i1IIi % ii1IiI1i / ii1IiI1i * ii1IiI1i . i11iIiiIii
      if i1IiI [ : 5 ] == "https" :
       o0oOO00 = urllib2 . ProxyHandler ( { 'https' : iii1IiI1I1 } )
       if 46 - 46: i11iIiiIii - Ii1I
      else :
       o0oOO00 = urllib2 . ProxyHandler ( { 'http' : iii1IiI1I1 } )
       if 95 - 95: i11i
      IIi = urllib2 . build_opener ( o0oOO00 )
      urllib2 . install_opener ( IIi )
      if 65 - 65: o0
      if 31 - 31: Ii1I * o0 . I1Ii111 % iII111i + I11i11Ii
     i11III1111iIi . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1' )
     iii1IiI1I1 = None
     if 47 - 47: O0 * oOooOoO0Oo0O * i1iIi11iIIi1I . i11i
     if 'referer' in OoO00o0 :
      i11III1111iIi . add_header ( 'Referer' , OoO00o0 [ 'referer' ] )
     if 'accept' in OoO00o0 :
      i11III1111iIi . add_header ( 'Accept' , OoO00o0 [ 'accept' ] )
     if 'agent' in OoO00o0 :
      i11III1111iIi . add_header ( 'User-agent' , OoO00o0 [ 'agent' ] )
     if 'x-req' in OoO00o0 :
      i11III1111iIi . add_header ( 'X-Requested-With' , OoO00o0 [ 'x-req' ] )
     if 'x-addr' in OoO00o0 :
      i11III1111iIi . add_header ( 'x-addr' , OoO00o0 [ 'x-addr' ] )
     if 'x-forward' in OoO00o0 :
      i11III1111iIi . add_header ( 'X-Forwarded-For' , OoO00o0 [ 'x-forward' ] )
     if 'setcookie' in OoO00o0 :
      if 95 - 95: iII111i % I1Ii111 . O0 % ooOoO0o
      i11III1111iIi . add_header ( 'Cookie' , OoO00o0 [ 'setcookie' ] )
     if 'appendcookie' in OoO00o0 :
      if 68 - 68: I11i11Ii . I11i11Ii - ii1IiI1i / Ii1I . o00O0oo / i1IIi
      iI1i1iIi1iiII = OoO00o0 [ 'appendcookie' ]
      iI1i1iIi1iiII = iI1i1iIi1iiII . split ( ';' )
      for o0OoO0000o in iI1i1iIi1iiII :
       o0Ii1 , IIi1IiII = o0OoO0000o . split ( '=' )
       o0IIIIiI11I , o0Ii1 = o0Ii1 . split ( ':' )
       iiiI11iIIi1 = cookielib . Cookie ( version = 0 , name = o0Ii1 , value = IIi1IiII , port = None , port_specified = False , domain = o0IIIIiI11I , domain_specified = False , domain_initial_dot = False , path = '/' , path_specified = True , secure = False , expires = None , discard = True , comment = None , comment_url = None , rest = { 'HttpOnly' : None } , rfc2109 = False )
       cookieJar . set_cookie ( iiiI11iIIi1 )
     if 'origin' in OoO00o0 :
      i11III1111iIi . add_header ( 'Origin' , OoO00o0 [ 'origin' ] )
     if o0o0O00 :
      o0o0O00 = o0o0O00 . split ( '&' )
      for o0OoO0000o in o0o0O00 :
       o0Ii1 , IIi1IiII = o0OoO0000o . split ( '=' )
       i11III1111iIi . add_header ( o0Ii1 , IIi1IiII )
       if 72 - 72: IiII * I11i
     if not cookieJar == None :
      if 67 - 67: i1IIi
      iii = urllib2 . HTTPCookieProcessor ( cookieJar )
      IIi = urllib2 . build_opener ( iii , urllib2 . HTTPBasicAuthHandler ( ) , urllib2 . HTTPHandler ( ) )
      IIi = urllib2 . install_opener ( IIi )
      if 57 - 57: oOooOoO0Oo0O
      if 35 - 35: OoooooooOO - ooOoO0o / i1iIi11iIIi1I
      if 'noredirect' in OoO00o0 :
       IIi = urllib2 . build_opener ( iii , II , urllib2 . HTTPBasicAuthHandler ( ) , urllib2 . HTTPHandler ( ) )
       IIi = urllib2 . install_opener ( IIi )
     elif 'noredirect' in OoO00o0 :
      IIi = urllib2 . build_opener ( II , urllib2 . HTTPBasicAuthHandler ( ) , urllib2 . HTTPHandler ( ) )
      IIi = urllib2 . install_opener ( IIi )
      if 50 - 50: o0
      if 33 - 33: Ii1I
     if 'connection' in OoO00o0 :
      if 98 - 98: o0 % i11i
      from keepalive import HTTPHandler
      OoO0O000 = HTTPHandler ( )
      IIi = urllib2 . build_opener ( OoO0O000 )
      urllib2 . install_opener ( IIi )
      if 14 - 14: i1iIi11iIIi1I / i1iIi11iIIi1I * O0 . OOooOOo
      if 59 - 59: i11i * i11iIiiIii
      if 54 - 54: O0 % OoooooooOO - oOooOoO0Oo0O
     OOo0OOoO00o0 = None
     if 45 - 45: i11i % o00O0oo % I1Ii111 + ii1IiI1i . i1IIi . o0
     if 'post' in OoO00o0 :
      O0o0OO00 = OoO00o0 [ 'post' ]
      if 14 - 14: ii1IiI1i + i11iIiiIii
      if 83 - 83: ii1IiI1i / i11iIiiIii + i11i . IiII * I11i + I1Ii111
      if 42 - 42: i1IIi % i11i . o00O0oo
      if 7 - 7: ii1IiI1i - OOooOOo * I11i + i1 . ii1IiI1i
      ooooO = O0o0OO00 . split ( ',' ) ;
      OOo0OOoO00o0 = { }
      for oO0O0 in ooooO :
       o0Ii1 = oO0O0 . split ( ':' ) [ 0 ] ;
       IIi1IiII = oO0O0 . split ( ':' ) [ 1 ] ;
       OOo0OOoO00o0 [ o0Ii1 ] = IIi1IiII
      OOo0OOoO00o0 = urllib . urlencode ( OOo0OOoO00o0 )
      if 19 - 19: iII111i
     if 'rawpost' in OoO00o0 :
      OOo0OOoO00o0 = OoO00o0 [ 'rawpost' ]
      if 55 - 55: I11i % I11i / O0 % IiII - i1 . I11i11Ii
      if 49 - 49: iIii1I11I1II1 * i1IIi . OoooooooOO
      if 90 - 90: i1 % ii1IiI1i - iIii1I11I1II1 % o0
      if 8 - 8: o0 * I11i11Ii / I1Ii111 % iII111i - oOooOoO0Oo0O
     I1i1Iiiii = ''
     try :
      if 71 - 71: IiII
      if OOo0OOoO00o0 :
       oO00OOoO00 = urllib2 . urlopen ( i11III1111iIi , OOo0OOoO00o0 )
      else :
       oO00OOoO00 = urllib2 . urlopen ( i11III1111iIi )
      if oO00OOoO00 . info ( ) . get ( 'Content-Encoding' ) == 'gzip' :
       from StringIO import StringIO
       import gzip
       Iiii1i11ii1Ii = StringIO ( oO00OOoO00 . read ( ) )
       i1Oo0oOo000OoO0 = gzip . GzipFile ( fileobj = Iiii1i11ii1Ii )
       I1i1Iiiii = i1Oo0oOo000OoO0 . read ( )
      else :
       I1i1Iiiii = oO00OOoO00 . read ( )
       if 25 - 25: ii1IiI1i . i1IIi . i11i / ooOoO0o
       if 54 - 54: i1IIi . Ii1I - ii1IiI1i + o00O0oo + I11i11Ii / I11i11Ii
       if 22 - 22: o00O0oo . iIii1I11I1II1
      if 'proxy' in OoO00o0 and not oOo00Ooo0o0 is None :
       urllib2 . install_opener ( urllib2 . build_opener ( oOo00Ooo0o0 ) )
       if 12 - 12: iII111i
      I1i1Iiiii = Ooii1IIi1ii ( I1i1Iiiii )
      if 85 - 85: OoooooooOO % o0 * iIii1I11I1II1
      if 44 - 44: iIii1I11I1II1 . ii1IiI1i + ooOoO0o . o00O0oo
      if 'includeheaders' in OoO00o0 :
       if 7 - 7: ii1IiI1i + iIii1I11I1II1 * Ii1I * Ii1I / i11i - iII111i
       I1i1Iiiii += '$$HEADERS_START$$:'
       for iIIIII1ii1I in oO00OOoO00 . headers :
        I1i1Iiiii += iIIIII1ii1I + ':' + oO00OOoO00 . headers . get ( iIIIII1ii1I ) + '\n'
       I1i1Iiiii += '$$HEADERS_END$$:'
       if 65 - 65: OOooOOo + o0 + i11i
      I1iI1iIi111i ( I1i1Iiiii )
      I1iI1iIi111i ( cookieJar )
      if 77 - 77: i11i
      oO00OOoO00 . close ( )
     except :
      pass
     cachedPages [ OoO00o0 [ 'page' ] ] = I1i1Iiiii
     if 50 - 50: O0 . O0 . o00O0oo % I11i11Ii
     if 68 - 68: OOooOOo
     if 10 - 10: iII111i
     if forCookieJarOnly :
      return cookieJar
    elif OoO00o0 [ 'page' ] and not OoO00o0 [ 'page' ] . startswith ( 'http' ) :
     if OoO00o0 [ 'page' ] . startswith ( '$pyFunction:' ) :
      OOOo = I1iI1IiI ( OoO00o0 [ 'page' ] . split ( '$pyFunction:' ) [ 1 ] , '' , cookieJar , OoO00o0 )
      if forCookieJarOnly :
       return cookieJar
      I1i1Iiiii = OOOo
      I1i1Iiiii = Ooii1IIi1ii ( I1i1Iiiii )
     else :
      I1i1Iiiii = OoO00o0 [ 'page' ]
   if '$pyFunction:playmedia(' in OoO00o0 [ 'expres' ] or 'ActivateWindow' in OoO00o0 [ 'expres' ] or '$PLAYERPROXY$=' in url or any ( x in url for x in o000O0o ) :
    OoIIi1iI = False
   if '$doregex' in OoO00o0 [ 'expres' ] :
    OoO00o0 [ 'expres' ] = i1iI1IIIII1 ( regexs , OoO00o0 [ 'expres' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages )
   if not OoO00o0 [ 'expres' ] == '' :
    if 46 - 46: ii1IiI1i
    if '$LiveStreamCaptcha' in OoO00o0 [ 'expres' ] :
     OOOo = oOo0Oo0O0O ( OoO00o0 , I1i1Iiiii , cookieJar )
     if 48 - 48: I11i11Ii - o00O0oo + I11i11Ii - oOooOoO0Oo0O * i11iIiiIii . IiII
     url = url . replace ( "$doregex[" + oO0Ooo0OooOOo + "]" , OOOo )
     if 35 - 35: I1Ii111 . O0 + I11i11Ii + I11i + i1IIi
    elif OoO00o0 [ 'expres' ] . startswith ( '$pyFunction:' ) or '#$pyFunction' in OoO00o0 [ 'expres' ] :
     if 65 - 65: O0 * oOooOoO0Oo0O / oOooOoO0Oo0O . o0
     OOOo = ''
     if OoO00o0 [ 'expres' ] . startswith ( '$pyFunction:' ) :
      OOOo = I1iI1IiI ( OoO00o0 [ 'expres' ] . split ( '$pyFunction:' ) [ 1 ] , I1i1Iiiii , cookieJar , OoO00o0 )
     else :
      OOOo = doEvalFunction ( OoO00o0 [ 'expres' ] , I1i1Iiiii , cookieJar , OoO00o0 )
     if 'ActivateWindow' in OoO00o0 [ 'expres' ] : return
     if 87 - 87: i11i * ii1IiI1i % I11i11Ii * I11i11Ii
     if 58 - 58: I11i . i1 + oOooOoO0Oo0O % I11i11Ii - i1iIi11iIIi1I
     if 50 - 50: IiII % i11i - o00O0oo . i1IIi + O0 % IiII
     try :
      url = url . replace ( u"$doregex[" + oO0Ooo0OooOOo + "]" , OOOo )
     except : url = url . replace ( "$doregex[" + oO0Ooo0OooOOo + "]" , OOOo . decode ( "utf-8" ) )
    else :
     if 'listrepeat' in OoO00o0 :
      i1iIi1IIiIII1 = OoO00o0 [ 'listrepeat' ]
      i1Ii11I1II = re . findall ( OoO00o0 [ 'expres' ] , I1i1Iiiii )
      return i1iIi1IIiIII1 , i1Ii11I1II , OoO00o0 , regexs
      if 77 - 77: OOooOOo - I11i11Ii - iIii1I11I1II1
     OOOo = ''
     if not I1i1Iiiii == '' :
      if 16 - 16: i1iIi11iIIi1I / IiII / i1IIi . IiII + OOooOOo
      Iiii1I = re . compile ( OoO00o0 [ 'expres' ] ) . search ( I1i1Iiiii )
      try :
       OOOo = Iiii1I . group ( 1 ) . strip ( )
      except : traceback . print_exc ( )
      if OoO00o0 [ 'page' ] == '' :
       OOOo = OoO00o0 [ 'expres' ]
       if 56 - 56: i11iIiiIii - iIii1I11I1II1 . i11i
     if rawPost :
      if 81 - 81: I1Ii111 / o0 * I1Ii111 . O0
      OOOo = urllib . quote_plus ( OOOo )
     if 'htmlunescape' in OoO00o0 :
      if 61 - 61: i1iIi11iIIi1I * I11i + ooOoO0o . iIii1I11I1II1 % Ii1I . ooOoO0o
      import HTMLParser
      OOOo = HTMLParser . HTMLParser ( ) . unescape ( OOOo )
     try :
      url = url . replace ( "$doregex[" + oO0Ooo0OooOOo + "]" , OOOo )
     except : url = url . replace ( "$doregex[" + oO0Ooo0OooOOo + "]" , OOOo . decode ( "utf-8" ) )
     if 53 - 53: ooOoO0o * I1Ii111 / iIii1I11I1II1 / oOooOoO0Oo0O % ii1IiI1i
     if 39 - 39: i1iIi11iIIi1I / OoooooooOO . i1iIi11iIIi1I * ii1IiI1i / o0
   else :
    url = url . replace ( "$doregex[" + oO0Ooo0OooOOo + "]" , '' )
 if '$epoctime$' in url :
  url = url . replace ( '$epoctime$' , o00ooOoO0 ( ) )
 if '$epoctime2$' in url :
  url = url . replace ( '$epoctime2$' , o000Oo0 ( ) )
  if 38 - 38: i1iIi11iIIi1I / o00O0oo % ooOoO0o * Ii1I + i11iIiiIii % o00O0oo
 if '$GUID$' in url :
  import uuid
  url = url . replace ( '$GUID$' , str ( uuid . uuid1 ( ) ) . upper ( ) )
 if '$get_cookies$' in url :
  url = url . replace ( '$get_cookies$' , O000oOo0O ( cookieJar ) )
  if 82 - 82: I1Ii111
 if recursiveCall : return url
 if 86 - 86: I11i11Ii * i11i * O0
 if url == "" :
  return
 else :
  return url , OoIIi1iI
  if 83 - 83: I1Ii111 / ooOoO0o
def OOo000OO000 ( t ) :
 import hashlib
 o0OoO0000o = hashlib . md5 ( )
 o0OoO0000o . update ( t )
 return o0OoO0000o . hexdigest ( )
 if 83 - 83: i1 % OOooOOo + Ii1I % i11iIiiIii + O0
def OoOOoooO000 ( encrypted ) :
 OoO0o000oOo = ""
 for OOOo in encrypted . split ( ':' ) :
  OoO0o000oOo += chr ( int ( OOOo . replace ( "0m0" , "" ) ) / 84 / 5 )
 return OoO0o000oOo
 if 88 - 88: i1IIi * ooOoO0o * OOooOOo - o00O0oo * Ii1I / OoooooooOO
def iiI1i ( media_url ) :
 try :
  import CustomPlayer
  oO0o0o00oOo0O = CustomPlayer . MyXBMCPlayer ( )
  oOOoooO0O0 = xbmcgui . ListItem ( label = str ( oOOO00o000o ) , iconImage = "DefaultVideo.png" , thumbnailImage = xbmc . getInfoImage ( "ListItem.Thumb" ) , path = media_url )
  oO0o0o00oOo0O . play ( media_url , oOOoooO0O0 )
  xbmc . sleep ( 1000 )
  while oO0o0o00oOo0O . is_active :
   xbmc . sleep ( 200 )
 except :
  traceback . print_exc ( )
 return ''
 if 46 - 46: iIii1I11I1II1
 if 33 - 33: Ii1I % Ii1I % O0 / oOooOoO0Oo0O . i1IIi
def O0O0ooOoOO0OO ( page_value , referer = None ) :
 if referer :
  referer = [ ( 'Referer' , referer ) ]
 if page_value . startswith ( "http" ) :
  I1iiIiiii1111 = page_value
  page_value = O0O00O ( page_value , headers = referer )
  if 29 - 29: iII111i - oOooOoO0Oo0O / oOooOoO0Oo0O * iII111i * I1Ii111 . I11i
 oooI11iI1I = "(eval\(function\(p,a,c,k,e,(?:r|d).*)"
 if 50 - 50: iIii1I11I1II1 * I1Ii111 . OoooooooOO / i11i - ii1IiI1i * ii1IiI1i
 OOo000o0 = re . compile ( oooI11iI1I ) . findall ( page_value )
 iIiI1 = ""
 if OOo000o0 and len ( OOo000o0 ) > 0 :
  for IIi1IiII in OOo000o0 :
   o00oo0OO0 = oO0o000OooOoo ( IIi1IiII )
   IIi11i = O00oooo00o0O ( o00oo0OO0 , '\'(.*?)\'' )
   if 'unescape' in o00oo0OO0 :
    o00oo0OO0 = urllib . unquote ( IIi11i )
   iIiI1 += o00oo0OO0 + '\n'
  print 'final value is ' , iIiI1
  if 86 - 86: iII111i
  I1iiIiiii1111 = O00oooo00o0O ( iIiI1 , 'src="(.*?)"' )
  if 29 - 29: iIii1I11I1II1 - i1iIi11iIIi1I + oOooOoO0Oo0O % iIii1I11I1II1 % I11i
  page_value = O0O00O ( I1iiIiiii1111 , headers = referer )
  if 84 - 84: I1Ii111 + ii1IiI1i + iII111i + IiII
  if 62 - 62: i11iIiiIii + o0 + i1IIi
  if 69 - 69: o0
 OO0Oo = O00oooo00o0O ( page_value , 'streamer\'.*?\'(.*?)\'\)' )
 IIiiiiiIiIIi = O00oooo00o0O ( page_value , 'file\',\s\'(.*?)\'' )
 if 26 - 26: i1
 if 12 - 12: OoooooooOO / O0 + i11i * ii1IiI1i
 return OO0Oo + ' playpath=' + IIiiiiiIiIIi + ' pageUrl=' + I1iiIiiii1111
 if 46 - 46: i11i - I1Ii111 * OoooooooOO / OOooOOo % I1Ii111
def Iii11III1I11 ( page_value , referer = None ) :
 if referer :
  referer = [ ( 'Referer' , referer ) ]
 if page_value . startswith ( "http" ) :
  page_value = O0O00O ( page_value , headers = referer )
 oooI11iI1I = "var a = (.*?);\s*var b = (.*?);\s*var c = (.*?);\s*var d = (.*?);\s*var f = (.*?);\s*var v_part = '(.*?)';"
 OOo000o0 = re . compile ( oooI11iI1I ) . findall ( page_value ) [ 0 ]
 if 40 - 40: i11iIiiIii . iIii1I11I1II1
 Iii , iIIIII1ii1I , o0oO0O00oOo , IiIIII1iiIIi , i1Oo0oOo000OoO0 , IIi1IiII = ( OOo000o0 )
 i1Oo0oOo000OoO0 = int ( i1Oo0oOo000OoO0 )
 Iii = int ( Iii ) / i1Oo0oOo000OoO0
 iIIIII1ii1I = int ( iIIIII1ii1I ) / i1Oo0oOo000OoO0
 o0oO0O00oOo = int ( o0oO0O00oOo ) / i1Oo0oOo000OoO0
 IiIIII1iiIIi = int ( IiIIII1iiIIi ) / i1Oo0oOo000OoO0
 if 17 - 17: Ii1I
 i1Ii11I1II = 'rtmp://' + str ( Iii ) + '.' + str ( iIIIII1ii1I ) + '.' + str ( o0oO0O00oOo ) + '.' + str ( IiIIII1iiIIi ) + IIi1IiII ;
 return i1Ii11I1II
 if 97 - 97: ii1IiI1i * ii1IiI1i / IiII
def i1111IIiI ( url , useragent = None ) :
 str = '#EXTM3U'
 str += '\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=361816'
 str += '\n' + url + '&bytes=0-200000'
 OOooo0O00o = os . path . join ( O0oOoOOOoOO , 'testfile.m3u' )
 str += '\n'
 I11I1IIii ( OOooo0O00o , str )
 if 90 - 90: o0 + oOooOoO0Oo0O * I11i
 return OOooo0O00o
 if 3 - 3: oOooOoO0Oo0O / i1IIi
def I11I1IIii ( file_name , page_data , append = False ) :
 if append :
  i1Oo0oOo000OoO0 = open ( file_name , 'a' )
  i1Oo0oOo000OoO0 . write ( page_data )
  i1Oo0oOo000OoO0 . close ( )
 else :
  i1Oo0oOo000OoO0 = open ( file_name , 'wb' )
  i1Oo0oOo000OoO0 . write ( page_data )
  i1Oo0oOo000OoO0 . close ( )
  return ''
  if 22 - 22: OOooOOo + I11i * i11i . o00O0oo % I11i % Ii1I
def OOo00ooOoO0o ( file_name ) :
 i1Oo0oOo000OoO0 = open ( file_name , 'rb' )
 IiIIII1iiIIi = i1Oo0oOo000OoO0 . read ( )
 i1Oo0oOo000OoO0 . close ( )
 return IiIIII1iiIIi
 if 21 - 21: i11iIiiIii
def o00iIiiiII ( page_data ) :
 import re , base64 , urllib ;
 Ii1I1 = page_data
 while 'geh(' in Ii1I1 :
  if Ii1I1 . startswith ( 'lol(' ) : Ii1I1 = Ii1I1 [ 5 : - 1 ]
  if 71 - 71: o0 + iIii1I11I1II1 * OOooOOo . ooOoO0o % i11iIiiIii % iIii1I11I1II1
  Ii1I1 = re . compile ( '"(.*?)"' ) . findall ( Ii1I1 ) [ 0 ] ;
  Ii1I1 = base64 . b64decode ( Ii1I1 ) ;
  Ii1I1 = urllib . unquote ( Ii1I1 ) ;
 print Ii1I1
 return Ii1I1
 if 63 - 63: OoooooooOO * i1iIi11iIIi1I / Ii1I - OOooOOo . iIii1I11I1II1 + IiII
def ii1IIiI1IIi ( page_data ) :
 print 'get_dag_url2' , page_data
 o0OO = O0O00O ( page_data ) ;
 IIiii11ii1i = '(http.*)'
 import uuid
 II1iI1IIi = str ( uuid . uuid1 ( ) ) . upper ( )
 Ii11iiI1 = re . compile ( IIiii11ii1i ) . findall ( o0OO )
 oO0O = [ ( 'X-Playback-Session-Id' , II1iI1IIi ) ]
 for OOoooO00o0o in Ii11iiI1 :
  try :
   I1ii1Ii1 = O0O00O ( OOoooO00o0o , headers = oO0O ) ;
   if 73 - 73: O0 . OOooOOo + i11iIiiIii + iIii1I11I1II1 - Ii1I / o0
  except : pass
  if 99 - 99: ii1IiI1i * OOooOOo * ii1IiI1i - i11i + iII111i
 return page_data + '|&X-Playback-Session-Id=' + II1iI1IIi
 if 72 - 72: i1 % oOooOoO0Oo0O / IiII - O0 + Ii1I
 if 83 - 83: O0
def oOOOOOo ( page_data ) :
 print 'get_dag_url' , page_data
 if page_data . startswith ( 'http://dag.total-stream.net' ) :
  oO0O = [ ( 'User-Agent' , 'Verismo-BlackUI_(2.4.7.5.8.0.34)' ) ]
  page_data = O0O00O ( page_data , headers = oO0O ) ;
  if 50 - 50: ooOoO0o + o00O0oo + IiII
 if '127.0.0.1' in page_data :
  return ii11iiI11I ( page_data )
 elif O00oooo00o0O ( page_data , 'wmsAuthSign%3D([^%&]+)' ) != '' :
  OoOooO = O00oooo00o0O ( page_data , '&ver_t=([^&]+)&' ) + '?wmsAuthSign=' + O00oooo00o0O ( page_data , 'wmsAuthSign%3D([^%&]+)' ) + '==/mp4:' + O00oooo00o0O ( page_data , '\\?y=([^&]+)&' )
 else :
  OoOooO = O00oooo00o0O ( page_data , 'href="([^"]+)"[^"]+$' )
  if len ( OoOooO ) == 0 :
   OoOooO = page_data
 OoOooO = OoOooO . replace ( ' ' , '%20' )
 return OoOooO
 if 100 - 100: iII111i + iIii1I11I1II1
def O00oooo00o0O ( data , re_patten ) :
 OoOo00o0OO = ''
 OoO00o0 = re . search ( re_patten , data )
 if OoO00o0 != None :
  OoOo00o0OO = OoO00o0 . group ( 1 )
 else :
  OoOo00o0OO = ''
 return OoOo00o0OO
 if 59 - 59: I1Ii111
def ii11iiI11I ( page_data ) :
 OoOooO = ''
 if '127.0.0.1' in page_data :
  OoOooO = O00oooo00o0O ( page_data , '&ver_t=([^&]+)&' ) + ' live=true timeout=15 playpath=' + O00oooo00o0O ( page_data , '\\?y=([a-zA-Z0-9-_\\.@]+)' )
  if 89 - 89: o0 % iIii1I11I1II1
 if O00oooo00o0O ( page_data , 'token=([^&]+)&' ) != '' :
  OoOooO = OoOooO + '?token=' + O00oooo00o0O ( page_data , 'token=([^&]+)&' )
 elif O00oooo00o0O ( page_data , 'wmsAuthSign%3D([^%&]+)' ) != '' :
  OoOooO = O00oooo00o0O ( page_data , '&ver_t=([^&]+)&' ) + '?wmsAuthSign=' + O00oooo00o0O ( page_data , 'wmsAuthSign%3D([^%&]+)' ) + '==/mp4:' + O00oooo00o0O ( page_data , '\\?y=([^&]+)&' )
 else :
  OoOooO = O00oooo00o0O ( page_data , 'HREF="([^"]+)"' )
  if 35 - 35: ii1IiI1i + ooOoO0o - o0 % OOooOOo % i1 % o0
 if 'dag1.asx' in OoOooO :
  return oOOOOOo ( OoOooO )
  if 45 - 45: oOooOoO0Oo0O * I11i % i1iIi11iIIi1I
 if 'devinlivefs.fplive.net' not in OoOooO :
  OoOooO = OoOooO . replace ( 'devinlive' , 'flive' )
 if 'permlivefs.fplive.net' not in OoOooO :
  OoOooO = OoOooO . replace ( 'permlive' , 'flive' )
 return OoOooO
 if 24 - 24: o00O0oo - Ii1I * OOooOOo
 if 87 - 87: iII111i - ii1IiI1i % ii1IiI1i . OOooOOo / ii1IiI1i
def II1i ( str_eval ) :
 o0II1IIi1iII1i = ""
 try :
  iiiiIiIi = "w,i,s,e=(" + str_eval + ')'
  exec ( iiiiIiIi )
  o0II1IIi1iII1i = iiIiI1 ( w , i , s , e )
 except : traceback . print_exc ( file = sys . stdout )
 if 13 - 13: ii1IiI1i % o0
 return o0II1IIi1iII1i
 if 76 - 76: O0 . i1iIi11iIIi1I + o0
def iiIiI1 ( w , i , s , e ) :
 ii11iI1iIiIi = 0 ;
 o0OO0OoO0o0o0 = 0 ;
 IIIIIIi1IiIi = 0 ;
 III1i = [ ] ;
 o0Oo0 = [ ] ;
 while True :
  if ( ii11iI1iIiIi < 5 ) :
   o0Oo0 . append ( w [ ii11iI1iIiIi ] )
  elif ( ii11iI1iIiIi < len ( w ) ) :
   III1i . append ( w [ ii11iI1iIiIi ] ) ;
  ii11iI1iIiIi += 1 ;
  if ( o0OO0OoO0o0o0 < 5 ) :
   o0Oo0 . append ( i [ o0OO0OoO0o0o0 ] )
  elif ( o0OO0OoO0o0o0 < len ( i ) ) :
   III1i . append ( i [ o0OO0OoO0o0o0 ] )
  o0OO0OoO0o0o0 += 1 ;
  if ( IIIIIIi1IiIi < 5 ) :
   o0Oo0 . append ( s [ IIIIIIi1IiIi ] )
  elif ( IIIIIIi1IiIi < len ( s ) ) :
   III1i . append ( s [ IIIIIIi1IiIi ] ) ;
  IIIIIIi1IiIi += 1 ;
  if ( len ( w ) + len ( i ) + len ( s ) + len ( e ) == len ( III1i ) + len ( o0Oo0 ) + len ( e ) ) :
   break ;
   if 35 - 35: i11iIiiIii - OOooOOo % i11iIiiIii
 II111I1Iii = '' . join ( III1i )
 OO00Oo00oO = '' . join ( o0Oo0 )
 o0OO0OoO0o0o0 = 0 ;
 ooo0 = [ ] ;
 for ii11iI1iIiIi in range ( 0 , len ( III1i ) , 2 ) :
  if 36 - 36: OOooOOo
  IIIi = - 1 ;
  if ( ord ( OO00Oo00oO [ o0OO0OoO0o0o0 ] ) % 2 ) :
   IIIi = 1 ;
   if 91 - 91: OoooooooOO / I11i11Ii % ii1IiI1i * ii1IiI1i + I11i
  ooo0 . append ( chr ( int ( II111I1Iii [ ii11iI1iIiIi : ii11iI1iIiIi + 2 ] , 36 ) - IIIi ) ) ;
  o0OO0OoO0o0o0 += 1 ;
  if ( o0OO0OoO0o0o0 >= len ( o0Oo0 ) ) :
   o0OO0OoO0o0o0 = 0 ;
 i1Ii11I1II = '' . join ( ooo0 )
 if 'eval(function(w,i,s,e)' in i1Ii11I1II :
  print 'STILL GOing'
  i1Ii11I1II = re . compile ( 'eval\(function\(w,i,s,e\).*}\((.*?)\)' ) . findall ( i1Ii11I1II ) [ 0 ]
  return II1i ( i1Ii11I1II )
 else :
  print 'FINISHED'
  return i1Ii11I1II
  if 57 - 57: O0 - O0 . ii1IiI1i / i1 / iII111i
def oO0o000OooOoo ( page_value , regex_for_text = '' , iterations = 1 , total_iteration = 1 ) :
 try :
  I1IiII1I1i1I1 = None
  if page_value . startswith ( "http" ) :
   page_value = O0O00O ( page_value )
  print 'page_value' , page_value
  if regex_for_text and len ( regex_for_text ) > 0 :
   page_value = re . compile ( regex_for_text ) . findall ( page_value ) [ 0 ]
   if 28 - 28: I11i11Ii + I1Ii111 % i11i / i1iIi11iIIi1I + i11iIiiIii
  page_value = ii11Iiii ( page_value , iterations , total_iteration )
 except : traceback . print_exc ( file = sys . stdout )
 print 'unpacked' , page_value
 if 'sav1live.tv' in page_value :
  page_value = page_value . replace ( 'sav1live.tv' , 'sawlive.tv' )
  print 'sav1 unpacked' , page_value
 return page_value
 if 32 - 32: o0 . ii1IiI1i % oOooOoO0Oo0O - i11i
def ii11Iiii ( sJavascript , iteration = 1 , totaliterations = 2 ) :
 print 'iteration' , iteration
 if sJavascript . startswith ( 'var _0xcb8a=' ) :
  iiI111 = sJavascript . split ( 'var _0xcb8a=' )
  iiiiIiIi = "myarray=" + iiI111 [ 1 ] . split ( "eval(" ) [ 0 ]
  exec ( iiiiIiIi )
  OOoooo0oo = 62
  oOo0O = int ( iiI111 [ 1 ] . split ( ",62," ) [ 1 ] . split ( ',' ) [ 0 ] )
  i1i = myarray [ 0 ]
  OO = myarray [ 3 ]
  with open ( 'temp file' + str ( iteration ) + '.js' , "wb" ) as OO00OoooO :
   OO00OoooO . write ( str ( OO ) )
   if 7 - 7: ii1IiI1i / i11i - Ii1I + i1IIi + iII111i
 else :
  if 7 - 7: o00O0oo + iII111i
  iiI111 = sJavascript . split ( "rn p}('" )
  print iiI111
  if 32 - 32: iIii1I11I1II1 % oOooOoO0Oo0O / i11iIiiIii + I11i - i1 . IiII
  i1i , OOoooo0oo , oOo0O , OO = ( '' , '0' , '0' , '' )
  if 86 - 86: i1IIi / iII111i * oOooOoO0Oo0O
  iiiiIiIi = "p1,a1,c1,k1=('" + iiI111 [ 1 ] . split ( ".spli" ) [ 0 ] + ')'
  exec ( iiiiIiIi )
 OO = OO . split ( '|' )
 iiI111 = iiI111 [ 1 ] . split ( "))'" )
 if 67 - 67: ii1IiI1i * ii1IiI1i / OOooOOo * OoooooooOO + o0
 if 79 - 79: i1IIi
 if 1 - 1: OOooOOo / i1IIi
 if 74 - 74: Ii1I / OoooooooOO / I11i11Ii * i11iIiiIii . i11i . OoooooooOO
 if 59 - 59: i11iIiiIii . OoooooooOO / Ii1I * ii1IiI1i + OoooooooOO
 if 3 - 3: i11iIiiIii * I11i11Ii % iIii1I11I1II1 % oOooOoO0Oo0O * IiII / I11i
 if 95 - 95: I1Ii111 * O0 * ooOoO0o . OoooooooOO % I11i11Ii + ii1IiI1i
 if 98 - 98: OOooOOo . OoooooooOO
 if 54 - 54: O0 / I1Ii111 % o00O0oo * i1IIi * O0
 if 48 - 48: i1 . OOooOOo % o0 - o0
 if 33 - 33: Ii1I % i11i + i1iIi11iIIi1I
 if 93 - 93: i1IIi . I1Ii111 / oOooOoO0Oo0O + I1Ii111
 if 58 - 58: ii1IiI1i + O0 . I11i11Ii + o0 - i1iIi11iIIi1I - o0
 if 41 - 41: I11i11Ii / i1IIi / I11i11Ii - IiII . i1
 if 65 - 65: O0 * i11iIiiIii . OoooooooOO / oOooOoO0Oo0O / IiII
 if 69 - 69: o00O0oo % o00O0oo
 if 76 - 76: i11iIiiIii * IiII / i1iIi11iIIi1I % ii1IiI1i + I11i
 if 48 - 48: iIii1I11I1II1 % i1IIi + o0 % i1
 if 79 - 79: o0 % oOooOoO0Oo0O % iII111i / i1IIi % i1iIi11iIIi1I
 if 56 - 56: iIii1I11I1II1 - i11iIiiIii * IiII
 if 84 - 84: I11i + iII111i + i1
 if 33 - 33: iII111i
 IiII111i1i11 = ''
 IiIIII1iiIIi = ''
 if 93 - 93: o00O0oo
 if 34 - 34: OOooOOo - o00O0oo * I11i11Ii / i1
 iI1iiIi1 = str ( i1iiiIi1Iii ( i1i , OOoooo0oo , oOo0O , OO , IiII111i1i11 , IiIIII1iiIIi , iteration ) )
 if 54 - 54: o00O0oo . iIii1I11I1II1 * i1IIi
 if 44 - 44: OOooOOo + ii1IiI1i * I11i - i11iIiiIii / iIii1I11I1II1
 if 7 - 7: i1 % I1Ii111 * o0
 if 58 - 58: I1Ii111 / Ii1I + i11i % IiII - OoooooooOO
 if 25 - 25: o0 % OoooooooOO * I11i11Ii - i1IIi * i11i * OOooOOo
 if iteration >= totaliterations :
  if 30 - 30: Ii1I % o0 / ii1IiI1i * O0 * iII111i . oOooOoO0Oo0O
  return iI1iiIi1
 else :
  if 46 - 46: o0 - O0
  return ii11Iiii ( iI1iiIi1 , iteration + 1 )
  if 70 - 70: Ii1I + I11i11Ii * iIii1I11I1II1 . oOooOoO0Oo0O * Ii1I
def i1iiiIi1Iii ( p , a , c , k , e , d , iteration , v = 1 ) :
 if 49 - 49: i1
 if 25 - 25: IiII . OoooooooOO * iIii1I11I1II1 . i1 / O0 + iII111i
 if 68 - 68: I11i11Ii
 while ( c >= 1 ) :
  c = c - 1
  if ( k [ c ] ) :
   ii111I11Ii = str ( i11IiiI1Ii1 ( c , a ) )
   if v == 1 :
    p = re . sub ( '\\b' + ii111I11Ii + '\\b' , k [ c ] , p )
   else :
    p = I1iiIiiIiiI ( p , ii111I11Ii , k [ c ] )
    if 94 - 94: i1IIi
    if 36 - 36: oOooOoO0Oo0O + I11i11Ii
    if 46 - 46: IiII
    if 65 - 65: i1IIi . ii1IiI1i / o00O0oo
    if 11 - 11: I1Ii111 * o00O0oo / o00O0oo - I11i
    if 68 - 68: oOooOoO0Oo0O % I1Ii111 - I1Ii111 / oOooOoO0Oo0O + ii1IiI1i - I11i11Ii
 return p
 if 65 - 65: o00O0oo - i1IIi
 if 62 - 62: Ii1I / OOooOOo % I11i11Ii . OoooooooOO / i11iIiiIii / ooOoO0o
 if 60 - 60: oOooOoO0Oo0O % OOooOOo / i1 % OOooOOo * i11iIiiIii / IiII
def I1iiIiiIiiI ( source_str , word_to_find , replace_with ) :
 i1Ii11II = None
 i1Ii11II = source_str . split ( word_to_find )
 if len ( i1Ii11II ) > 1 :
  i1iiiiI11ii = [ ]
  oooooOOo0o = 0
  for oOO0 in i1Ii11II :
   if 77 - 77: i11iIiiIii % I1Ii111 + ooOoO0o % OoooooooOO - Ii1I
   i1iiiiI11ii . append ( oOO0 )
   OOOo = word_to_find
   if 26 - 26: I11i11Ii + O0 - iIii1I11I1II1
   if 47 - 47: OoooooooOO
   if oooooOOo0o == len ( i1Ii11II ) - 1 :
    OOOo = ''
   else :
    if len ( oOO0 ) == 0 :
     if ( len ( i1Ii11II [ oooooOOo0o + 1 ] ) == 0 and word_to_find [ 0 ] . lower ( ) not in 'abcdefghijklmnopqrstuvwxyz1234567890_' ) or ( len ( i1Ii11II [ oooooOOo0o + 1 ] ) > 0 and i1Ii11II [ oooooOOo0o + 1 ] [ 0 ] . lower ( ) not in 'abcdefghijklmnopqrstuvwxyz1234567890_' ) :
      OOOo = replace_with
      if 2 - 2: o0 % ooOoO0o * I11i11Ii * o0
    else :
     if ( i1Ii11II [ oooooOOo0o ] [ - 1 ] . lower ( ) not in 'abcdefghijklmnopqrstuvwxyz1234567890_' ) and ( ( len ( i1Ii11II [ oooooOOo0o + 1 ] ) == 0 and word_to_find [ 0 ] . lower ( ) not in 'abcdefghijklmnopqrstuvwxyz1234567890_' ) or ( len ( i1Ii11II [ oooooOOo0o + 1 ] ) > 0 and i1Ii11II [ oooooOOo0o + 1 ] [ 0 ] . lower ( ) not in 'abcdefghijklmnopqrstuvwxyz1234567890_' ) ) :
      OOOo = replace_with
      if 65 - 65: i11iIiiIii + I11i11Ii * OoooooooOO - i1iIi11iIIi1I
   i1iiiiI11ii . append ( OOOo )
   oooooOOo0o += 1
   if 26 - 26: i1 % I11i + I11i % Ii1I * i11iIiiIii / IiII
  source_str = '' . join ( i1iiiiI11ii )
 return source_str
 if 64 - 64: OOooOOo % o0 / i11i % o00O0oo - IiII
def I1II1IiI1 ( num , radix ) :
 if 26 - 26: I11i * I11i11Ii
 i11 = ""
 if num == 0 : return '0'
 while num > 0 :
  i11 = "0123456789abcdefghijklmnopqrstuvwxyz" [ num % radix ] + i11
  num /= radix
 return i11
 if 31 - 31: Ii1I * OOooOOo . iII111i
def i11IiiI1Ii1 ( cc , a ) :
 ii111I11Ii = "" if cc < a else i11IiiI1Ii1 ( int ( cc / a ) , a )
 cc = ( cc % a )
 i1Ii11ii1I = chr ( cc + 29 ) if cc > 35 else str ( I1II1IiI1 ( cc , 36 ) )
 return ii111I11Ii + i1Ii11ii1I
 if 66 - 66: I11i11Ii / OoooooooOO % ooOoO0o / IiII + OoooooooOO
 if 6 - 6: i11i % ooOoO0o
def Iii1iI ( url , headers = None ) :
 try :
  if headers is None :
   if 41 - 41: I1Ii111 - i11i . i11i + oOooOoO0Oo0O
   if 59 - 59: iIii1I11I1II1 % iII111i . i11iIiiIii
   headers = { '\x55\x73\x65\x72\x2d\x61\x67\x65\x6e\x74' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0)/Apollo Gecko/20100101 Firefox/19.0' , 'Apollo' : 'Direitos Reservados' , 'Referer' : 'https://deus-apollo.ml' , 'Ref' : 'copyright © 2017-2020' , 'DEUS' : 'Apollo' }
  i11III1111iIi = urllib2 . Request ( url , None , headers )
  oO00OOoO00 = urllib2 . urlopen ( i11III1111iIi )
  IiI111111IIII = oO00OOoO00 . read ( )
  oO00OOoO00 . close ( )
  return IiI111111IIII
 except urllib2 . URLError , IiII111i1i11 :
  I1iI1iIi111i ( 'URL: ' + url )
  if hasattr ( IiII111i1i11 , 'code' ) :
   I1iI1iIi111i ( 'Falha com o código de erro - %s.' % IiII111i1i11 . code )
   if 59 - 59: i1 . OOooOOo . iII111i * o0 * i1iIi11iIIi1I + I11i11Ii
   if 90 - 90: ooOoO0o % I11i11Ii - I11i11Ii . iIii1I11I1II1 / I11i + Ii1I
   xbmc . executebuiltin ( "XBMC.Notification(Falha, código de erro - " + str ( IiII111i1i11 . code ) + ",10000," + oOO00Oo + ")" )
  elif hasattr ( IiII111i1i11 , 'reason' ) :
   I1iI1iIi111i ( 'Falha ao acessar um servidor.' )
   I1iI1iIi111i ( 'Razão: %s' % IiII111i1i11 . reason )
   if 89 - 89: OOooOOo
   xbmc . executebuiltin ( "XBMC.Notification(Falha, motivo - " + str ( IiII111i1i11 . reason ) + ",10000," + oOO00Oo + ")" )
   if 87 - 87: IiII % I11i11Ii
   if 62 - 62: i1iIi11iIIi1I + o00O0oo / IiII * i11iIiiIii
   if 37 - 37: IiII
def O000oOo0O ( cookieJar ) :
 try :
  iIIiI1111 = ""
  for ooOO0OoO , OooOO in enumerate ( cookieJar ) :
   iIIiI1111 += OooOO . name + "=" + OooOO . value + ";"
 except : pass
 if 86 - 86: iII111i . I11i / I1Ii111 - OoooooooOO
 return iIIiI1111
 if 45 - 45: I11i
 if 25 - 25: I11i % O0
def II1 ( cookieJar , COOKIEFILE ) :
 try :
  o0o = os . path . join ( O0oOoOOOoOO , COOKIEFILE )
  cookieJar . save ( o0o , ignore_discard = True )
 except : pass
 if 44 - 44: ooOoO0o . iII111i * i11i / I1Ii111 + iIii1I11I1II1
def OOoOoo00Oo ( COOKIEFILE ) :
 if 14 - 14: O0 % I1Ii111 % iII111i * OOooOOo
 o0OOO00ooo = None
 if COOKIEFILE :
  try :
   o0o = os . path . join ( O0oOoOOOoOO , COOKIEFILE )
   o0OOO00ooo = cookielib . LWPCookieJar ( )
   o0OOO00ooo . load ( o0o , ignore_discard = True )
  except :
   o0OOO00ooo = None
   if 9 - 9: Ii1I * I11i11Ii . o00O0oo * i11iIiiIii - O0
 if not o0OOO00ooo :
  o0OOO00ooo = cookielib . LWPCookieJar ( )
  if 54 - 54: oOooOoO0Oo0O * I11i + i1 % i1IIi - i1 + o0
 return o0OOO00ooo
 if 15 - 15: o0 * OOooOOo + I11i . Ii1I % oOooOoO0Oo0O - o00O0oo
def I1iI1IiI ( fun_call , page_data , Cookie_Jar ) :
 II1I1I1i1i = ''
 if oOOoOooOo not in sys . path :
  sys . path . append ( oOOoOooOo )
  if 74 - 74: O0 % OoooooooOO * I11i11Ii + I11i * IiII
 print fun_call
 try :
  O000OO = 'import ' + fun_call . split ( '.' ) [ 0 ]
  print O000OO , sys . path
  exec ( O000OO )
  print 'done'
 except :
  print 'error in import'
  traceback . print_exc ( file = sys . stdout )
 print 'ret_val=' + fun_call
 exec ( 'ret_val=' + fun_call )
 print II1I1I1i1i
 if 29 - 29: I1Ii111 / iIii1I11I1II1 + ii1IiI1i % IiII % Ii1I
 return str ( II1I1I1i1i )
 if 46 - 46: iIii1I11I1II1
def oo0oO00o0O00o ( url ) :
 o0OOOooO00OO00O = O0O00O ( url )
 OoOOooO0O = ""
 Ii11iIII = ""
 o0ooOO0OOO00o = "<script.*?src=\"(.*?recap.*?)\""
 OoOo00o0OO = re . findall ( o0ooOO0OOO00o , o0OOOooO00OO00O )
 OoOoO0ooooO0 = False
 IIII1ii1 = None
 Ii11iIII = None
 if 52 - 52: i1iIi11iIIi1I - I11i - o00O0oo - i1 + i1IIi
 if OoOo00o0OO and len ( OoOo00o0OO ) > 0 :
  Iii1 = OoOo00o0OO [ 0 ]
  OoOoO0ooooO0 = True
  if 96 - 96: I11i11Ii / OOooOOo . i11i . I11i11Ii
  ooIi111iII = 'challenge.*?\'(.*?)\''
  Oo0OoOo = '\'(.*?)\''
  iiIIIi1i = O0O00O ( Iii1 )
  OoOOooO0O = re . findall ( ooIi111iII , iiIIIi1i ) [ 0 ]
  iIi1i1i1II11I = 'http://www.google.com/recaptcha/api/reload?c=' ;
  O0OO = Iii1 . split ( 'k=' ) [ 1 ]
  iIi1i1i1II11I += OoOOooO0O + '&k=' + O0OO + '&captcha_k=1&type=image&lang=en-GB'
  OO0OooOo = O0O00O ( iIi1i1i1II11I )
  IIII1ii1 = re . findall ( Oo0OoOo , OO0OooOo ) [ 0 ]
  ii111iI1i1 = 'http://www.google.com/recaptcha/api/image?c=' + IIII1ii1
  if not ii111iI1i1 . startswith ( "http" ) :
   ii111iI1i1 = 'http://www.google.com/recaptcha/api/' + ii111iI1i1
  import random
  o0Ii1 = random . randrange ( 100 , 1000 , 5 )
  OO000 = os . path . join ( O0oOoOOOoOO , str ( o0Ii1 ) + "captcha.img" )
  IIiii11ii1II1 = open ( OO000 , "wb" )
  IIiii11ii1II1 . write ( O0O00O ( ii111iI1i1 ) )
  IIiii11ii1II1 . close ( )
  o0OO000O = O000o0000O ( captcha = OO000 )
  Ii11iIII = o0OO000O . get ( )
  os . remove ( OO000 )
 return IIII1ii1 , Ii11iIII
 if 61 - 61: I11i * i1 * O0 / IiII
def O0O00O ( url , cookieJar = None , post = None , timeout = 20 , headers = None ) :
 if 52 - 52: I11i11Ii + iIii1I11I1II1 + i1IIi * iII111i - i11i . i11i
 if 22 - 22: i1IIi - ooOoO0o / IiII - o0 . OOooOOo
 iii = urllib2 . HTTPCookieProcessor ( cookieJar )
 IIi = urllib2 . build_opener ( iii , urllib2 . HTTPBasicAuthHandler ( ) , urllib2 . HTTPHandler ( ) )
 if 49 - 49: oOooOoO0Oo0O - i11iIiiIii + I1Ii111
 i11III1111iIi = urllib2 . Request ( url )
 i11III1111iIi . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.154 Safari/537.36' )
 if headers :
  for o0OoO0000o , iIi in headers :
   i11III1111iIi . add_header ( o0OoO0000o , iIi )
   if 52 - 52: iIii1I11I1II1
 oO00OOoO00 = IIi . open ( i11III1111iIi , post , timeout = timeout )
 I1i1Iiiii = oO00OOoO00 . read ( )
 oO00OOoO00 . close ( )
 return I1i1Iiiii ;
 if 49 - 49: I11i
def iIi1i ( str , reg = None ) :
 if reg :
  str = re . findall ( reg , str ) [ 0 ]
 III = urllib . unquote ( str [ 0 : len ( str ) - 1 ] ) ;
 IiiI = '' ;
 for iII1I1IiI11ii in range ( len ( III ) ) :
  IiiI += chr ( ord ( III [ iII1I1IiI11ii ] ) - III [ len ( III ) - 1 ] ) ;
 IiiI = urllib . unquote ( IiiI )
 print IiiI
 return IiiI
 if 75 - 75: OoooooooOO . I11i + i1iIi11iIIi1I / iII111i - oOooOoO0Oo0O % iII111i
def Ooii1IIi1ii ( str ) :
 O0OooooO0o0O0 = re . findall ( 'unescape\(\'(.*?)\'' , str )
 print 'js' , O0OooooO0o0O0
 if ( not O0OooooO0o0O0 == None ) and len ( O0OooooO0o0O0 ) > 0 :
  for oO0oo in O0OooooO0o0O0 :
   if 52 - 52: I1Ii111 % o00O0oo
   str = str . replace ( oO0oo , urllib . unquote ( oO0oo ) )
 return str
 if 25 - 25: Ii1I / Ii1I % OoooooooOO - ii1IiI1i * OOooOOo
i1oooOoOoOO = 0
def oOo0Oo0O0O ( m , html_page , cookieJar ) :
 global i1oooOoOoOO
 i1oooOoOoOO += 1
 OooOOii = m [ 'expre' ]
 I1iiIiiii1111 = m [ 'page' ]
 o0oo0Oo = re . compile ( '\$LiveStreamCaptcha\[([^\]]*)\]' ) . findall ( OooOOii ) [ 0 ]
 if 10 - 10: ii1IiI1i
 Iii1 = re . compile ( o0oo0Oo ) . findall ( html_page ) [ 0 ]
 print OooOOii , o0oo0Oo , Iii1
 if not Iii1 . startswith ( "http" ) :
  oO0OOOoO0o = 'http://' + "" . join ( I1iiIiiii1111 . split ( '/' ) [ 2 : 3 ] )
  if Iii1 . startswith ( "/" ) :
   Iii1 = oO0OOOoO0o + Iii1
  else :
   Iii1 = oO0OOOoO0o + '/' + Iii1
   if 75 - 75: ii1IiI1i
 OO000 = os . path . join ( O0oOoOOOoOO , str ( i1oooOoOoOO ) + "captcha.jpg" )
 IIiii11ii1II1 = open ( OO000 , "wb" )
 print ' c capurl' , Iii1
 i11III1111iIi = urllib2 . Request ( Iii1 )
 i11III1111iIi . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1' )
 if 'refer' in m :
  i11III1111iIi . add_header ( 'Referer' , m [ 'refer' ] )
 if 'agent' in m :
  i11III1111iIi . add_header ( 'User-agent' , m [ 'agent' ] )
 if 'setcookie' in m :
  print 'adding cookie' , m [ 'setcookie' ]
  i11III1111iIi . add_header ( 'Cookie' , m [ 'setcookie' ] )
  if 92 - 92: Ii1I / O0 * oOooOoO0Oo0O - Ii1I
  if 99 - 99: i11iIiiIii % OoooooooOO
  if 56 - 56: I1Ii111 * ooOoO0o
  if 98 - 98: Ii1I + O0 * ooOoO0o + i11iIiiIii - I11i - iIii1I11I1II1
 urllib2 . urlopen ( i11III1111iIi )
 oO00OOoO00 = urllib2 . urlopen ( i11III1111iIi )
 if 5 - 5: I11i % I11i11Ii % I1Ii111 % o00O0oo
 IIiii11ii1II1 . write ( oO00OOoO00 . read ( ) )
 oO00OOoO00 . close ( )
 IIiii11ii1II1 . close ( )
 o0OO000O = O000o0000O ( captcha = OO000 )
 Ii11iIII = o0OO000O . get ( )
 return Ii11iIII
 if 17 - 17: iII111i + i11i + OoooooooOO / I11i / I1Ii111
class O000o0000O ( xbmcgui . WindowDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  self . cptloc = kwargs . get ( 'captcha' )
  self . img = xbmcgui . ControlImage ( 335 , 30 , 624 , 60 , self . cptloc )
  self . addControl ( self . img )
  self . kbd = xbmc . Keyboard ( )
  if 80 - 80: i1 % i1IIi / Ii1I
 def get ( self ) :
  self . show ( )
  time . sleep ( 2 )
  self . kbd . doModal ( )
  if ( self . kbd . isConfirmed ( ) ) :
   ooi1i1Ii1IiIII = self . kbd . getText ( )
   self . close ( )
   return ooi1i1Ii1IiIII
  self . close ( )
  return False
  if 9 - 9: Ii1I - OOooOOo + O0 / IiII % i1IIi
def o00ooOoO0 ( ) :
 import time
 return str ( int ( time . time ( ) * 1000 ) )
 if 97 - 97: i1 * o00O0oo
def o000Oo0 ( ) :
 import time
 return str ( int ( time . time ( ) ) )
 if 78 - 78: Ii1I . I11i + OOooOOo * IiII - i1IIi
def I1ii1I1iii1 ( ) :
 iIiiiIIiii = [ ]
 OO0 = sys . argv [ 2 ]
 if len ( OO0 ) >= 2 :
  Oo00Oo = sys . argv [ 2 ]
  iIiO0O = Oo00Oo . replace ( '?' , '' )
  if ( Oo00Oo [ len ( Oo00Oo ) - 1 ] == '/' ) :
   Oo00Oo = Oo00Oo [ 0 : len ( Oo00Oo ) - 2 ]
  oOOoooo = iIiO0O . split ( '&' )
  iIiiiIIiii = { }
  for iII1I1IiI11ii in range ( len ( oOOoooo ) ) :
   O0o = { }
   O0o = oOOoooo [ iII1I1IiI11ii ] . split ( '=' )
   if ( len ( O0o ) ) == 2 :
    iIiiiIIiii [ O0o [ 0 ] ] = O0o [ 1 ]
 return iIiiiIIiii
 if 30 - 30: iIii1I11I1II1 * i11iIiiIii * iIii1I11I1II1 + I11i
 if 23 - 23: I1Ii111 + iIii1I11I1II1 % iIii1I11I1II1 / o00O0oo . OOooOOo + iIii1I11I1II1
def OOoOO0o0o0Oo ( ) :
 I1i = json . loads ( open ( O00OOOoOoo0O ) . read ( ) )
 ii1IIIIiI11 = len ( I1i )
 for iII1I1IiI11ii in I1i :
  oOOO00o000o = iII1I1IiI11ii [ 0 ]
  O0O0Oooo0o = iII1I1IiI11ii [ 1 ]
  O00oo0oOoO00O = iII1I1IiI11ii [ 2 ]
  try :
   I1Ii1111iIi = iII1I1IiI11ii [ 3 ]
   if I1Ii1111iIi == None :
    raise
  except :
   if oO . getSetting ( 'use_thumb' ) == "true" :
    I1Ii1111iIi = O00oo0oOoO00O
   else :
    I1Ii1111iIi = iIi11
  try : i1IIi1i1Ii1 = iII1I1IiI11ii [ 5 ]
  except : i1IIi1i1Ii1 = None
  try : II1Ii11Ii1i1I = iII1I1IiI11ii [ 6 ]
  except : II1Ii11Ii1i1I = None
  if 7 - 7: i11i * o00O0oo . I11i11Ii / oOooOoO0Oo0O
  if iII1I1IiI11ii [ 4 ] == 0 :
   oo0o0oooo ( O0O0Oooo0o , oOOO00o000o , O00oo0oOoO00O , I1Ii1111iIi , '' , '' , '' , 'fav' , i1IIi1i1Ii1 , II1Ii11Ii1i1I , ii1IIIIiI11 )
  else :
   I1IiiiiI ( oOOO00o000o , O0O0Oooo0o , iII1I1IiI11ii [ 4 ] , O00oo0oOoO00O , iIi11 , '' , '' , '' , '' , 'fav' )
   if 43 - 43: iII111i + IiII + i1IIi - o0 + i1
   if 54 - 54: ii1IiI1i + ii1IiI1i + Ii1I % i1IIi % i11iIiiIii
def o00oO000 ( name , url , iconimage , fanart , mode , playlist = None , regexs = None ) :
 i11i1ii11Ii1 = [ ]
 if not os . path . exists ( O00OOOoOoo0O + 'txt' ) :
  os . makedirs ( O00OOOoOoo0O + 'txt' )
 if not os . path . exists ( O000OOo00oo ) :
  os . makedirs ( O000OOo00oo )
 try :
  if 38 - 38: O0 - I1Ii111 * I11i11Ii . O0 . ii1IiI1i
  name = name . encode ( 'utf-8' , 'ignore' )
 except :
  pass
 if os . path . exists ( O00OOOoOoo0O ) == False :
  I1iI1iIi111i ( 'Making Favorites File' )
  i11i1ii11Ii1 . append ( ( name , url , iconimage , fanart , mode , playlist , regexs ) )
  Iii = open ( O00OOOoOoo0O , "w" )
  Iii . write ( json . dumps ( i11i1ii11Ii1 ) )
  Iii . close ( )
 else :
  I1iI1iIi111i ( 'Appending Favorites' )
  Iii = open ( O00OOOoOoo0O ) . read ( )
  IiI111111IIII = json . loads ( Iii )
  IiI111111IIII . append ( ( name , url , iconimage , fanart , mode ) )
  iIIIII1ii1I = open ( O00OOOoOoo0O , "w" )
  iIIIII1ii1I . write ( json . dumps ( IiI111111IIII ) )
  iIIIII1ii1I . close ( )
  if 82 - 82: OoooooooOO
  if 75 - 75: i11i % oOooOoO0Oo0O + I11i % OoooooooOO / I1Ii111
def Ii111I11 ( name ) :
 IiI111111IIII = json . loads ( open ( O00OOOoOoo0O ) . read ( ) )
 for ooOO0OoO in range ( len ( IiI111111IIII ) ) :
  if IiI111111IIII [ ooOO0OoO ] [ 0 ] == name :
   del IiI111111IIII [ ooOO0OoO ]
   iIIIII1ii1I = open ( O00OOOoOoo0O , "w" )
   iIIIII1ii1I . write ( json . dumps ( IiI111111IIII ) )
   iIIIII1ii1I . close ( )
   break
 xbmc . executebuiltin ( "XBMC.Container.Refresh" )
 if 51 - 51: OoooooooOO + i1 * iIii1I11I1II1 * OOooOOo / i1IIi
def ii1 ( url ) :
 if oO . getSetting ( 'Updatecommonresolvers' ) == 'true' :
  OOoooO00o0o = os . path . join ( ii1ii11IIIiiI , 'genesisresolvers.py' )
  if xbmcvfs . exists ( OOoooO00o0o ) :
   os . remove ( OOoooO00o0o )
   if 19 - 19: IiII - o0 % OOooOOo / OoooooooOO % IiII
  ooO = 'https://raw.githubusercontent.com/KelTec-Maedia-Play/master/plugin.video.genesis/commonresolvers.py'
  oOoO0Iii1II1ii = urllib . urlretrieve ( ooO , OOoooO00o0o )
  oO . setSetting ( 'Updatecommonresolvers' , 'false' )
 try :
  import genesisresolvers
 except Exception :
  if 95 - 95: I11i11Ii
  if 29 - 29: iII111i / o00O0oo % Ii1I
  xbmc . executebuiltin ( "XBMC.Notification(Por favor Ative Atualizar Resolvedores comuns para reproduzir em configurações. - ,10000)" )
  if 10 - 10: iIii1I11I1II1 % OoooooooOO % ii1IiI1i
 IiiI1i111I1i = genesisresolvers . get ( url ) . result
 if url == IiiI1i111I1i or IiiI1i111I1i is None :
  if 97 - 97: I11i % oOooOoO0Oo0O * oOooOoO0Oo0O % I11i11Ii
  if 86 - 86: iII111i * i1IIi + OOooOOo
  xbmc . executebuiltin ( "XBMC.Notification(Using Urlresolver module.. - ,5000)" )
  import urlresolver
  iI1i1I11i = urlresolver . HostedMediaFile ( url )
  if iI1i1I11i :
   Oo0 = urlresolver . resolve ( url )
   IiiI1i111I1i = Oo0
 if IiiI1i111I1i :
  if isinstance ( IiiI1i111I1i , list ) :
   for oO0Ooo0OooOOo in IiiI1i111I1i :
    iiiIii1iIi1Ii = oO . getSetting ( 'quality' )
    if oO0Ooo0OooOOo [ 'quality' ] == 'HD' :
     Oo0 = oO0Ooo0OooOOo [ 'url' ]
     break
    elif oO0Ooo0OooOOo [ 'quality' ] == 'SD' :
     Oo0 = oO0Ooo0OooOOo [ 'url' ]
    elif oO0Ooo0OooOOo [ 'quality' ] == '1080p' and oO . getSetting ( '1080pquality' ) == 'true' :
     Oo0 = oO0Ooo0OooOOo [ 'url' ]
     break
  else :
   Oo0 = IiiI1i111I1i
 return Oo0
 if 13 - 13: I1Ii111 . I1Ii111 + iIii1I11I1II1 * I11i11Ii
def O0Oo00 ( name , mu_playlist , queueVideo = None ) :
 i1IIi1i1Ii1 = xbmc . PlayList ( xbmc . PLAYLIST_VIDEO )
 if 63 - 63: i1IIi % i11iIiiIii % i11i * OoooooooOO
 if '$$LSPlayOnlyOne$$' in mu_playlist [ 0 ] :
  mu_playlist [ 0 ] = mu_playlist [ 0 ] . replace ( '$$LSPlayOnlyOne$$' , '' )
  import urlparse
  iIiII1 = [ ]
  i111iii1I1 = 0
  I11iIi1II = xbmcgui . DialogProgress ( )
  I11iIi1II . create ( 'Progress' , 'Trying Multiple Links' )
  for iII1I1IiI11ii in mu_playlist :
   if 48 - 48: OoooooooOO . o0
   if 65 - 65: OOooOOo . I11i11Ii
   if 94 - 94: o0 + I1Ii111 . o00O0oo
   if OOoOO0oo0ooO in iII1I1IiI11ii :
    if 69 - 69: O0 - O0
    i1I1i1i1I1 = iII1I1IiI11ii . split ( OOoOO0oo0ooO ) [ 1 ] . split ( '&regexs' ) [ 0 ]
    iIiII1 . append ( i1I1i1i1I1 )
    if 17 - 17: o0 + OoooooooOO % I11i
    mu_playlist [ i111iii1I1 ] = iII1I1IiI11ii . split ( OOoOO0oo0ooO ) [ 0 ] + ( '&regexs' + iII1I1IiI11ii . split ( '&regexs' ) [ 1 ] if '&regexs' in iII1I1IiI11ii else '' )
   else :
    i1I1i1i1I1 = urlparse . urlparse ( iII1I1IiI11ii ) . netloc
    if i1I1i1i1I1 == '' :
     iIiII1 . append ( name )
    else :
     iIiII1 . append ( i1I1i1i1I1 )
   ooOO0OoO = i111iii1I1
   i111iii1I1 += 1
   if 36 - 36: i11iIiiIii + ii1IiI1i % I11i . oOooOoO0Oo0O - o00O0oo
   OooOo0o0OO = iIiII1 [ ooOO0OoO ]
   if I11iIi1II . iscanceled ( ) : return
   I11iIi1II . update ( i111iii1I1 / len ( mu_playlist ) * 100 , "" , "Link#%d" % ( i111iii1I1 ) , OooOo0o0OO )
   print 'auto playnamexx' , OooOo0o0OO
   if "&mode=19" in mu_playlist [ ooOO0OoO ] :
    if 1 - 1: iIii1I11I1II1 % o00O0oo + O0
    iiI1i1Iii111 = xbmcgui . ListItem ( OooOo0o0OO , iconImage = O00oo0oOoO00O , thumbnailImage = O00oo0oOoO00O )
    iiI1i1Iii111 . setInfo ( type = 'Video' , infoLabels = { 'Title' : OooOo0o0OO } )
    iiI1i1Iii111 . setProperty ( "IsPlayable" , "true" )
    IIiII11 = ii1 ( mu_playlist [ ooOO0OoO ] . replace ( '&mode=19' , '' ) . replace ( ';' , '' ) )
    iiI1i1Iii111 . setPath ( IIiII11 )
    if 58 - 58: IiII
    I11IIIII = tryplay ( IIiII11 , iiI1i1Iii111 )
   elif "$doregex" in mu_playlist [ ooOO0OoO ] :
    if 53 - 53: OoooooooOO . OoooooooOO + i1 - IiII + I11i
    i1111iIII = mu_playlist [ ooOO0OoO ] . split ( '&regexs=' )
    if 50 - 50: O0 * ii1IiI1i + i11i . i1IIi + o0
    O0O0Oooo0o , OoIIi1iI = i1iI1IIIII1 ( i1111iIII [ 1 ] , i1111iIII [ 0 ] )
    ii11I11 = O0O0Oooo0o . replace ( ';' , '' )
    iiI1i1Iii111 = xbmcgui . ListItem ( OooOo0o0OO , iconImage = O00oo0oOoO00O , thumbnailImage = O00oo0oOoO00O )
    iiI1i1Iii111 . setInfo ( type = 'Video' , infoLabels = { 'Title' : OooOo0o0OO } )
    iiI1i1Iii111 . setProperty ( "IsPlayable" , "true" )
    iiI1i1Iii111 . setPath ( ii11I11 )
    if 75 - 75: I11i11Ii
    I11IIIII = tryplay ( ii11I11 , iiI1i1Iii111 )
    if 23 - 23: i11i * IiII
   else :
    O0O0Oooo0o = mu_playlist [ ooOO0OoO ]
    O0O0Oooo0o = O0O0Oooo0o . split ( '&regexs=' ) [ 0 ]
    iiI1i1Iii111 = xbmcgui . ListItem ( OooOo0o0OO , iconImage = O00oo0oOoO00O , thumbnailImage = O00oo0oOoO00O )
    iiI1i1Iii111 . setInfo ( type = 'Video' , infoLabels = { 'Title' : OooOo0o0OO } )
    iiI1i1Iii111 . setProperty ( "IsPlayable" , "true" )
    iiI1i1Iii111 . setPath ( O0O0Oooo0o )
    if 80 - 80: ooOoO0o / i11iIiiIii + OoooooooOO
    I11IIIII = tryplay ( O0O0Oooo0o , iiI1i1Iii111 )
    print 'played' , I11IIIII
   print 'played' , I11IIIII
   if I11IIIII : return
  return
 if oO . getSetting ( 'ask_playlist_items' ) == 'true' and not queueVideo :
  import urlparse
  iIiII1 = [ ]
  i111iii1I1 = 0
  for iII1I1IiI11ii in mu_playlist :
   if 38 - 38: ii1IiI1i % o00O0oo + i1IIi * OoooooooOO * OOooOOo
   if OOoOO0oo0ooO in iII1I1IiI11ii :
    if 83 - 83: iIii1I11I1II1 - o00O0oo - ooOoO0o / i1iIi11iIIi1I - O0
    i1I1i1i1I1 = iII1I1IiI11ii . split ( OOoOO0oo0ooO ) [ 1 ] . split ( '&regexs' ) [ 0 ]
    iIiII1 . append ( i1I1i1i1I1 )
    if 81 - 81: iII111i - OOooOOo * ii1IiI1i / ooOoO0o
    mu_playlist [ i111iii1I1 ] = iII1I1IiI11ii . split ( OOoOO0oo0ooO ) [ 0 ] + ( '&regexs' + iII1I1IiI11ii . split ( '&regexs' ) [ 1 ] if '&regexs' in iII1I1IiI11ii else '' )
   else :
    i1I1i1i1I1 = urlparse . urlparse ( iII1I1IiI11ii ) . netloc
    if i1I1i1i1I1 == '' :
     iIiII1 . append ( name )
    else :
     iIiII1 . append ( i1I1i1i1I1 )
     if 21 - 21: i1iIi11iIIi1I
   i111iii1I1 += 1
  I11iiI1i1 = xbmcgui . Dialog ( )
  if 63 - 63: Ii1I . O0 * Ii1I + iIii1I11I1II1
  ooOO0OoO = I11iiI1i1 . select ( II111ii1II1i , iIiII1 )
  if ooOO0OoO >= 0 :
   OooOo0o0OO = iIiII1 [ ooOO0OoO ]
   print 'playnamexx' , OooOo0o0OO
   if "&mode=19" in mu_playlist [ ooOO0OoO ] :
    if 46 - 46: i1IIi + i11i * i1IIi - iII111i
    iiI1i1Iii111 = xbmcgui . ListItem ( OooOo0o0OO , iconImage = O00oo0oOoO00O , thumbnailImage = O00oo0oOoO00O )
    iiI1i1Iii111 . setInfo ( type = 'Video' , infoLabels = { 'Title' : OooOo0o0OO } )
    iiI1i1Iii111 . setProperty ( "IsPlayable" , "true" )
    IIiII11 = ii1 ( mu_playlist [ ooOO0OoO ] . replace ( '&mode=19' , '' ) . replace ( ';' , '' ) )
    iiI1i1Iii111 . setPath ( IIiII11 )
    xbmc . Player ( ) . play ( IIiII11 , iiI1i1Iii111 )
   elif "$doregex" in mu_playlist [ ooOO0OoO ] :
    if 79 - 79: i11i - OOooOOo * ii1IiI1i - o0 . ii1IiI1i
    i1111iIII = mu_playlist [ ooOO0OoO ] . split ( '&regexs=' )
    if 11 - 11: O0 * o0
    O0O0Oooo0o , OoIIi1iI = i1iI1IIIII1 ( i1111iIII [ 1 ] , i1111iIII [ 0 ] )
    ii11I11 = O0O0Oooo0o . replace ( ';' , '' )
    iiI1i1Iii111 = xbmcgui . ListItem ( OooOo0o0OO , iconImage = O00oo0oOoO00O , thumbnailImage = O00oo0oOoO00O )
    iiI1i1Iii111 . setInfo ( type = 'Video' , infoLabels = { 'Title' : OooOo0o0OO } )
    iiI1i1Iii111 . setProperty ( "IsPlayable" , "true" )
    iiI1i1Iii111 . setPath ( ii11I11 )
    xbmc . Player ( ) . play ( ii11I11 , iiI1i1Iii111 )
    if 37 - 37: o0 + O0 . O0 * I11i11Ii % ooOoO0o / IiII
   else :
    O0O0Oooo0o = mu_playlist [ ooOO0OoO ]
    O0O0Oooo0o = O0O0Oooo0o . split ( '&regexs=' ) [ 0 ]
    iiI1i1Iii111 = xbmcgui . ListItem ( OooOo0o0OO , iconImage = O00oo0oOoO00O , thumbnailImage = O00oo0oOoO00O )
    iiI1i1Iii111 . setInfo ( type = 'Video' , infoLabels = { 'Title' : OooOo0o0OO } )
    iiI1i1Iii111 . setProperty ( "IsPlayable" , "true" )
    iiI1i1Iii111 . setPath ( O0O0Oooo0o )
    xbmc . Player ( ) . play ( O0O0Oooo0o , iiI1i1Iii111 )
 elif not queueVideo :
  if 18 - 18: OoooooooOO
  i1IIi1i1Ii1 . clear ( )
  i1oO = 0
  for iII1I1IiI11ii in mu_playlist :
   i1oO += 1
   O0oOo00oooO = xbmcgui . ListItem ( '%s) %s' % ( str ( i1oO ) , name ) )
   if 16 - 16: i1IIi . i1IIi / ooOoO0o % o0 / oOooOoO0Oo0O * ii1IiI1i
   try :
    if "$doregex" in iII1I1IiI11ii :
     i1111iIII = iII1I1IiI11ii . split ( '&regexs=' )
     if 30 - 30: i1 + OoooooooOO + I11i / i11i * I11i11Ii
     O0O0Oooo0o , OoIIi1iI = i1iI1IIIII1 ( i1111iIII [ 1 ] , i1111iIII [ 0 ] )
    elif "&mode=19" in iII1I1IiI11ii :
     O0O0Oooo0o = ii1 ( iII1I1IiI11ii . replace ( '&mode=19' , '' ) . replace ( ';' , '' ) )
    if O0O0Oooo0o :
     i1IIi1i1Ii1 . add ( O0O0Oooo0o , O0oOo00oooO )
    else :
     raise
   except Exception :
    i1IIi1i1Ii1 . add ( iII1I1IiI11ii , O0oOo00oooO )
    pass
    if 59 - 59: iII111i / o0 * i1iIi11iIIi1I * IiII % OOooOOo
  xbmc . executebuiltin ( 'playlist.playoffset(video,0)' )
 else :
  if 61 - 61: I11i11Ii - O0 - OoooooooOO
  oOOoooO0O0 = xbmcgui . ListItem ( name )
  i1IIi1i1Ii1 . add ( mu_playlist , oOOoooO0O0 )
  if 4 - 4: i11i - OOooOOo % I11i11Ii * i11iIiiIii
def iIiII1iiiiI ( name , url ) :
 if oO . getSetting ( 'save_location' ) == "" :
  if 80 - 80: I11i11Ii - i1 - i11i . I1Ii111 - O0 * I1Ii111
  xbmc . executebuiltin ( "XBMC.Notification('','Choose a location to save files.',15000," + oOO00Oo + ")" )
  oO . openSettings ( )
 Oo00Oo = { 'url' : url , 'download_path' : oO . getSetting ( 'save_location' ) }
 downloader . download ( name , Oo00Oo )
 I11iiI1i1 = xbmcgui . Dialog ( )
 if 43 - 43: oOooOoO0Oo0O / IiII / o00O0oo + iIii1I11I1II1 + OoooooooOO
 i1Ii11I1II = I11iiI1i1 . yesno ( '' , 'Do you want to add this file as a source?' )
 if i1Ii11I1II :
  iI1I ( os . path . join ( oO . getSetting ( 'save_location' ) , name ) )
  if 33 - 33: i11i - I1Ii111 - o00O0oo
def oO00oOoo00o0 ( name , url , mode , iconimage , fanart , description , genre , date , credits , showcontext = False , regexs = None , reg_url = None , allinfo = { } ) :
 if 41 - 41: OOooOOo / I11i + IiII + o00O0oo
 if mode == 1 :
  iiiiii1Ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( codecs . encode ( base64 . b32encode ( base64 . b16encode ( url ) ) , 'rot_13' ) ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&fanart=" + urllib . quote_plus ( fanart )
 else :
  iiiiii1Ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( codecs . encode ( base64 . b32encode ( base64 . b16encode ( url ) ) , 'rot_13' ) ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&fanart=" + urllib . quote_plus ( fanart )
 i111I11i = True
 if date == '' :
  date = None
 else :
  description += '\n\nDate: %s' % date
 iiI1i1Iii111 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if len ( allinfo ) < 1 :
  iiI1i1Iii111 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description , "Genre" : genre , "dateadded" : date } )
 else :
  iiI1i1Iii111 . setInfo ( type = "Video" , infoLabels = allinfo )
 iiI1i1Iii111 . setProperty ( "Fanart_Image" , fanart )
 if showcontext :
  I1111i = [ ]
  if 79 - 79: ooOoO0o
  OOooo00 = ''
  OOooo00 = OOooo00 == "true"
  if 8 - 8: IiII - i11i
  ii1111I = ''
  if 45 - 45: i1
  if len ( ii1111I ) > 0 :
   if OOooo00 :
    I1111i . append ( ( 'Disable Parental Block' , 'XBMC.RunPlugin(%s?mode=55&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
   else :
    I1111i . append ( ( 'Enable Parental Block' , 'XBMC.RunPlugin(%s?mode=56&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
    if 58 - 58: oOooOoO0Oo0O * i1IIi % i11i / O0
  if showcontext == 'source' :
   if 56 - 56: Ii1I - O0 / O0 * i1IIi . OoooooooOO % iIii1I11I1II1
   if name in str ( I1 ) :
    I1111i . append ( ( 'Remove from Sources' , 'XBMC.RunPlugin(%s?mode=8&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
    if 21 - 21: I1Ii111 - oOooOoO0Oo0O % OoooooooOO + i1
    if 92 - 92: o00O0oo + I1Ii111
  elif showcontext == 'download' :
   I1111i . append ( ( 'Download' , 'XBMC.RunPlugin(%s?url=%s&mode=9&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
  elif showcontext == 'fav' :
   I1111i . append ( ( 'Remove from KelTec-Media-Play Favorites' , 'XBMC.RunPlugin(%s?mode=6&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
  if showcontext == '!!update' :
   Oooo = (
 '%s?url=%s&mode=17&regexs=%s'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( reg_url ) , regexs )
 )
   I1111i . append ( ( '[COLOR orange]!!update[/COLOR]' , 'XBMC.RunPlugin(%s)' % Oooo ) )
  if not name in iiIiI :
   O00IiII = (
 '%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage ) , urllib . quote_plus ( fanart ) )
 )
   if i1IIi1i1Ii1 :
    O00IiII += 'playlist=' + urllib . quote_plus ( str ( i1IIi1i1Ii1 ) . replace ( ',' , '||' ) )
   if regexs :
    O00IiII += "&regexs=" + regexs
    if 27 - 27: i1iIi11iIIi1I . i1 . O0 - O0 / Ii1I - i1iIi11iIIi1I
    if 30 - 30: i1 - i1iIi11iIIi1I + I11i
  iiI1i1Iii111 . addContextMenuItems ( I1111i )
 i111I11i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiiiii1Ii , listitem = iiI1i1Iii111 , isFolder = True )
 return i111I11i
 if 65 - 65: O0 / i11i . iIii1I11I1II1 . OOooOOo / I11i11Ii % iIii1I11I1II1
def I1IiiiiI ( name , url , mode , iconimage , fanart , description , genre , date , credits , year , director , duration , premiered , studio , rate , originaltitle , country , rating , userrating , votes , aired , showcontext = False , reg_url = None , regexs = None , allinfo = { } ) :
 if 74 - 74: i1IIi / oOooOoO0Oo0O % ii1IiI1i / O0 % Ii1I - o0
 if mode == 1 :
  iiiiii1Ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( codecs . encode ( base64 . b32encode ( base64 . b16encode ( url ) ) , 'rot_13' ) ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&fanart=" + urllib . quote_plus ( fanart )
 else :
  iiiiii1Ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( codecs . encode ( base64 . b32encode ( base64 . b16encode ( url ) ) , 'rot_13' ) ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&fanart=" + urllib . quote_plus ( fanart )
 i111I11i = True
 if date == '' :
  date = None
 else :
  description += '\n\nDate: %s' % date
 iiI1i1Iii111 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if len ( allinfo ) < 1 :
  iiI1i1Iii111 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description , "Genre" : genre , "dateadded" : date , "credits" : credits , "Year" : year , "Director" : director , "Duration" : duration , "Premiered" : premiered , "Studio" : studio , "Mpaa" : rate , "Originaltitle" : originaltitle , "Country" : country , "Rating" : rating , "Userrating" : userrating , "Votes" : votes , "Aired" : aired } )
 else :
  iiI1i1Iii111 . setInfo ( type = "Video" , infoLabels = allinfo )
 iiI1i1Iii111 . setProperty ( "Fanart_Image" , fanart )
 if showcontext :
  I1111i = [ ]
  if 31 - 31: oOooOoO0Oo0O / OoooooooOO . iIii1I11I1II1 * o0 . OoooooooOO + i11i
  OOooo00 = ''
  OOooo00 = OOooo00 == "true"
  if 8 - 8: ii1IiI1i * ii1IiI1i * i1IIi + IiII . ii1IiI1i
  ii1111I = ''
  if 100 - 100: OoooooooOO - O0 . Ii1I / Ii1I + i11i * o0
  if len ( ii1111I ) > 0 :
   if OOooo00 :
    I1111i . append ( ( 'Disable Parental Block' , 'XBMC.RunPlugin(%s?mode=55&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
   else :
    I1111i . append ( ( 'Enable Parental Block' , 'XBMC.RunPlugin(%s?mode=56&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
    if 37 - 37: I11i11Ii
  if showcontext == 'source' :
   if 72 - 72: I1Ii111 % ii1IiI1i * I11i . i11iIiiIii % I1Ii111 * I11i
   if name in str ( I1 ) :
    I1111i . append ( ( 'Remove from Sources' , 'XBMC.RunPlugin(%s?mode=8&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
    if 15 - 15: Ii1I / I11i11Ii * Ii1I
    if 20 - 20: o00O0oo - I11i * i1iIi11iIIi1I * i1 * I11i / I1Ii111
  elif showcontext == 'download' :
   I1111i . append ( ( 'Download' , 'XBMC.RunPlugin(%s?url=%s&mode=9&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
  elif showcontext == 'fav' :
   I1111i . append ( ( 'Remove from KelTec-Maedia-Play Favorites' , 'XBMC.RunPlugin(%s?mode=6&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
  if showcontext == '!!update' :
   Oooo = (
 '%s?url=%s&mode=17&regexs=%s'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( reg_url ) , regexs )
 )
   I1111i . append ( ( '[COLOR orange]!!update[/COLOR]' , 'XBMC.RunPlugin(%s)' % Oooo ) )
  if not name in iiIiI :
   O00IiII = (
 '%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage ) , urllib . quote_plus ( fanart ) )
 )
   if i1IIi1i1Ii1 :
    O00IiII += 'playlist=' + urllib . quote_plus ( str ( i1IIi1i1Ii1 ) . replace ( ',' , '||' ) )
   if regexs :
    O00IiII += "&regexs=" + regexs
    if 40 - 40: oOooOoO0Oo0O * i1 . oOooOoO0Oo0O
    if 62 - 62: o00O0oo + i11i % o00O0oo
  iiI1i1Iii111 . addContextMenuItems ( I1111i )
 i111I11i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiiiii1Ii , listitem = iiI1i1Iii111 , isFolder = True )
 return i111I11i
 if 50 - 50: OoooooooOO + OOooOOo * oOooOoO0Oo0O - iII111i / i11iIiiIii
def iiiIIiiIi ( url , title , media_type = 'video' ) :
 if 86 - 86: OoooooooOO % i11i . OoooooooOO * ii1IiI1i
 if 9 - 9: I11i11Ii + IiII
 import youtubedl
 if not url == '' :
  if media_type == 'audio' :
   youtubedl . single_YD ( url , download = True , audio = True )
  else :
   youtubedl . single_YD ( url , download = True )
 elif xbmc . Player ( ) . isPlaying ( ) == True :
  import YDStreamExtractor
  if YDStreamExtractor . isDownloading ( ) == True :
   if 64 - 64: O0 * oOooOoO0Oo0O / oOooOoO0Oo0O
   YDStreamExtractor . manageDownloads ( )
  else :
   OO0oo = xbmc . Player ( ) . getPlayingFile ( )
   if 56 - 56: ii1IiI1i . OOooOOo
   OO0oo = OO0oo . split ( '|User-Agent=' ) [ 0 ]
   O0oOo00oooO = { 'url' : OO0oo , 'title' : title , 'media_type' : media_type }
   youtubedl . single_YD ( '' , download = True , dl_info = O0oOo00oooO )
 else :
  xbmc . executebuiltin ( "XBMC.Notification(DOWNLOAD,First Play [COLOR yellow]WHILE playing download[/COLOR] ,10000)" )
  if 55 - 55: i1iIi11iIIi1I * i1iIi11iIIi1I . oOooOoO0Oo0O
def OOOOoO0 ( site_name , search_term = None ) :
 o00oO = ''
 if os . path . exists ( O000OOo00oo ) == False or oO . getSetting ( 'clearseachhistory' ) == 'true' :
  I11I1IIii ( O000OOo00oo , '' )
  oO . setSetting ( "clearseachhistory" , "false" )
 if site_name == 'history' :
  oOOo000oOoO0 = OOo00ooOoO0o ( O000OOo00oo )
  OoOo00o0OO = re . compile ( '(.+?):(.*?)(?:\r|\n)' ) . findall ( oOOo000oOoO0 )
  if 43 - 43: oOooOoO0Oo0O - i1 / i1 . i11i - iII111i
  for oOOO00o000o , search_term in OoOo00o0OO :
   if 'plugin://' in search_term :
    oo0o0oooo ( search_term , oOOO00o000o , o00oO , '' , '' , '' , '' , '' , None , '' , total = int ( len ( OoOo00o0OO ) ) )
   else :
    I1IiiiiI ( oOOO00o000o + ':' + search_term , oOOO00o000o , 26 , oOO00Oo , i1iI11i1ii11 , '' , '' , '' , '' )
 if not search_term :
  I1i11111i1i11 = xbmc . Keyboard ( '' , 'Enter Search Term' )
  I1i11111i1i11 . doModal ( )
  if ( I1i11111i1i11 . isConfirmed ( ) == False ) :
   return
  search_term = I1i11111i1i11 . getText ( )
  if len ( search_term ) == 0 :
   return
 search_term = search_term . replace ( ' ' , '+' )
 search_term = search_term . encode ( 'utf-8' )
 if 'youtube' in site_name :
  if 40 - 40: IiII . o0 * O0
  import _ytplist
  if 6 - 6: oOooOoO0Oo0O - i11i . oOooOoO0Oo0O + Ii1I . I11i
  oo0O = { }
  oo0O = _ytplist . YoUTube ( 'searchYT' , youtube = search_term , max_page = 4 , nosave = 'nosave' )
  ii1IIIIiI11 = len ( oo0O )
  for i1oO in oo0O :
   try :
    oOOO00o000o = oo0O [ i1oO ] [ 'title' ]
    iIIiiiI = oo0O [ i1oO ] [ 'date' ]
    try :
     Iii1iI1iiIii = oo0O [ i1oO ] [ 'desc' ]
    except Exception :
     Iii1iI1iiIii = 'UNAVAIABLE'
     if 21 - 21: i1iIi11iIIi1I % iIii1I11I1II1 . i1iIi11iIIi1I
    O0O0Oooo0o = 'plugin://plugin.video.youtube/play/?video_id=' + oo0O [ i1oO ] [ 'url' ]
    o00oO = 'http://img.youtube.com/vi/' + oo0O [ i1oO ] [ 'url' ] + '/0.jpg'
    oo0o0oooo ( O0O0Oooo0o , oOOO00o000o , o00oO , '' , '' , '' , '' , '' , None , '' , ii1IIIIiI11 )
   except Exception :
    I1iI1iIi111i ( 'This item is ignored::' )
  OO000OOOo0Oo = site_name + ':' + search_term + '\n'
  I11I1IIii ( os . path . join ( O0oOoOOOoOO , 'history' ) , OO000OOOo0Oo , append = True )
 elif 'dmotion' in site_name :
  Oo00O0O = "https://api.dailymotion.com"
  if 70 - 70: i1iIi11iIIi1I
  import _DMsearch
  iIiiI1I = str ( oO . getSetting ( 'familyFilter' ) )
  _DMsearch . listVideos ( Oo00O0O + "/videos?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&search=" + search_term + "&sort=relevance&limit=100&family_filter=" + iIiiI1I + "&localization=en_EN&page=1" )
  if 5 - 5: o0 * i11i % I11i11Ii * i1 * Ii1I + I11i11Ii
  OO000OOOo0Oo = site_name + ':' + search_term + '\n'
  I11I1IIii ( os . path . join ( O0oOoOOOoOO , 'history' ) , OO000OOOo0Oo , append = True )
 elif 'IMDBidplay' in site_name :
  Oo00O0O = "http://www.omdbapi.com/?t="
  O0O0Oooo0o = Oo00O0O + search_term
  if 7 - 7: Ii1I + Ii1I + i11i % iII111i
  oO0O = dict ( { 'User-Agent' : 'Mozilla/5.0 (Windows NT 6.3; rv:33.0) Gecko/20100101 Firefox/33.0' , 'Referer' : 'http://joker.org/' , 'Accept-Encoding' : 'gzip, deflate' , 'Content-Type' : 'application/json;charset=utf-8' , 'Accept' : 'application/json, text/plain, */*' } )
  if 31 - 31: OOooOOo * o0 + I11i
  iIiI1 = requests . get ( O0O0Oooo0o , headers = oO0O )
  IiI111111IIII = iIiI1 . json ( )
  OOoo0OOOo0o = IiI111111IIII [ 'Response' ]
  if OOoo0OOOo0o == 'True' :
   iI1111i1i11Ii = IiI111111IIII [ 'imdbID' ]
   oOOO00o000o = IiI111111IIII [ 'Title' ] + IiI111111IIII [ 'Released' ]
   I11iiI1i1 = xbmcgui . Dialog ( )
   i1Ii11I1II = I11iiI1i1 . yesno ( 'Check Movie Title' , 'PLAY :: %s ?' % oOOO00o000o )
   if i1Ii11I1II :
    O0O0Oooo0o = 'plugin://plugin.video.pulsar/movie/' + iI1111i1i11Ii + '/play'
    OO000OOOo0Oo = oOOO00o000o + ':' + O0O0Oooo0o + '\n'
    I11I1IIii ( O000OOo00oo , OO000OOOo0Oo , append = True )
    return O0O0Oooo0o
  else :
   if 62 - 62: IiII
   xbmc . executebuiltin ( "XBMC.Notification(No IMDB match found ,7000," + oOO00Oo + ")" )
   if 8 - 8: IiII - oOooOoO0Oo0O * I11i11Ii % ii1IiI1i * OoooooooOO
def iii11 ( string ) :
 if isinstance ( string , basestring ) :
  if isinstance ( string , unicode ) :
   string = string . encode ( 'ascii' , 'ignore' )
 return string
def I1i11IIIi ( string , encoding = 'utf-8' ) :
 if isinstance ( string , basestring ) :
  if not isinstance ( string , unicode ) :
   string = unicode ( string , encoding , 'ignore' )
 return string
def III1IIIIIiiI ( s ) : return "" . join ( filter ( lambda i1iIii : ord ( i1iIii ) < 128 , s ) )
if 95 - 95: Ii1I / I1Ii111 . O0 * I1Ii111 - i1 * I11i11Ii
def II1iiI1iI ( command ) :
 IiI111111IIII = ''
 try :
  IiI111111IIII = xbmc . executeJSONRPC ( I1i11IIIi ( command ) )
 except UnicodeEncodeError :
  IiI111111IIII = xbmc . executeJSONRPC ( iii11 ( command ) )
  if 74 - 74: I1Ii111 - O0 / ooOoO0o * iII111i % o00O0oo . ooOoO0o
 return I1i11IIIi ( IiI111111IIII )
 if 60 - 60: ii1IiI1i . i11i * i11iIiiIii . i1
 if 66 - 66: IiII / i11iIiiIii * O0
def IIIii ( ) :
 O000Oo00 = xbmc . getSkinDir ( )
 if O000Oo00 == 'skin.confluence' :
  xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 elif O000Oo00 == 'skin.aeon.nox' :
  xbmc . executebuiltin ( 'Container.SetViewMode(511)' )
 else :
  xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
  if 43 - 43: i1iIi11iIIi1I . o00O0oo * I11i11Ii
  if 20 - 20: i1IIi . i1IIi - Ii1I
def O0o00ooo ( url ) :
 iiiIIiiiI = I1i11IIIi ( '{"jsonrpc":"2.0","method":"Files.GetDirectory","params":{"directory":"%s","media":"video","properties":["thumbnail","title","year","dateadded","fanart","rating","season","episode","studio"]},"id":1}' ) % url
 if 50 - 50: ooOoO0o + Ii1I / iII111i * I11i / i1
 Ii11Iiii = json . loads ( II1iiI1iI ( iiiIIiiiI ) )
 for iII1I1IiI11ii in Ii11Iiii [ 'result' ] [ 'files' ] :
  url = iII1I1IiI11ii [ 'file' ]
  oOOO00o000o = III1IIIIIiiI ( iII1I1IiI11ii [ 'label' ] )
  o00oO = III1IIIIIiiI ( iII1I1IiI11ii [ 'thumbnail' ] )
  try :
   iIi11 = III1IIIIIiiI ( iII1I1IiI11ii [ 'fanart' ] )
  except Exception :
   iIi11 = ''
  try :
   iIIiiiI = iII1I1IiI11ii [ 'year' ]
  except Exception :
   iIIiiiI = ''
  try :
   ooO0o00OOo = iII1I1IiI11ii [ 'episode' ]
   iI1ii = iII1I1IiI11ii [ 'season' ]
   if ooO0o00OOo == - 1 or iI1ii == - 1 :
    Iii1iI1iiIii = ''
   else :
    Iii1iI1iiIii = '[COLOR yellow] S' + str ( iI1ii ) + '[/COLOR][COLOR hotpink] E' + str ( ooO0o00OOo ) + '[/COLOR]'
  except Exception :
   Iii1iI1iiIii = ''
  try :
   O0Oo000 = iII1I1IiI11ii [ 'studio' ]
   if O0Oo000 :
    Iii1iI1iiIii += '\n Studio:[COLOR steelblue] ' + O0Oo000 [ 0 ] + '[/COLOR]'
  except Exception :
   O0Oo000 = ''
   if 61 - 61: I11i11Ii * i1IIi . OoooooooOO
  if iII1I1IiI11ii [ 'filetype' ] == 'file' :
   ii1iiIi1 ( url , oOOO00o000o , o00oO , iIi11 , Iii1iI1iiIii , '' , iIIiiiI , '' , None , '' , total = len ( Ii11Iiii [ 'result' ] [ 'files' ] ) )
   if 44 - 44: oOooOoO0Oo0O
   if 55 - 55: OOooOOo . ooOoO0o * ooOoO0o
  else :
   oO00oOoo00o0 ( oOOO00o000o , url , 53 , o00oO , iIi11 , Iii1iI1iiIii , '' , iIIiiiI , '' )
   if 82 - 82: oOooOoO0Oo0O % i1iIi11iIIi1I % Ii1I + Ii1I
   if 6 - 6: I11i11Ii
def ii1iiIi1 ( url , name , iconimage , fanart , description , genre , date , showcontext , playlist , regexs , total , setCookie = "" , allinfo = { } ) :
 if 73 - 73: ooOoO0o * ii1IiI1i + i1 - I11i11Ii . Ii1I
 I1111i = [ ]
 OOooo00 = oO . getSetting ( 'parentalblocked' )
 OOooo00 = OOooo00 == "true"
 ii1111I = oO . getSetting ( 'parentalblockedpin' )
 if 93 - 93: i11iIiiIii
 if len ( ii1111I ) > 0 :
  if OOooo00 :
   I1111i . append ( ( 'Disable Parental Block' , 'XBMC.RunPlugin(%s?mode=55&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
  else :
   I1111i . append ( ( 'Enable Parental Block' , 'XBMC.RunPlugin(%s?mode=56&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
   if 80 - 80: i1IIi . oOooOoO0Oo0O - OOooOOo + I11i + IiII % OOooOOo
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 i111I11i = True
 IiiII = False
 if regexs :
  I1ii1iI = '17'
  if 'listrepeat' in regexs :
   IiiII = True
   if 32 - 32: OoooooooOO
   if 77 - 77: iIii1I11I1II1 * OOooOOo
  I1111i . append ( ( o0OOoo0OO0OOO , 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 elif ( any ( x in url for x in o0oo0oOo ) and url . startswith ( 'http' ) ) or url . endswith ( '&mode=19' ) :
  url = url . replace ( '&mode=19' , '' )
  I1ii1iI = '19'
  if 15 - 15: iIii1I11I1II1 . I11i . ii1IiI1i * i11iIiiIii
  I1111i . append ( ( o0OOoo0OO0OOO , 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 elif url . endswith ( '&mode=18' ) :
  url = url . replace ( '&mode=18' , '' )
  I1ii1iI = '18'
  I1111i . append ( ( '[COLOR white]!!Download!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=23&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
  if oO . getSetting ( 'dlaudioonly' ) == 'true' :
   I1111i . append ( ( '!!Download [COLOR seablue]Audio!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=24&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
   if 72 - 72: Ii1I
 elif url . startswith ( 'magnet:?xt=' ) or '.torrent' in url :
  if '&' in url and not '&amp;' in url :
   url = url . replace ( '&' , '&amp;' )
   if 26 - 26: I1Ii111 % I11i11Ii
  url = 'plugin://plugin.video.elementum/play?uri=' + url
  I1ii1iI = '12'
 else :
  I1ii1iI = '12'
  if 72 - 72: O0 + i1 + oOooOoO0Oo0O / I11i11Ii
  I1111i . append ( ( o0OOoo0OO0OOO , 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 if 'plugin://plugin.video.youtube/play/?video_id=' in url :
  o0oo0OOOO = url . replace ( 'plugin://plugin.video.youtube/play/?video_id=' , 'https://www.youtube.com/watch?v=' )
  I1111i . append ( ( '!!Download [COLOR blue]Audio!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=24&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( o0oo0OOOO ) , urllib . quote_plus ( name ) ) ) )
 iiiiii1Ii = sys . argv [ 0 ] + "?"
 Oo0o0O0OOOo0 = False
 if playlist :
  if oO . getSetting ( 'add_playlist' ) == "false" and '$$LSPlayOnlyOne$$' not in playlist [ 0 ] :
   iiiiii1Ii += "url=" + urllib . quote_plus ( url ) + "&mode=" + I1ii1iI
  else :
   iiiiii1Ii += "mode=13&name=%s&playlist=%s" % ( urllib . quote_plus ( name ) , urllib . quote_plus ( str ( playlist ) . replace ( ',' , '||' ) ) )
   name = name + '[COLOR orange] (' + str ( len ( playlist ) ) + ' itens)[/COLOR]'
   Oo0o0O0OOOo0 = True
 else :
  iiiiii1Ii += "url=" + urllib . quote_plus ( url ) + "&mode=" + I1ii1iI
 if regexs :
  iiiiii1Ii += "&regexs=" + regexs
 if not setCookie == '' :
  iiiiii1Ii += "&setCookie=" + urllib . quote_plus ( setCookie )
 if iconimage and not iconimage == '' :
  iiiiii1Ii += "&iconimage=" + urllib . quote_plus ( iconimage )
  if 4 - 4: o00O0oo + O0 . i1IIi * ii1IiI1i - i1
 if date == '' :
  date = None
 else :
  description += '\n\nDate: %s' % date
 iiI1i1Iii111 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 if 42 - 42: i1 * o0 . i1iIi11iIIi1I - IiII / i11i
 if allinfo == None or len ( allinfo ) < 1 :
  iiI1i1Iii111 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description , "Genre" : genre , "dateadded" : date } )
 else :
  iiI1i1Iii111 . setInfo ( type = "Video" , infoLabels = allinfo )
 iiI1i1Iii111 . setProperty ( "Fanart_Image" , fanart )
 if 25 - 25: I11i11Ii % o0
 if ( not Oo0o0O0OOOo0 ) and not any ( x in url for x in o000O0o ) and not '$PLAYERPROXY$=' in url :
  if regexs :
   if 75 - 75: i1IIi
   if '$pyFunction:playmedia(' not in urllib . unquote_plus ( regexs ) and 'notplayable' not in urllib . unquote_plus ( regexs ) and 'listrepeat' not in urllib . unquote_plus ( regexs ) :
    if 74 - 74: I11i11Ii + ooOoO0o - OOooOOo - i1iIi11iIIi1I + IiII - iIii1I11I1II1
    iiI1i1Iii111 . setProperty ( 'IsPlayable' , 'true' )
  else :
   iiI1i1Iii111 . setProperty ( 'IsPlayable' , 'true' )
 else :
  I1iI1iIi111i ( 'NOT setting isplayable' + url )
 if showcontext :
  if 54 - 54: ii1IiI1i + i11i . oOooOoO0Oo0O / i1iIi11iIIi1I . o00O0oo
  if showcontext == 'fav' :
   I1111i . append (
 ( 'Remove CANAIS do Favoritos' , 'XBMC.RunPlugin(%s?mode=6&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) )
 )
  elif not name in iiIiI :
   try :
    O00IiII = (
 '%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage ) , urllib . quote_plus ( fanart ) )
 )
   except :
    O00IiII = (
 '%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage . encode ( "utf-8" ) ) , urllib . quote_plus ( fanart . encode ( "utf-8" ) ) )
 )
   if playlist :
    O00IiII += 'playlist=' + urllib . quote_plus ( str ( playlist ) . replace ( ',' , '||' ) )
   if regexs :
    O00IiII += "&regexs=" + regexs
    if 58 - 58: I1Ii111 % i11iIiiIii * i11i . ii1IiI1i
  iiI1i1Iii111 . addContextMenuItems ( I1111i )
 try :
  if not playlist is None :
   if oO . getSetting ( 'add_playlist' ) == "false" :
    OoO = name . split ( ') ' ) [ 1 ]
    O00oO0o00 = [
 ( 'Play ' + OoO + ' PlayList' , 'XBMC.RunPlugin(%s?mode=13&name=%s&playlist=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( OoO ) , urllib . quote_plus ( str ( playlist ) . replace ( ',' , '||' ) ) ) )
 ]
    iiI1i1Iii111 . addContextMenuItems ( O00oO0o00 )
 except : pass
 if 60 - 60: i11iIiiIii * I11i11Ii % i1iIi11iIIi1I + i1iIi11iIIi1I
 i111I11i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiiiii1Ii , listitem = iiI1i1Iii111 , totalItems = total , isFolder = IiiII )
 if 84 - 84: iIii1I11I1II1 + OoooooooOO
 if 77 - 77: O0 * ii1IiI1i * OOooOOo + i1iIi11iIIi1I + ii1IiI1i - ooOoO0o
 return i111I11i
 if 10 - 10: ii1IiI1i + I1Ii111
def oo0o0oooo ( url , name , iconimage , fanart , description , genre , date , year , director , duration , premiered , studio , rate , originaltitle , country , rating , userrating , votes , aired , showcontext , playlist , regexs , total , setCookie = "" , allinfo = { } ) :
 if 58 - 58: oOooOoO0Oo0O + OoooooooOO / IiII . o00O0oo % i1 / ii1IiI1i
 I1111i = [ ]
 OOooo00 = oO . getSetting ( 'parentalblocked' )
 OOooo00 = OOooo00 == "true"
 ii1111I = oO . getSetting ( 'parentalblockedpin' )
 if 62 - 62: i11i
 if len ( ii1111I ) > 0 :
  if OOooo00 :
   I1111i . append ( ( 'Disable Parental Block' , 'XBMC.RunPlugin(%s?mode=55&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
  else :
   I1111i . append ( ( 'Enable Parental Block' , 'XBMC.RunPlugin(%s?mode=56&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
   if 12 - 12: I1Ii111 + i11i
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 i111I11i = True
 IiiII = False
 if regexs :
  I1ii1iI = '17'
  if 'listrepeat' in regexs :
   IiiII = True
   if 92 - 92: ooOoO0o % iIii1I11I1II1 - IiII / i11iIiiIii % o00O0oo * i1
   if 80 - 80: IiII
  I1111i . append ( ( o0OOoo0OO0OOO , 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 elif ( any ( x in url for x in o0oo0oOo ) and url . startswith ( 'http' ) ) or url . endswith ( '&mode=19' ) :
  url = url . replace ( '&mode=19' , '' )
  I1ii1iI = '19'
  if 3 - 3: ii1IiI1i * Ii1I
  I1111i . append ( ( o0OOoo0OO0OOO , 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 elif url . endswith ( '&mode=18' ) :
  url = url . replace ( '&mode=18' , '' )
  I1ii1iI = '18'
  I1111i . append ( ( '[COLOR white]!!Download!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=23&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
  if oO . getSetting ( 'dlaudioonly' ) == 'true' :
   I1111i . append ( ( '!!Download [COLOR seablue]Audio!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=24&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
   if 53 - 53: iIii1I11I1II1 / IiII % i1iIi11iIIi1I + I1Ii111 / o00O0oo
 elif url . startswith ( 'magnet:?xt=' ) or '.torrent' in url :
  if '&' in url and not '&amp;' in url :
   url = url . replace ( '&' , '&amp;' )
   if 74 - 74: I11i11Ii
  url = 'plugin://plugin.video.elementum/play?uri=' + url
  I1ii1iI = '12'
 else :
  I1ii1iI = '12'
  if 8 - 8: oOooOoO0Oo0O % i11i - i1 - Ii1I % oOooOoO0Oo0O
  I1111i . append ( ( o0OOoo0OO0OOO , 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 if 'plugin://plugin.video.youtube/play/?video_id=' in url :
  o0oo0OOOO = url . replace ( 'plugin://plugin.video.youtube/play/?video_id=' , 'https://www.youtube.com/watch?v=' )
  I1111i . append ( ( '!!Download [COLOR blue]Audio!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=24&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( o0oo0OOOO ) , urllib . quote_plus ( name ) ) ) )
 iiiiii1Ii = sys . argv [ 0 ] + "?"
 Oo0o0O0OOOo0 = False
 if playlist :
  if oO . getSetting ( 'add_playlist' ) == "false" and '$$LSPlayOnlyOne$$' not in playlist [ 0 ] :
   iiiiii1Ii += "url=" + urllib . quote_plus ( url ) + "&mode=" + I1ii1iI
  else :
   iiiiii1Ii += "mode=13&name=%s&playlist=%s" % ( urllib . quote_plus ( name ) , urllib . quote_plus ( str ( playlist ) . replace ( ',' , '||' ) ) )
   name = name + '[COLOR orange] (' + str ( len ( playlist ) ) + ' itens)[/COLOR]'
   Oo0o0O0OOOo0 = True
 else :
  iiiiii1Ii += "url=" + urllib . quote_plus ( url ) + "&mode=" + I1ii1iI
 if regexs :
  iiiiii1Ii += "&regexs=" + regexs
 if not setCookie == '' :
  iiiiii1Ii += "&setCookie=" + urllib . quote_plus ( setCookie )
 if iconimage and not iconimage == '' :
  iiiiii1Ii += "&iconimage=" + urllib . quote_plus ( iconimage )
  if 93 - 93: iII111i * IiII / I11i
 if date == '' :
  date = None
 else :
  description += '\n\nDate: %s' % date
 iiI1i1Iii111 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 if 88 - 88: OOooOOo
 if allinfo == None or len ( allinfo ) < 1 :
  iiI1i1Iii111 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description , "Genre" : genre , "dateadded" : date , "Year" : year , "Director" : director , "Duration" : duration , "Premiered" : premiered , "Studio" : studio , "Mpaa" : rate , "Originaltitle" : originaltitle , "Country" : country , "Rating" : rating , "Userrating" : userrating , "Votes" : votes , "Aired" : aired } )
 else :
  iiI1i1Iii111 . setInfo ( type = "Video" , infoLabels = allinfo )
 iiI1i1Iii111 . setProperty ( "Fanart_Image" , fanart )
 if 1 - 1: I11i11Ii
 if ( not Oo0o0O0OOOo0 ) and not any ( x in url for x in o000O0o ) and not '$PLAYERPROXY$=' in url :
  if regexs :
   if 95 - 95: OoooooooOO / Ii1I % OoooooooOO / o00O0oo * I1Ii111
   if '$pyFunction:playmedia(' not in urllib . unquote_plus ( regexs ) and 'notplayable' not in urllib . unquote_plus ( regexs ) and 'listrepeat' not in urllib . unquote_plus ( regexs ) :
    if 75 - 75: O0
    iiI1i1Iii111 . setProperty ( 'IsPlayable' , 'true' )
  else :
   iiI1i1Iii111 . setProperty ( 'IsPlayable' , 'true' )
 else :
  I1iI1iIi111i ( 'NOT setting isplayable' + url )
 if showcontext :
  if 56 - 56: i1iIi11iIIi1I / i11i
  if showcontext == 'fav' :
   I1111i . append (
 ( 'Remove CANAIS do Favoritos' , 'XBMC.RunPlugin(%s?mode=6&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) )
 )
  elif not name in iiIiI :
   try :
    O00IiII = (
 '%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage ) , urllib . quote_plus ( fanart ) )
 )
   except :
    O00IiII = (
 '%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage . encode ( "utf-8" ) ) , urllib . quote_plus ( fanart . encode ( "utf-8" ) ) )
 )
   if playlist :
    O00IiII += 'playlist=' + urllib . quote_plus ( str ( playlist ) . replace ( ',' , '||' ) )
   if regexs :
    O00IiII += "&regexs=" + regexs
    if 39 - 39: o0 - OoooooooOO - i1IIi / i11i
  iiI1i1Iii111 . addContextMenuItems ( I1111i )
 try :
  if not playlist is None :
   if oO . getSetting ( 'add_playlist' ) == "false" :
    OoO = name . split ( ') ' ) [ 1 ]
    O00oO0o00 = [
 ( 'Play ' + OoO + ' PlayList' , 'XBMC.RunPlugin(%s?mode=13&name=%s&playlist=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( OoO ) , urllib . quote_plus ( str ( playlist ) . replace ( ',' , '||' ) ) ) )
 ]
    iiI1i1Iii111 . addContextMenuItems ( O00oO0o00 )
 except : pass
 if 49 - 49: I11i11Ii + O0 + I1Ii111 . i11i % o00O0oo
 i111I11i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiiiii1Ii , listitem = iiI1i1Iii111 , totalItems = total , isFolder = IiiII )
 if 33 - 33: o0 . iIii1I11I1II1 / Ii1I % iII111i
 if 49 - 49: i1iIi11iIIi1I + i11i / I1Ii111 - O0 % iII111i
 return i111I11i
 if 27 - 27: i1iIi11iIIi1I + I11i11Ii
def oO0oOOooO0 ( url , name , iconimage , setresolved = True ) :
 if setresolved :
  iiI1i1Iii111 = xbmcgui . ListItem ( name , iconImage = iconimage )
  iiI1i1Iii111 . setInfo ( type = 'Video' , infoLabels = { 'Title' : name } )
  iiI1i1Iii111 . setProperty ( "IsPlayable" , "true" )
  iiI1i1Iii111 . setPath ( str ( url ) )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiI1i1Iii111 )
 else :
  xbmc . executebuiltin ( 'XBMC.RunPlugin(' + url + ')' )
  if 62 - 62: i11iIiiIii - Ii1I
  if 81 - 81: Ii1I
  if 92 - 92: I11i - I11i11Ii - OoooooooOO / I1Ii111 - i1IIi
  if 81 - 81: i1IIi / ooOoO0o % i11iIiiIii . iIii1I11I1II1 * o0 + OoooooooOO
def Oo0Oo0O ( link ) :
 O0O0Oooo0o = urllib . urlopen ( link )
 iiii1Ii1iii = O0O0Oooo0o . read ( )
 O0O0Oooo0o . close ( )
 Oo0Oo0 = iiii1Ii1iii . split ( "Jetzt" )
 oooOooooO = Oo0Oo0 [ 1 ] . split ( 'programm/detail.php?const_id=' )
 i1IIiiIIIIi = oooOooooO [ 1 ] . split ( '<br /><a href="/' )
 IiIIIi = i1IIiiIIIIi [ 0 ] [ 40 : len ( i1IIiiIIIIi [ 0 ] ) ]
 Oo0iII = oooOooooO [ 2 ] . split ( "</a></p></div>" )
 O0oo = Oo0iII [ 0 ] [ 17 : len ( Oo0iII [ 0 ] ) ]
 O0oo = O0oo . encode ( 'utf-8' )
 return "  - " + O0oo + " - " + IiIIIi
 if 34 - 34: oOooOoO0Oo0O
 if 57 - 57: I11i . iII111i % i1
def OoO00oo00 ( url , regex ) :
 IiI111111IIII = Iii1iI ( url )
 try :
  i1oO = re . findall ( regex , IiI111111IIII ) [ 0 ]
  return i1oO
 except :
  I1iI1iIi111i ( 'regex failed' )
  I1iI1iIi111i ( regex )
  return
  if 32 - 32: Ii1I / I1Ii111 - O0 * iIii1I11I1II1
  if 70 - 70: OoooooooOO % OoooooooOO % i1iIi11iIIi1I
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 98 - 98: i1iIi11iIIi1I
try :
 xbmcplugin . addSortMethod ( int ( sys . argv [ 1 ] ) , xbmcplugin . SORT_METHOD_UNSORTED )
except :
 pass
try :
 xbmcplugin . addSortMethod ( int ( sys . argv [ 1 ] ) , xbmcplugin . SORT_METHOD_LABEL )
except :
 pass
try :
 xbmcplugin . addSortMethod ( int ( sys . argv [ 1 ] ) , xbmcplugin . SORT_METHOD_DATE )
except :
 pass
try :
 xbmcplugin . addSortMethod ( int ( sys . argv [ 1 ] ) , xbmcplugin . SORT_METHOD_GENRE )
except :
 pass
 if 18 - 18: Ii1I + I11i11Ii - i1iIi11iIIi1I / ooOoO0o / I11i
Oo00Oo = I1ii1I1iii1 ( )
if 53 - 53: I11i + i1 . OOooOOo / Ii1I
O0O0Oooo0o = None
oOOO00o000o = None
I1ii1iI = None
i1IIi1i1Ii1 = None
O00oo0oOoO00O = None
iIi11 = i1iI11i1ii11
i1IIi1i1Ii1 = None
o0000oO = None
II1Ii11Ii1i1I = None
if 83 - 83: i1iIi11iIIi1I
try :
 O0O0Oooo0o = urllib . unquote_plus ( Oo00Oo [ "url" ] ) . decode ( 'utf-8' )
except :
 pass
try :
 oOOO00o000o = urllib . unquote_plus ( Oo00Oo [ "name" ] )
except :
 pass
try :
 O00oo0oOoO00O = urllib . unquote_plus ( Oo00Oo [ "iconimage" ] )
except :
 pass
try :
 iIi11 = urllib . unquote_plus ( Oo00Oo [ "fanart" ] )
except :
 pass
try :
 I1ii1iI = int ( Oo00Oo [ "mode" ] )
except :
 pass
try :
 i1IIi1i1Ii1 = eval ( urllib . unquote_plus ( Oo00Oo [ "playlist" ] ) . replace ( '||' , ',' ) )
except :
 pass
try :
 o0000oO = int ( Oo00Oo [ "fav_mode" ] )
except :
 pass
try :
 II1Ii11Ii1i1I = Oo00Oo [ "regexs" ]
except :
 pass
 if 16 - 16: o00O0oo
I1iI1iIi111i ( "Mode: " + str ( I1ii1iI ) )
if not O0O0Oooo0o is None :
 I1iI1iIi111i ( "URL: " + str ( O0O0Oooo0o . encode ( 'utf-8' ) ) )
I1iI1iIi111i ( "Name: " + str ( oOOO00o000o ) )
if 32 - 32: i1 % oOooOoO0Oo0O
if I1ii1iI == None :
 I1iI1iIi111i ( "Index" )
 o0o0O0O00oOOo ( True )
 if 7 - 7: I11i11Ii . i1IIi - OOooOOo
elif I1ii1iI == 1 :
 I1iI1iIi111i ( "getData" )
 IiI111111IIII = None
 O0O0Oooo0o = base64 . b16decode ( base64 . b32decode ( codecs . decode ( O0O0Oooo0o , 'rot_13' ) ) )
 if II1Ii11Ii1i1I :
  IiI111111IIII = i1iI1IIIII1 ( II1Ii11Ii1i1I , O0O0Oooo0o )
  O0O0Oooo0o = ''
  if 93 - 93: I1Ii111 % ii1IiI1i
 oo00oO0O0 ( O0O0Oooo0o , iIi11 , IiI111111IIII )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 31 - 31: i11i + I11i - OoooooooOO . Ii1I
elif I1ii1iI == 2 :
 I1iI1iIi111i ( "getChannelItems" )
 O0O0Oooo0o = base64 . b16decode ( base64 . b32decode ( codecs . decode ( O0O0Oooo0o , 'rot_13' ) ) )
 if II1Ii11Ii1i1I :
  IiI111111IIII = i1iI1IIIII1 ( II1Ii11Ii1i1I , O0O0Oooo0o )
  O0O0Oooo0o = ''
  if 28 - 28: iII111i . ii1IiI1i
 OooO0ooo0o ( oOOO00o000o , O0O0Oooo0o , iIi11 )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 77 - 77: ii1IiI1i % i11i
elif I1ii1iI == 3 :
 I1iI1iIi111i ( "getSubChannelItems" )
 O0O0Oooo0o = base64 . b16decode ( base64 . b32decode ( codecs . decode ( O0O0Oooo0o , 'rot_13' ) ) )
 if II1Ii11Ii1i1I :
  IiI111111IIII = i1iI1IIIII1 ( II1Ii11Ii1i1I , O0O0Oooo0o )
  O0O0Oooo0o = ''
  if 81 - 81: o0 % iII111i / O0 * iIii1I11I1II1 % I1Ii111 . oOooOoO0Oo0O
 O0000 ( oOOO00o000o , O0O0Oooo0o , iIi11 )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 90 - 90: i1
elif I1ii1iI == 4 :
 I1iI1iIi111i ( "getFavorites" )
 OOoOO0o0o0Oo ( )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 44 - 44: i1 / ii1IiI1i . I11i11Ii + o0
elif I1ii1iI == 5 :
 I1iI1iIi111i ( "addFavorite" )
 try :
  oOOO00o000o = oOOO00o000o . split ( '\\ ' ) [ 1 ]
 except :
  pass
 try :
  oOOO00o000o = oOOO00o000o . split ( '  - ' ) [ 0 ]
 except :
  pass
 o00oO000 ( oOOO00o000o , O0O0Oooo0o , O00oo0oOoO00O , iIi11 , o0000oO )
 if 32 - 32: I1Ii111 - o00O0oo * IiII * Ii1I
elif I1ii1iI == 6 :
 I1iI1iIi111i ( "rmFavorite" )
 try :
  oOOO00o000o = oOOO00o000o . split ( '\\ ' ) [ 1 ]
 except :
  pass
 try :
  oOOO00o000o = oOOO00o000o . split ( '  - ' ) [ 0 ]
 except :
  pass
 Ii111I11 ( oOOO00o000o )
 if 84 - 84: iII111i + ii1IiI1i % oOooOoO0Oo0O + i11iIiiIii
elif I1ii1iI == 7 :
 I1iI1iIi111i ( "addSource" )
 iI1I ( O0O0Oooo0o )
 if 37 - 37: Ii1I % ii1IiI1i / o00O0oo
elif I1ii1iI == 8 :
 I1iI1iIi111i ( "rmSource" )
 OOooO0oo0o00o ( oOOO00o000o )
 if 94 - 94: Ii1I / i1iIi11iIIi1I . i1
elif I1ii1iI == 9 :
 I1iI1iIi111i ( "download_file" )
 iIiII1iiiiI ( oOOO00o000o , O0O0Oooo0o )
 if 1 - 1: I11i11Ii . i11i
elif I1ii1iI == 10 :
 I1iI1iIi111i ( "getCommunitySources" )
 Ii1ii1IiIII ( )
 if 93 - 93: i11i . i11iIiiIii + i11i % OOooOOo
elif I1ii1iI == 11 :
 I1iI1iIi111i ( "addSource" )
 iI1I ( O0O0Oooo0o )
 if 98 - 98: ooOoO0o * OOooOOo * o0 + iII111i * IiII
elif I1ii1iI == 12 :
 I1iI1iIi111i ( "setResolvedUrl" )
 if not O0O0Oooo0o . startswith ( "plugin://plugin" ) or not any ( x in O0O0Oooo0o for x in o000O0o ) :
  i1oO = xbmcgui . ListItem ( path = O0O0Oooo0o )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1oO )
 else :
  print 'Not setting setResolvedUrl'
  xbmc . executebuiltin ( 'XBMC.RunPlugin(' + O0O0Oooo0o + ')' )
  if 4 - 4: I1Ii111
  if 16 - 16: iIii1I11I1II1 * IiII + OOooOOo . O0 . i1
elif I1ii1iI == 13 :
 I1iI1iIi111i ( "play_playlist" )
 O0Oo00 ( oOOO00o000o , i1IIi1i1Ii1 )
 if 99 - 99: i11iIiiIii - IiII
elif I1ii1iI == 14 :
 I1iI1iIi111i ( "get_xml_database" )
 iII111iO0000o ( O0O0Oooo0o )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 85 - 85: ooOoO0o % ii1IiI1i
elif I1ii1iI == 15 :
 I1iI1iIi111i ( "browse_xml_database" )
 iII111iO0000o ( O0O0Oooo0o , True )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 95 - 95: i1iIi11iIIi1I * I11i * IiII . i1
elif I1ii1iI == 16 :
 I1iI1iIi111i ( "browse_community" )
 Ii1ii1IiIII ( True )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 73 - 73: i1iIi11iIIi1I
elif I1ii1iI == 17 :
 I1iI1iIi111i ( "getRegexParsed" )
 O0O0Oooo0o , OoIIi1iI = i1iI1IIIII1 ( II1Ii11Ii1i1I , O0O0Oooo0o )
 if O0O0Oooo0o :
  oO0oOOooO0 ( O0O0Oooo0o , oOOO00o000o , O00oo0oOoO00O , OoIIi1iI )
 else :
  if 28 - 28: OoooooooOO - Ii1I
  xbmc . executebuiltin ( "XBMC.Notification(Failed to extract regex. - " + "this" + ",4000," + oOO00Oo + ")" )
elif I1ii1iI == 18 :
 I1iI1iIi111i ( "youtubedl" )
 try :
  import youtubedl
 except Exception :
  if 84 - 84: i11i
  xbmc . executebuiltin ( "XBMC.Notification(Please [COLOR yellow]install the Youtube Addon[/COLOR] module ,10000," ")" )
 O0oOOo0Oo = youtubedl . single_YD ( O0O0Oooo0o )
 oO0oOOooO0 ( O0oOOo0Oo , oOOO00o000o , O00oo0oOoO00O )
elif I1ii1iI == 19 :
 I1iI1iIi111i ( "Genesiscommonresolvers" )
 oO0oOOooO0 ( ii1 ( O0O0Oooo0o ) , oOOO00o000o , O00oo0oOoO00O , True )
 if 36 - 36: I11i - o0 - iIii1I11I1II1
elif I1ii1iI == 21 :
 I1iI1iIi111i ( "download current file using youtube-dl service" )
 iiiIIiiIi ( '' , oOOO00o000o , 'video' )
elif I1ii1iI == 23 :
 I1iI1iIi111i ( "get info then download" )
 iiiIIiiIi ( O0O0Oooo0o , oOOO00o000o , 'video' )
elif I1ii1iI == 24 :
 I1iI1iIi111i ( "Audio only youtube download" )
 iiiIIiiIi ( O0O0Oooo0o , oOOO00o000o , 'audio' )
elif I1ii1iI == 25 :
 I1iI1iIi111i ( "YouTube/DMotion" )
 OOOOoO0 ( O0O0Oooo0o )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
elif I1ii1iI == 26 :
 I1iI1iIi111i ( "YouTube/DMotion From Search History" )
 oOOO00o000o = oOOO00o000o . split ( ':' )
 OOOOoO0 ( O0O0Oooo0o , search_term = oOOO00o000o [ 1 ] )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
elif I1ii1iI == 27 :
 I1iI1iIi111i ( "Using IMDB id to play in Pulsar" )
 II11 = OOOOoO0 ( O0O0Oooo0o )
 xbmc . Player ( ) . play ( II11 )
elif I1ii1iI == 30 :
 O00Oo ( oOOO00o000o , O0O0Oooo0o , O00oo0oOoO00O , iIi11 )
 if 79 - 79: O0 + Ii1I
elif I1ii1iI == 40 :
 OOoOOo0O00O ( )
 IIIii ( )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 25 - 25: ooOoO0o - iII111i / O0 . OoooooooOO % oOooOoO0Oo0O . i1IIi
elif I1ii1iI == 41 :
 I1iI1iIi111i ( "puxarconf" )
 xbmcaddon . Addon ( ) . openSettings ( )
 xbmcgui . Dialog ( ) . ok ( '[B][COLOR red]AVISO IMPORTANTE![/COLOR][/B]' , '[B]POR FAVOR SAIR DO ADD-ON E ENTRE NOVAMENTE PARA ATUALIZAR AS CONFIGURAÇÕES[/B]' )
 xbmc . executebuiltin ( "XBMC.Container.Refresh" )
 if 19 - 19: i11i / i11i % ii1IiI1i + OOooOOo + OOooOOo + IiII
elif I1ii1iI == 42 :
 I1iI1iIi111i ( "infofilme4k" )
 if 4 - 4: i1 + Ii1I / IiII + i1IIi % i1 % IiII
 if 80 - 80: iII111i
 xbmcgui . Dialog ( ) . ok ( Ii1IOo0o0 , o0O ( oOO00oOO ) )
 if 26 - 26: iIii1I11I1II1 . OoooooooOO - iIii1I11I1II1
 if 59 - 59: ii1IiI1i + Ii1I . OOooOOo
elif I1ii1iI == 43 :
 iII11I1IiiIi ( True )
 if 87 - 87: i1iIi11iIIi1I
if I1ii1iI == 44 :
 IIOOOO0oo0 ( True )
 if 34 - 34: ooOoO0o . o0 / i11iIiiIii / IiII
elif I1ii1iI == 53 :
 I1iI1iIi111i ( "Requesting JSON-RPC Items" )
 O0O0Oooo0o = base64 . b16decode ( base64 . b32decode ( codecs . decode ( O0O0Oooo0o , 'rot_13' ) ) )
 if II1Ii11Ii1i1I :
  IiI111111IIII = i1iI1IIIII1 ( II1Ii11Ii1i1I , O0O0Oooo0o )
  O0O0Oooo0o = ''
  if 46 - 46: I11i11Ii + i11i * oOooOoO0Oo0O + I11i
 O0o00ooo ( O0O0Oooo0o )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 31 - 31: iII111i * i1 * iII111i + i1iIi11iIIi1I * i1 . ooOoO0o
elif I1ii1iI == 54 :
 oo0OO00OoooOo ( True )
 if 89 - 89: OoooooooOO * iII111i * oOooOoO0Oo0O . o00O0oo * iII111i / IiII
 if 46 - 46: i11iIiiIii
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
